name = "老王"
print(type(name))

# 整数类型 int
age = 18
print(type(age))
print(age + 1)

number = 1_000_000_000_000
print(number)

# 浮点数类型 float
PI = 3.14
print(type(PI))
print(PI)

print(3.14e3)
print(3.14e-3)

# 布尔类型 bool
a = 9 > 7
print(type(a))
print(a)

# 字符串 str
x = "hello world"
print(x)
y = """
床前  明月光，
疑是  地上霜。
举头  望明月,
低头  思故乡。


111111
"""
print(y)

str01 = 'She said, "hello!"'
print(str01)

str02 = 'Sh\' \" \\e said, \n"hel\tlo!"' # tab 四个空格
print(str02)

print(r"C\path\to\nile.txt")

print("老王" + "去串门")
print("老王" * 3)