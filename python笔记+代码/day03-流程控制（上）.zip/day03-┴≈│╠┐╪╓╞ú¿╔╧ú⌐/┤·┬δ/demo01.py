num = 10
print(id(num))
num01 = 10
num02 = 10.0
print(num01 == num02)
print(num01 is num02)
print(id(num01))
print(id(num02))

num3 = 257
num4 = 257
print(num3 is num4)

names = "老王，小丽，小美"
print("老王" in names)
print("小丽" in names)
print("小丽小美" in names)
print("王，小" in names)

score01 = 95 > 60  # True
score02 = 59 > 60  # False
print(score01 and score02)  # False
print(score01 or score02)  # Ture
print(not score01)  # False
print(not score02)  # Ture
