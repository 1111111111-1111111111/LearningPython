# 单分支
"""age = int(input("age:"))
if age >= 18:
    print("可以进入网吧！")"""

# 双分支
payment = 50
if payment > 99:
    print("欢迎下次光临")
else:
    print("有人吃霸王餐，给我拿下！")

# 多分支
"""# 获取学生成绩
score = int(input("请输入学生的考试成绩:")) 
# 判定成绩等级
if score >= 90:
    print("成绩等级：优秀")
elif score >= 80:
    print("成绩等级：良好")
elif score >= 70:
    print("成绩等级：中等")
elif score >= 60:
    print("成绩等级：及格")
else:
    print("成绩等级：不及格")"""

# if 嵌套
# 等级查询
"""score = int(input("请输入学生的考试成绩:"))
if score >= 0 and score <= 100:
    if score >= 90:
        print("A")
    elif score >= 80:
        print("B")
    elif score >= 70:
        print("C")
    elif score >= 60:
        print("D")
    else:
        print("首考不及格")
        score02 = int(input("请输入补考成绩："))
        if 0 <= score02 <= 100:
            if score02 >= 60:
                print("补考及格")
            else:
                print("补考不及格")
        else:
            print("你的补考成绩输入有误！")
else:
    print("你的输入有误！")"""

age = 19
if age >= 18:
    pass
else:
    print("111")

# 条件表达式
age = int(input("age:"))
if age >= 18:
    print("成年了")
else:
    print("未成年")

data = "成年了" if age >= 18 else "未成年"
print(data)

print("成年了") if age >= 18 else print("未成年")

a = 11
b = 22
if a > b:
    print(a)
else:
    print(b)

print(a) if a > b else print(b)




