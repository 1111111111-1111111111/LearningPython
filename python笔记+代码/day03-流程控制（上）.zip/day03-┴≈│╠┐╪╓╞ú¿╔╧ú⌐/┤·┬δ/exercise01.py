"""
在终端中输入整数
打印正数、 负数、零
"""
number = int(input("请输入整数："))
if number > 0:
    print("正数")
elif number == 0:
    print("零")
else:
    print("负数")

"""
在终端中输入按键1~4,显示对应内容
效果：
输入：			输出：
1				老王
2				串门
3				邻居
4				饺子
"""
number = int(input("输入按键1~4"))
if number == 1:
    print("老王")
elif number == 2:
    print("串门")
elif number == 3:
    print("邻居")
elif number == 4:
    print("饺子")
else:
    print("输入错误！")




















