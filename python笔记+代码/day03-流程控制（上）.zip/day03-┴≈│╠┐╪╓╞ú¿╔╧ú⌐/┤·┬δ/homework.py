"""
		商店找零功能
	假设 a 商品单价为15元，
	请输入你要购买的数量，和你付的钱数
	输出应找回金额
效果：
请输入购买数量：1
请输入支付金额：100
找您85.0元
"""
a = 15
number = int(input("请输入购买数量："))
payment = int(input("请输入支付金额："))
money = payment - a * number
print(f"找您{money:.2f}元")










