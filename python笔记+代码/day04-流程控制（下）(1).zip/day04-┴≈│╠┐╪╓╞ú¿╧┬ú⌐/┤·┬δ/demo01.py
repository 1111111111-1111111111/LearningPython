# while 循环
"""while True: # 永真 --> 死循环
    print("老王来了")
print("我把媳妇落家了")"""

# 计数器
count = 1
while count < 4: # count = 1 2 3 4
    print("老王来了")
    count += 1
print("我把媳妇落家了")

# 使用循环输出1-100的所有整数,数字打印在一行，并用" --> "分割
# 计数器
num = 1
while num <= 100:
    print(num, end=" --> ")
    num += 1

# 使用循环输出1-100的所有偶数/奇数
# 计数器
num = 1
while num <= 100:
    # 偶数
    if num % 2 == 0:
        print(num)
    num += 1

count = 0
while count < 10:
    if count == 5:
        print("退出循环")
        break  # 立刻退出循环
        print("================")
    print(f"count = {count}")
    count += 1
print("循环break")


count = 0
while count < 10:
    if count == 5:
        print("跳过本次循环")
        count += 1
        continue  # 跳过本次循环
        print("================")
    print(f"count = {count}")
    count += 1
print("循环continue")





