# for 循环
for i in "老王去串门!":
    print(i)

for i in range(1, 11):
    print(i)

# 用法一:range(stop)生成从0开始到stop之前的所有整数。
for i in range(10): # 生成的是0-9
    print(i, end=" ")
print()
# 用法二：range(start, stop)生成从start开始到stop之前的所有整数。
for i in range(1, 10): # 生成的是1-9
    print(i, end=" ")
print()
# 用法三：range(start, stop, step)生成从start开始到stop之前的所有整数，数字之间的间隔由step指定。
for i in range(1, 10, 2):  # 步长 1 3 5 7 9
    print(i, end=" ")
print()
for i in range(10, 1, -1):  # 逆序
    print(i, end=" ")

for i in range(10):
    if i == 3:
        print("continue", i)
        continue
    elif i == 7:
        print("break", i)
        break
    print(f"i = {i}")

for i in range(2):
    print("你好！")
    for j in range(3):
        print("老王")

a = 0
while a < 2:
    print("你好！!!!")
    b = 0
    while b < 3:
        print("老王!!!")
        b += 1
    a += 1











