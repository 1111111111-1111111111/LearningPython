# exercise01:
"""
在终端中输入任意整数，计算累加和.
"1234" -> "1" -> 累加 1
效果：
请输入一个整数:12345
累加和是 15
"""
number = input("请输入一个整数:")
sum = 0
for i in number:  # i = "1" "2" "3" "4"
    sum += int(i)
print("累加和是", sum)

# exercise02:
"""
高斯定理：求1-100的和
"""
sum = 0
for i in range(1, 101):  # 包头不包尾
    sum += i
print(sum)







