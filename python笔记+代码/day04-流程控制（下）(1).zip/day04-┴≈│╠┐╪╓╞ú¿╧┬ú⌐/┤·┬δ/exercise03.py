# exercise01:
"""
打印如下图形
*  *  *  *  *  
*  *  *  *  *  
*  *  *  *  *  
*  *  *  *  *  
*  *  *  *  *
"""
for i in range(5):
    print("* " * 5)


# exercise02：
"""
*  
*  *  
*  *  *  
*  *  *  *  
*  *  *  *  *
"""
for i in range(1, 6):
    print("* " * i)