"""
打印九九乘法表
"""
for i in range(1, 10): # i = 1 2 3 4 5 6 7 8 9
    for j in range(1, i+1):
        print(f"{j} * {i} = {j * i}", end="\t")
    print()














