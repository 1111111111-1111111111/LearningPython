"""
在终端中循环录入5个成绩,最后打印平均成绩(总成绩除以人数)
效果：
请输入成绩：98
请输入成绩：83
请输入成绩：90
请输入成绩：99
请输入成绩：78
平均分：89.6
"""
# result:总成绩 count：计数器
result, count = 0, 1
while count <= 5:
    result += int(input("请输入成绩："))  # result = result + int(input("请输入成绩："))
    count += 1
print(f"平均分：{result / 5}")


"""
一张纸的厚度是1毫米
请计算，对折多少次超过珠穆朗玛峰(8844.43米)
思路:
数据：厚度、高度、次数
算法：厚度*=2	次数+=1
"""
# 厚度
thickness = 0.001
# 次数
count = 0
# 高度
high = 8844.43
while thickness < high:
    thickness *= 2
    count += 1
    print(f"对折{count}次的厚度是{thickness}")
print(f"对折{count}次超过珠穆朗玛峰(8844.43米)")

