"""
编写一个程序，让用户输入一个整数，判断该整数是偶数还是奇数
效果：
请输入一个整数：
number为偶数
"""
number = int(input('请输入一个整数：'))
if number % 2 == 0:
    print(number, '为偶数')
else:
    print(number, '为奇数')
print(number, '为偶数') if number % 2 == 0 else print(number, '为奇数')


"""
在终端中输入一个年份，如果是闰年，变量day赋值29,否则赋值28。
闰年条件：年份能被4整除但是不能被100整除，或者年份能被400整除
效果：
请输入年份:2020
2020年的2月有29天
"""
year = int(input('请输入年份:'))
if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
    day = 29
else:
    day = 28
print(f"{year}年的2月有{day}天")
# day = 29 if year % 4 == 0 and year % 100 != 0 or year % 400 == 0 else 28












