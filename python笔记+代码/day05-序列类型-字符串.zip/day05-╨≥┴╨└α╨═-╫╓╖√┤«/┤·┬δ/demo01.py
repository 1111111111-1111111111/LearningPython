# 索引
mess = "hello world"

# 正索引从0开始计数，访问从左到右的元素。
print(mess[0])
print(mess[10])
print(mess[4])

# 负索引从-1开始计数，访问从右到左的元素。
print(mess[-1])
print(mess[-5])

# 如果索引超出序列的范围，会引发IndexError错误。
# print(mess[11])

# 字符串只能通过索引取值，但是无法修改值
# mess[-1] = "a"

# 切片
mess = "hello world"

# 默认切片表示整个序列,start，默认为0
print(mess[:]) # 全切

# 仅指定start，从start开始到结尾
print(mess[4:])

# 仅指定end，从开头开始到end之前 不包含end，end默认为序列长度
print(mess[:4])  # 包头不包尾

# 同时指定start和end，从start开始到end之前
print(mess[1:4])

# 按step步长提取元素，step默认为1
print(mess[::2])

# step为负数，从右向左提取元素。
print(mess[::-1]) # 字符串的反转
print(mess[10::-1])
print(mess[10::-2])

# 字符串反转
print(mess[::-1])

