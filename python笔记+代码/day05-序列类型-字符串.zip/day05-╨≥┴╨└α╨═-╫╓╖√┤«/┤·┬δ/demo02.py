mess01 = "hello world"
mess02 = "beautiful world"
# 长度获取:使用内置函数  len()  来获取序列的长度
print(len(mess01))

# 成员检查:使用关键字 in 来检查一个元素是否存在于序列中
print("he" in mess01)

# 连接操作:使用加号 + 来连接两个序列，生成一个新的序列
print(mess01 + mess02)

# 重复操作:使用乘号 * 来重复序列中的元素，生成一个新的序列
print(mess01 * 3)

# 迭代:使用 for 循环来遍历序列中的元素
for i in mess01:
    print(i, end="-")
print()

# 元素查找：使用 index() 方法来查找指定元素在序列中的索引。如果元素不存在，会引发 ValueError 错误
print(mess01.index("l"))
# print(mess01.index("z"))

# 计数元素出现次数:使用 count() 方法来统计指定元素在序列中出现的次数。
print(mess01.count("l"))

# 最值获取:使用内置函数 max() 和 min() 来获取序列中的最大值和最小值
list01 = [1, 2, 16, 31, 100, 7, 8]  # 列表
print(max(list01))
print(min(list01))

# 排序操作:使用内置函数 sorted() 对序列进行排序，生成一个新的排序后的序列
print(sorted(list01)) # 生成了一个新的列表
print(sorted(list01, reverse=True)) # 生成了一个新的列表
