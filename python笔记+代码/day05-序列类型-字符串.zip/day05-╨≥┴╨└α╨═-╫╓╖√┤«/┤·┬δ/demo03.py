mess = "老王爱串门，喜欢吃饺子！"
# startswith() : 检查字符串是否以指定的子字符串开头，返回布尔值。
if mess.startswith("老"):
    print("关门，放狗！")

# endswith() : 检查字符串是否以指定的子字符串结尾，返回布尔值。
if mess.endswith("饺子！"):
    print("干饭")

# isdigit() : 检查字符串是否只包含数字字符，返回布尔值。
mess01 = "123131231"
if mess01.isdigit():
    print("全是数字")

# strip() : 去除字符串两端的空格，换行符，制表符（或指定的字符）
print(mess.strip("！"))

# lower() : 将字符串转换为小写形式
# upper() : 将字符串转换为大写形式
mess02 = "My name is LaoWang!"
print(mess02.lower())
print(mess02.upper())

# replace() : 将字符串中的指定子字符串替换为新的字符串
print(mess.replace("饺子", "包子"))
print(mess)

# find() : 查找指定子字符串在字符串中的索引位置，如果找到返回索引值，否则返回-1
print(mess.find("爱"))
print(mess.find("小"))

# split() : 将字符串按照指定的分隔符分割成子字符串，并返回一个包含子字符串的列表。
print(mess.split("，"))

# join() : 将一个包含字符串的可迭代对象（如列表）连接成一个字符串，使用指定的连接符
print("%%%%%老王-->".join(['老王爱串门', '喜欢吃饺子！']))
