name = "老王"
age = 40
high = 185.0
# 普通写法
print("我叫" + name + "今年" + str(age) + "岁了,身高" + str(high))

# % 方法
print("我叫%s今年%d岁了,身高%f" % (name, age, high))
print("我叫%s今年%d岁了,身高%.2f" % (name, age, high))
print("我叫%s今年%d岁了,身高%.2f" % ("老王", 40, 185.0))

data01 = "我叫%s今年%d岁了,身高%.2f" % (name, age, high)
print(data01)

# format方法
data02 = "我叫{}今年{}岁了,身高{:.2f}".format(name, age, high)
print(data02)

# f-string方法
data03 = f"我叫{name}今年{age}岁了,身高{high:.2f}"
print(data03)



