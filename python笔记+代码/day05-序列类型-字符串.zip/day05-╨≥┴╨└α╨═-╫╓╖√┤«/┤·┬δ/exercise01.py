mess = "老王爱串门，喜欢吃饺子！"
# 1.打印第一个字符、打印最后一个字符、打印中间字符
print(mess[0])
print(mess[-1])
print(mess[1:-1])  # 包头不包尾

# 2.打印字前三个符、打印后三个字符
print(mess[:3])
print(mess[-3:])

# 3.判断老王在字符串mess中
print("老王" in mess)

# 4.通过切片打印"爱串门，喜欢吃"
print(mess[2:-3])

# 5.通过切片打印“老串喜饺”
print(mess[::3])

# 7.倒序打印字符
print(mess[::-1])