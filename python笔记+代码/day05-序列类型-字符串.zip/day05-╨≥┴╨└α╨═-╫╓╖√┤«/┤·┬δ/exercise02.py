"""
输入患病人数和治愈人数，并计算治愈率
要求：分别用占位符，format()，f-strings三种方式进行打印
	 治愈率保留两位小数
效果：
请输入患病人数：
请输入治愈人数：
京海市共确诊10000人，治愈9000人，治愈率为0.90。
"""
unhealthy = int(input("请输入患病人数："))
healthy = int(input("请输入治愈人数："))
# 占位符
data01 = "京海市共确诊%d人，治愈%d人，治愈率为%.2f。" % (unhealthy, healthy, healthy / unhealthy)
print(data01)
# format()
data02 = "京海市共确诊{}人，治愈{}人，治愈率为{:.2f}。".format(unhealthy, healthy, healthy / unhealthy)
print(data02)
# f-strings
data03 = f"京海市共确诊{unhealthy}人，治愈{healthy}人，治愈率为{healthy / unhealthy:.2f}。"
print(data03)





