# -1.
"""
循环输入整数，当输入空字符时退出循环
求出这些数据的平均值
效果：
请输入整数：10
请输入整数：15
请输入整数：20
请输入整数：15
请输入整数：
这4个整数的平均值为：15
"""
sum = 0
count = 0
while True:
    num = input('请输入整数：')
    if not num:
        break
    sum += int(num)
    count += 1
print(f"这{count}个整数的平均值为：{sum / count}")

# -2
"""
使用for循环遍历字符串"abaaeeaddaoaoea",统计字符串"a"的次数
"""
count = 0
for i in "abaaeeaddaoaoea":  # 遍历
    if i == "a":
        count += 1
print(count)

# -3
"""
猜数字：电脑随机生成一个1-100区间的数字，一直提示让用户输出数字，如果比随机数大，则显示猜测的结果大了， 如果是比随机数小，则显示猜测的结果小了，只有输入数字等于随机数，显示猜测结果正确，然后退出循环
提示:
1.随机数使用random模块；
	import random
	a = random.randint(1, 100)
2.退出循环可以使用break关键字
效果：
=======================
	欢迎进入猜数字游戏
=======================	
请输入你的猜测：28
不好意思，再往大猜猜吧！
不好意思，再往小猜猜吧！
你太棒了！你猜了5次后通关！
"""
import random

a = random.randint(1, 100)
count = 0
print("""
=======================
	欢迎进入猜数字游戏
=======================	
""")
while True:
    get = int(input("请输入你的猜测："))
    count += 1
    if get < 0 or get > 100:
        print("您的输入有误，请正确输入！")
    elif get < a:
        print("不好意思，再往大猜猜吧！")
    elif get > a:
        print("不好意思，再往小猜猜吧！")
    else:
        print(f"你太棒了！你猜了{count}次后通关！")
        break


