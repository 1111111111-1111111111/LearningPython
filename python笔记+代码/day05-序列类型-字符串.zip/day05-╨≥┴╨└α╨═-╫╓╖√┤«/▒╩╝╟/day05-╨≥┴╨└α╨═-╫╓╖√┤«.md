

# 数据类型-序列

## 上课节回顾

```python
-循环
   while循环 根据条件的真假来重复执行代码块，直到条件为假为止
   break 退出整个循环
   continue 退出本次循环，不会退出整个循环
   while...else... 正常结束的没有break终止，那么else里面的代码就会执行
   
   for循环 通过迭代方便取值
   for循环后面可以跟可迭代对象，字符串，列表都可以被for循环
   range(start,stop,step)函数创建一系列数字 开始和结束，间隔 range中只能传整数
   break continue else和while循环同理
   
   循环嵌套
   在一个循环内部再放置一个循环
   i循环 n次
   j循环 m次
   i循环内部嵌套j循环  n*m次

-作业：
-1.
"""
循环输入整数，当输入空字符时退出循环
求出这些数据的平均值
效果：
请输入整数：10
请输入整数：15
请输入整数：20
请输入整数：15
请输入整数：
这4个整数的平均值为：15
"""
sum = 0
count = 0
while True:
    num = input('请输入整数：')
    if not num:
        break
    sum += int(num)
    count += 1
print(f"这{count}个整数的平均值为：{sum / count}")

-2
"""
使用for循环遍历字符串"abaaeeaddaoaoea",统计字符串"a"的次数
"""
count = 0
for i in "abaaeeaddaoaoea":  # 遍历
    if i == "a":
        count += 1
print(count)


-3
"""
猜数字：电脑随机生成一个1-100区间的数字，一直提示让用户输出数字，如果比随机数大，则显示猜测的结果大了， 如果是比随机数小，则显示猜测的结果小了，只有输入数字等于随机数，显示猜测结果正确，然后退出循环
提示:
1.随机数使用random模块；
	import random
	a = random.randint(1, 100)
2.退出循环可以使用break关键字
效果：
=======================
	欢迎进入猜数字游戏
=======================	
请输入你的猜测：28
不好意思，再往大猜猜吧！
不好意思，再往小猜猜吧！
你太棒了！你猜了5次后通关！
"""
import random

a = random.randint(1, 100)
count = 0
print("""
=======================
	欢迎进入猜数字游戏
=======================	
""")
while True:
    get = int(input("请输入你的猜测："))
    count += 1
    if get < 0 or get > 100:
        print("您的输入有误，请正确输入！")
    elif get < a:
        print("不好意思，再往大猜猜吧！")
    elif get > a:
        print("不好意思，再往小猜猜吧！")
    else:
        print(f"你太棒了！你猜了{count}次后通关！")
        break


```

## 目标

```python
-序列介绍
	-索引
    -切片
    -其他共同操作
-字符串
	-内置方法
    -字符串格式化
```

## 1.序列介绍

在 Python 中，序列是一种有序的数据集合。常见的序列类型包括字符串、列表、元组。这些序列类型具有一些共同的特性和操作。

### 1.1索引访问：

索引访问是指通过索引位置来访问序列中的单个元素

```python
语法：	序列[索引值]
示例：
mess = "hello world"

# 正索引从0开始计数，访问从左到右的元素。
print(mess[0])
print(mess[10])
print(mess[4])

# 负索引从-1开始计数，访问从右到左的元素。
print(mess[-1])
print(mess[-5])

# 如果索引超出序列的范围，会引发IndexError错误。
# print(mess[11])

# 字符串只能通过索引取值，但是无法修改值
# mess[-1] = "a"

```

### 1.2切片操作: 

切片操作用于从序列中提取子序列（包头不包尾）

```python
语法：		序列[start:end:step]
mess = "hello world"

# 默认切片表示整个序列,start，默认为0
print(mess[:]) # 全切

# 仅指定start，从start开始到结尾
print(mess[4:])

# 仅指定end，从开头开始到end之前 不包含end，end默认为序列长度
print(mess[:4])  # 包头不包尾

# 同时指定start和end，从start开始到end之前
print(mess[1:4])

# 按step步长提取元素，step默认为1
print(mess[::2])

# step为负数，从右向左提取元素。
print(mess[::-1]) # 字符串的反转
print(mess[10::-1])
print(mess[10::-2])

# 字符串反转
print(mess[::-1])

```

练习：

> ```python
> 练习：
> 字符串： mess = "老王爱串门，喜欢吃饺子！"
> # 1.打印第一个字符、打印最后一个字符、打印中间字符
> print(mess[0])
> print(mess[-1])
> print(mess[1:-1])
> 
> # 2.打印字前三个符、打印后三个字符
> print(mess[:3])
> print(mess[-3:])
> 
> # 3.判断老王在字符串mess中
> print("老王" in mess)
> 
> # 4.通过切片打印"爱串门，喜欢吃"
> print(mess[2:-3])
> 
> # 5.通过切片打印“老串喜饺”
> print(mess[::3])
> 
> # 7.倒序打印字符
> print(mess[::-1])
> ```



### 1.3其他共同操作

| 操作             | 描述                                                         | 示例                                     |
| ---------------- | ------------------------------------------------------------ | ---------------------------------------- |
| 长度获取         | 使用内置函数 `len()` 来获取序列的长度                        | `len(sequence)`                          |
| 成员检查         | 使用关键字 `in` 来检查一个元素是否存在于序列中               | `element in sequence`                    |
| 连接操作         | 使用加号 `+` 来连接两个序列，生成一个新的序列                | `sequence1 + sequence2`                  |
| 重复操作         | 使用乘号 `*` 来重复序列中的元素，生成一个新的序列            | `sequence * n`                           |
| 迭代             | 使用 `for` 循环来遍历序列中的元素                            | `for element in sequence:`               |
| 元素查找         | 使用 `index()` 方法来查找指定元素在序列中的索引。如果元素不存在，会引发 `ValueError` 错误 | `sequence.index("3")`                    |
| 计数元素出现次数 | 使用 `count()` 方法来统计指定元素在序列中出现的次数          | `sequence.count("2")`                    |
| 最值获取         | 使用内置函数 `max()` 和 `min()` 来获取序列中的最大值和最小值 | `max(sequence)`和`min(sequence)`         |
| 排序操作         | 使用内置函数 `sorted()` 对序列进行排序，生成一个新的排序后的序列 | `sorted(sequence，reverse=True)`默认升序 |

```python
mess01 = "hello world"
mess02 = "beautiful world"
# 长度获取:使用内置函数  len()  来获取序列的长度
print(len(mess01))

# 成员检查:使用关键字 in 来检查一个元素是否存在于序列中
print("he" in mess01)

# 连接操作:使用加号 + 来连接两个序列，生成一个新的序列
print(mess01 + mess02)

# 重复操作:使用乘号 * 来重复序列中的元素，生成一个新的序列
print(mess01 * 3)

# 迭代:使用 for 循环来遍历序列中的元素
for i in mess01:
    print(i, end="-")
print()

# 元素查找：使用 index() 方法来查找指定元素在序列中的索引。如果元素不存在，会引发 ValueError 错误
print(mess01.index("l"))
# print(mess01.index("z"))

# 计数元素出现次数:使用 count() 方法来统计指定元素在序列中出现的次数。
print(mess01.count("l"))

# 最值获取:使用内置函数 max() 和 min() 来获取序列中的最大值和最小值
list01 = [1, 2, 16, 31, 100, 7, 8]  # 列表
print(max(list01))
print(min(list01))

# 排序操作:使用内置函数 sorted() 对序列进行排序，生成一个新的排序后的序列
print(sorted(list01)) # 生成了一个新的列表
print(sorted(list01, reverse=True)) # 生成了一个新的列表


```

## 2.字符串

### 2.1内置方法

我们在开发程序时需要频繁对数据进行操作，为了提升我们的开发效率， python 针对这些常用的操作，为每一种数据类型内置了一系列方法

| 方法           | 说明                                                         | 示例                           | 返回值               |
| -------------- | ------------------------------------------------------------ | ------------------------------ | -------------------- |
| `startswith()` | 检查字符串是否以指定的子字符串开头，返回布尔值               | `"Hello".startswith("He")`     | `True`               |
| `endswith()`   | 检查字符串是否以指定的子字符串结尾，返回布尔值               | `"Hello".endswith("lo")`       | `True`               |
| `isdigit()`    | 检查字符串是否只包含数字字符，返回布尔值                     | `"123".isdigit()`              | `True`               |
| `strip()`      | 去除字符串两端的空格（或指定的字符）                         | `" hello ".strip()`            | `"hello"`            |
| `lower()`      | 将字符串转换为小写形式                                       | `"Hello".lower()`              | `"hello"`            |
| `upper()`      | 将字符串转换为大写形式                                       | `"Hello".upper()`              | `"HELLO"`            |
| `replace()`    | 将字符串中的指定子字符串替换为新的字符串                     | `"Hello".replace("H", "J")`    | `"Jello"`            |
| `find()`       | 查找指定子字符串在字符串中的索引位置，如果找到返回索引值，否则返回-1 | `"Hello".find("l")`            | `2`                  |
| `split()`      | 将字符串按照指定的分隔符分割成子字符串，并返回一个包含子字符串的列表 | `"Hello,World".split(",")`     | `["Hello", "World"]` |
| `join()`       | 将一个包含字符串的可迭代对象（如列表）连接成一个字符串，使用指定的连接符 | `"-".join(["Hello", "World"])` | `"Hello-World"`      |

```python
mess = "老王爱串门，喜欢吃饺子！"
# startswith() : 检查字符串是否以指定的子字符串开头，返回布尔值。
if mess.startswith("老"):
    print("关门，放狗！")

# endswith() : 检查字符串是否以指定的子字符串结尾，返回布尔值。
if mess.endswith("饺子！"):
    print("干饭")

# isdigit() : 检查字符串是否只包含数字字符，返回布尔值。
mess01 = "123131231"
if mess01.isdigit():
    print("全是数字")

# strip() : 去除字符串两端的空格，换行符，制表符（或指定的字符）
print(mess.strip("！"))

# lower() : 将字符串转换为小写形式
# upper() : 将字符串转换为大写形式
mess02 = "My name is LaoWang!"
print(mess02.lower())
print(mess02.upper())

# replace() : 将字符串中的指定子字符串替换为新的字符串
print(mess.replace("饺子", "包子"))
print(mess)

# find() : 查找指定子字符串在字符串中的索引位置，如果找到返回索引值，否则返回-1
print(mess.find("爱"))
print(mess.find("小"))

# split() : 将字符串按照指定的分隔符分割成子字符串，并返回一个包含子字符串的列表。
print(mess.split("，"))

# join() : 将一个包含字符串的可迭代对象（如列表）连接成一个字符串，使用指定的连接符
print("-->".join(['老王爱串门', '喜欢吃饺子！']))

```

### 2.2字符串格式化

字符串格式化是将变量的值插入到字符串中的一种方法。这样可以更简洁和动态地生成包含变量的字符串。

- 百分号`%`格式化:在字符串中使用百分号作为占位符，并使用对应的值进行替换

```python
- %s：字符串占位符。
- %d：整数占位符。
- %f：浮点数占位符，默认保留6位小数
	%.1f:保留一位小数
    %.2f:保留两位小数
语法：
"xx%sxx%dxxx%f" % (数据1，数据2，数据3)
注意：%方法需要写在引号内部

name = "老王"
age = 40
high = 185.0
# 普通写法
print("我叫" + name + "今年" + str(age) + "岁了,身高" + str(high))

# % 方法
print("我叫%s今年%d岁了,身高%f" % (name, age, high))
print("我叫%s今年%d岁了,身高%.2f" % (name, age, high))
print("我叫%s今年%d岁了,身高%.2f" % ("老王", 40, 185.0))

data01 = "我叫%s今年%d岁了,身高%.2f" % (name, age, high)
print(data01)

```

- `str.format()`方法是 Python 中较为现代且灵活的字符串格式化方法。它允许你在字符串中使用花括号 `{}` 作为占位符，然后通过 `format()` 方法来传递变量或值，并将它们插入到字符串中。

```python
语法：
"xx{}xx{}xx{}xx".format(数据1，数据2，数据3)

data02= "我叫{}今年{}岁了,身高{:.2f}".format(name, age, high)
print(data02)

```

- f-string` 是 Python 3.6 及更高版本引入的一种非常方便的字符串格式化方法。通过在字符串前加上字母 `f` 或 `F`，并在字符串中使用花括号 `{}` 来插入变量或表达式的值

```python
语法：
直接在字符串前加上F/f前缀，并在花括号{}内放入表达式

data03 = f"我叫{name}今年{age}岁了,身高{high:.2f}"
print(data03)

```

练习：

```python
exercise01:
"""
输入患病人数和治愈人数，并计算治愈率
要求：分别用占位符，format()，f-strings三种方式进行打印
	 治愈率保留两位小数
效果：
请输入患病人数：
请输入治愈人数：
京海市共确诊10000人，治愈9000人，治愈率为0.90。
"""    
unhealthy = int(input("请输入患病人数："))
healthy = int(input("请输入治愈人数："))
# 占位符
data01 = "京海市共确诊%d人，治愈%d人，治愈率为%.2f。" % (unhealthy, healthy, healthy / unhealthy)
print(data01)
# format()
data02 = "京海市共确诊{}人，治愈{}人，治愈率为{:.2f}。".format(unhealthy, healthy, healthy / unhealthy)
print(data02)
# f-strings
data03 = f"京海市共确诊{unhealthy}人，治愈{healthy}人，治愈率为{healthy / unhealthy:.2f}。"
print(data03)


exercise02:
"""
输入一个秒数，换算成时分秒进行输出
要求：分别用占位符，format()，f-strings三种方式进行打印
效果：
请输入秒数：3700
3700秒是1小时1分钟零40秒
"""   


```

## 作业

```python
-1
"""
message = "老王说：“我是要成为海贼王的男人！”"
	1.获取字符串长度
	2.通过range() + 索引方法打印出整个字符串
	3.切片方式打印出老王说的话
	4.倒叙输出整个字符串
"""

-2
"""
录入一句话
如果开头两个字是"老王"并且结尾为"敲门"，打印"老王来串门了！"
如果不是，打印"幸好不是老王！"
"""
```



