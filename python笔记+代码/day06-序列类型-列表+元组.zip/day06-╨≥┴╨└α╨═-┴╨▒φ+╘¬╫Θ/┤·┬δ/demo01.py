# 列表的创建
list01 = ["老虎", "大象", "狮子"]
print(list01)
list02 = list("老虎大象狮子")
print(list02)
list03 = list(range(1, 11))
print(list03)

# 列表添加元素
list01 = ["老虎", "大象", "狮子"]
list01.append("秃鹫")
print(list01)

list01.extend("猫头鹰")
print(list01)

list01.extend(["犀牛", "斑马"])
print(list01)

list01.insert(0, "长颈鹿")
print(list01)

# 删除列表元素
# --删除列表中第一个匹配的元素
# 列表名.remove(元素)
list01 = ["老虎", "大象", "狮子", "老虎"]
list01.remove("老虎")
print(list01)

# --删除并返回指定索引位置的元素。如果没有指定索引，默认删除并返回最后一个元素
# 被删除元素=列表名.pop(索引)
list02 = ["老虎", "大象", "狮子", "老虎"]
data01 = list02.pop(1) # 弹出
print(list02, data01)

data02 = list02.pop()
print(list02, data02)

# --删除列表中指定的一个或者多个元素
# del 列表名[索引或切片]
list03 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
del list03[1]
print(list03)

del list03[-2:]
print(list03)

# --清空列表中的所有元素，使列表变为空列表
# 列表名.clear()
list04 = ["老虎", "大象", "狮子", "老虎"]
list04.clear()
print(list04)

# 定位元素
# 查找
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
data01 = list01[1]
print(data01)

list02 = list01[-3:]
print(list02)

# 修改
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
list01[1] = "恐龙"
print(list01)

list01[-3:] = ["超人", "奥特曼", "猪猪侠", "老王"]
print(list01)

# 列表遍历
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
for i in list01:
    print(i)

for i in range(len(list01)-1, -1, -1):
    print(i)
    print(list01[i])

# 列表的元素排序
num_list = [100, 20, 30, 11, 33]
print(num_list)
num_list.sort()
print(num_list)
num_list.sort(reverse=True)
print(num_list)

list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
list01.sort()
print(list01)

list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
list01.reverse()
print(list01)

#
# 字符串--->列表
message = "老王，爱跳，广场舞"
list01 = list(message)
print(list01)
list02 = message.split("，")
print(list02)

#列表--->字符串
list01 = ["老王", "跳", "广场舞"]
message = "-->".join(list01)
print(message)

# 在list01中所有数字的个位存储list03
list01 = [12, 13, 14, 15]
list03 = []
for i in list01:
    list03.append(i % 10)
print(list03)
list03 = [i % 10 for i in list01]
print(list03)

# 生成11-20之间的数字平方
result = []
for i in range(11, 21):
    result.append(i ** 2)
print(result)
result = [i ** 2 for i in range(11, 21)]
print(result)

