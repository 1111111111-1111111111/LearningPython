tuple01 = ("饺子", "嫂子")
print(tuple01)
list01 = ["饺子", "嫂子"]
tuple02 = tuple(list01)
print(tuple02)

tuple01 = ("老王", "爱吃", "饺子", "嫂子")
print(tuple01[2])
print(tuple01[1:3])

tuple01 = ("老王", "爱吃", "饺子", "嫂子")
for item in tuple01:
    print(item)

for i in range(len(tuple01) - 1, -1, -1):
    print(tuple01[i])

tuple01 = ("老王", "爱吃", "饺子")
a, b, c = tuple01
print(a, b, c)
a, b, c = ["A", "B", "C"]
print(a, b, c)
a, b, c = "孙悟空"
print(a, b, c)
