"""
生成10--30之间能被3或者5整除的数字
[10, 12, 15, 18, 20, 21, 24, 25, 27]
"""
list01 = []
for i in range(10, 31):
    if i % 5 == 0:
        list01.append(i)
print(list01)
list01 = [i for i in range(10, 31) if i % 5 == 0]
print(list01)