# exercise02:
"""
输入一个秒数，换算成时分秒进行输出
要求：分别用占位符，format()，f-strings三种方式进行打印
效果：
请输入秒数：3700
3700秒是1小时1分钟零40秒
"""
time = int(input("请输入秒数："))
hour = time // 3600
minute = time % 3600 // 60
second = time % 3600 % 60
print("%d秒是%d小时%d分钟零%d秒" % (time, hour, minute, second))
print("{}秒是{}小时{}分钟零{}秒".format(time, hour, minute, second))
print(f"{time}秒是{hour}小时{minute}分钟零{second}秒")

# -1
"""
message = "老王说：“我是要成为海贼王的男人！”"
	1.获取字符串长度
	2.通过range() + 索引方法打印出整个字符串
	3.切片方式打印出老王说的话
	4.倒叙输出整个字符串
"""
message = "老王说：“我是要成为海贼王的男人！”"
# 1.获取字符串长度
print(len(message))

# 2.通过range() + 索引方法打印出整个字符串
for i in range(len(message)):
    print(message[i], end="-")
print()

# 3.切片方式打印出老王说的话
print(message[5:-1])  # index

# 4.倒叙输出整个字符串
print(message[::-1])

# -2
"""
录入一句话
如果开头两个字是"老王"并且结尾为"敲门"，打印"老王来串门了！"
如果不是，打印"幸好不是老王！"
"""
message = input("请输入你要说的话：")
if message.startswith("老王") and message.endswith("敲门"):
    print("老王来串门了！")
else:
    print("幸好不是老王！")

if message[:2] == "老王" and message[-2:] == "敲门":
    print("老王来串门了！")
else:
    print("幸好不是老王！")
