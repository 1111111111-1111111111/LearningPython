# 数据类型-序列

## 上节课回顾

```python
-序列介绍
	-索引
    	序列[索引值]
    -切片
    	序列[start:end:step]
    -其他共同操作
    	len()
        in not in
        + *
        for()循环遍历
        count()
        max() min()
        sorted(sequence，reverse=True)默认升序
-字符串
	-内置方法
    	startswith()
        endswith()
        isdigit()
        strip()
        lower() upper()
        replace()
        find()
        split()
        join()
    -字符串格式化
		%格式化
        format方法
        f-strings方法
-作业
# exercise02:
"""
输入一个秒数，换算成时分秒进行输出
要求：分别用占位符，format()，f-strings三种方式进行打印
效果：
请输入秒数：3700
3700秒是1小时1分钟零40秒
"""
time = int(input("请输入秒数："))
hour = time // 3600
minute = time % 3600 // 60
second = time % 3600 % 60
print("%d秒是%d小时%d分钟零%d秒" % (time, hour, minute, second))
print("{}秒是{}小时{}分钟零{}秒".format(time, hour, minute, second))
print(f"{time}秒是{hour}小时{minute}分钟零{second}秒")

# -1
"""
message = "老王说：“我是要成为海贼王的男人！”"
	1.获取字符串长度
	2.通过range() + 索引方法打印出整个字符串
	3.切片方式打印出老王说的话
	4.倒叙输出整个字符串
"""
message = "老王说：“我是要成为海贼王的男人！”"
# 1.获取字符串长度
print(len(message))

# 2.通过range() + 索引方法打印出整个字符串
for i in range(len(message)):
    print(message[i], end="-")
print()

# 3.切片方式打印出老王说的话
print(message[5:-1])  # index

# 4.倒叙输出整个字符串
print(message[::-1])

# -2
"""
录入一句话
如果开头两个字是"老王"并且结尾为"敲门"，打印"老王来串门了！"
如果不是，打印"幸好不是老王！"
"""
message = input("请输入你要说的话：")
if message.startswith("老王") and message.endswith("敲门"):
    print("老王来串门了！")
else:
    print("幸好不是老王！")

if message[:2] == "老王" and message[-2:] == "敲门":
    print("老王来串门了！")
else:
    print("幸好不是老王！")

```

## 目标

```python
-列表
	增删查改
    遍历
    推导式
-元组
	创建
    定位
    遍历
```

## 1.列表

在Python中，列表(List)是一种常用的数据类型，是一个**有序且可变**的容器，在里面可以存放多个不同类型的元素。列表会将所有元素都放在一对中括号`[ ]`里面，相邻元素之间用逗号`,`分隔。建议在列表中放置相同类型的数据，这样可以提高代码的可读性和维护性

- 字符串是不可变的，一旦创建后，字符串的内容就无法更改。这意味着对字符串的操作都会生成一个新的字符串对象，而不会修改原始字符串。这是由于字符串的不可变性质决定的。
- 列表是可变的，可以在创建后修改其中的元素。列表提供了许多内置方法和操作符，可以直接在列表上进行添加、删除、修改和重排序等操作，而无需创建新的列表对象。

### 1.1列表的创建

```python
语法：
列表名 = []
列表名 = list(可迭代对象) # 子符串会被分割为单个元素

list01 = ["老虎", "大象", "狮子"]
print(list01)
list02 = list("老虎大象狮子")
print(list02)
list03 = list(range(1, 11))
print(list03)

```

### 1.2列表添加元素

```python
语法：
列表名.append(元素) # 在列表末尾添加一个元素。
列表名.extend(可迭代对象) # 在列表末尾添加多个元素。
列表.insert(索引，元素) # 在指定索引位置插入一个元素

list01 = ["老虎", "大象", "狮子"]
list01.append("秃鹫")
print(list01)

list01.extend("猫头鹰")
print(list01)

list01.extend(["犀牛", "斑马"])
print(list01)

list01.insert(0, "长颈鹿")
print(list01)

```

### 1.3 列表删除元素

```python
语法：
# --删除列表中第一个匹配的元素
# 列表名.remove(元素)
list01 = ["老虎", "大象", "狮子", "老虎"]
list01.remove("老虎")
print(list01)

# --删除并返回指定索引位置的元素。如果没有指定索引，默认删除并返回最后一个元素
# 被删除元素=列表名.pop(索引)
list02 = ["老虎", "大象", "狮子", "老虎"]
data01 = list02.pop(1) # 弹出
print(list02, data01)

data02 = list02.pop()
print(list02, data02)

# --删除列表中指定的一个或者多个元素
# del 列表名[索引或切片]
list03 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
del list03[1]
print(list03)

del list03[-2:]
print(list03)

# --清空列表中的所有元素，使列表变为空列表
# 列表名.clear()
list04 = ["老虎", "大象", "狮子", "老虎"]
list04.clear()
print(list04)


```

### 1.4列表定位元素

```python
语法：
-查找：
	变量 = 列表名[索引]
	变量 = 列表名[切片] # 赋值给变量的是切片所创建的新列表
-修改：
	列表名[索引] = 元素
    列表名[切片] = 容器 # 右侧必须是可迭代对象，左侧切片没有创建新列表。

# 查找
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
data01 = list01[1]
print(data01)

list02 = list01[-3:]
print(list02)

# 修改
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
list01[1] = "恐龙"
print(list01)

list01[-3:] = ["超人", "奥特曼", "猪猪侠", "老王"]
print(list01)    
```

### 1.5列表遍历

```python
语法：
    正向：
        for 变量名 in 列表名:
        	变量名就是元素
    反向：
        for 索引名 in range(len(列表名)-1,-1,-1):
        	列表名[索引名]就是元素

list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
for i in list01:
    print(i)

for i in range(len(list01)-1, -1, -1):
    print(i)
    print(list01[i])            
```

### 1.6列表的元素排序

```python
语法：
	列表名.sort() # 对原来列表进行操作
    新列表名 = sorted(列表名) # 返回一个新列表

num_list = [100, 20, 30, 11, 33]
print(num_list)
num_list.sort()
print(num_list)
num_list.sort(reverse=True)
print(num_list)    

# 字符串排序
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
"""
sort的排序原理
1.先比较字符串第一个字符的unicode编码位置
2.字符串第一个字符一样的话，就比较第二个
3.如果前面相同，后面没有的字符就小
"""
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
list01.sort()
print(list01)
```

```python
语法：
	列表名.reverse() # 反转列表中的元素顺序
    
list01 = ["老虎", "大象", "狮子", "老虎", "斑马", "长颈鹿"]
list01.reverse()
print(list01)
    
```

练习5：

```python
八大行星："水星" "金星" "地球" "火星" "木星" "土星" "天王星" "海王星"
-- 创建列表存储4个行星："水星" "金星" "火星" "木星"
-- 插入"地球"、追加"土星" "天王星" "海王星"
-- 打印距离太阳最近、最远的行星(第一个和最后一个元素)
-- 打印太阳到地球之间的行星(前两个行星)
-- 删除"海王星",删除第四个行星
-- 倒序打印所有行星(一行一个)

# -- 创建列表存储4个行星："水星" "金星" "火星" "木星"
list01 = ["水星", "金星", "火星", "木星"]
print(list01)
# -- 插入"地球"、追加"土星" "天王星" "海王星"
list01.insert(2, "地球")
print(list01)
list01.extend(["土星", "天王星", "海王星"])
print(list01)

# -- 打印距离太阳最近、最远的行星(第一个和最后一个元素)
print(list01[0])
print(list01[-1])

# -- 打印太阳到地球之间的行星(前两个行星)
print(list01[:2])

# -- 删除"海王星",删除第四个行星
list01.remove("海王星")
del list01[3]
print(list01)

# -- 倒序打印所有行星(一行一个
for i in range(len(list01)-1, -1, -1):
    print(list01[i])
```

### 1.7深拷贝和浅拷贝

```python
浅拷贝：复制过程中,只复制一层变量,不会复制深层变量绑定的对象的复制过程。
深拷贝：复制整个依懒的变量
import copy
list01 = ["北京",["上海","深圳"]]
list02 = list01
list03 = list01[:]
list04 = copy.deepcopy(list01)
list04[0] = "北京04"
list04[1][1] = "深圳04"
print(list01) # ?

list03[0] = "北京03"
list03[1][1] = "深圳03"
print(list01) # ?

list02[0] = "北京02"
list02[1][1] = "深圳02"
print(list01) # ?
```

![1750945405994](C:\Users\EDY\AppData\Roaming\Typora\typora-user-images\1750945405994.png)

### 1.8列表与字符串转换

```python
# 字符串--->列表
message = "老王，爱跳，广场舞"
list01 = list(message)
print(list01)
list02 = message.split("，")
print(list02)

#列表--->字符串
list01 = ["老王", "跳", "广场舞"]
message = "-->".join(list01)
print(message)
```

### 1.9列表推导式

```python
语法：
变量 = [表达式 for 变量 in 可迭代对象 if 条件]

# 在list01中所有数字的个位存储list03
list01 = [12, 13, 14, 15]
list03 = []
for i in list01:
    list03.append(i % 10)
print(list03)
list03 = [i % 10 for i in list01]
print(list03)

# 生成11-20之间的数字平方
result = []
for i in range(11, 21):
    result.append(i ** 2)
print(result)
result = [i ** 2 for i in range(11, 21)]
print(result)
```

练习：

```python
"""
生成10--30之间能被3或者5整除的数字
[10, 12, 15, 18, 20, 21, 24, 25, 27]
"""

list01 = []
for i in range(10, 31):
    if i % 5 == 0:
        list01.append(i)
print(list01)
list01 = [i for i in range(10, 31) if i % 5 == 0]
print(list01)
```

## 2元组

元组(`tuple`)，是一个有序且**不可变**的容器，在里面可以存放多个不同类型的元素

### 2.1元组的创建

```python
语法：
	-根据元素创建：元组名=(元素,元素,元素 )
    			 元组名=tuple()
注意：当创建的元组中只有一个字符串类型的元素时，该元素后面必须要加一个逗号
	例：
    	tuple = ("1",)
	-根据可迭代创建：tuple01=tuple(list01)
    
tuple01 = ("饺子", "嫂子")
print(tuple01)
list01 = ["饺子", "嫂子"]
tuple02 = tuple(list01)
print(tuple02)
    
```

### 2.2定位

```python
语法：
	-索引：元组名[索引]
	-切片：元组名[索引： 索引： 索引]

tuple01 = ("老王", "爱吃", "饺子", "嫂子")
print(tuple01[2])
print(tuple01[1:3])
    
```

### 2.3遍历

```python
语法：
    正向：
        for 变量名 in 元组名:
        	变量名就是元素
    反向：
        for 索引名 in range(len(元组名)-1,-1,-1):
        	元组名[索引名]就是元素

tuple01 = ("老王", "爱吃", "饺子", "嫂子")
for item in tuple01:
    print(item)

for i in range(len(tuple01)-1, -1, -1):
    print(tuple01[i])            
```

### 2.4特殊

```python
-元组创建时可以省略()
tuple01 = 10, 20, 30


-拆包: 多个变量 = 容器
tuple01 = ("老王", "爱吃", "饺子")
a, b, c = tuple01
print(a, b, c)
a, b, c = ["A", "B", "C"]
print(a, b, c)
a, b, c = "孙悟空"
print(a, b, c)
    
```

## 3.列表与元组的对比

- 元组与列表都可以存储一系列变量，由于列表会**预留**内存**空间**，所以可以增加元素
- 元组会**按需分配**内存，所以如果变量数量固定，建议使用元组，因为占用空间更小

## 作业

```python
exercise01:
"""
根据月日,计算是这一年的第几天.
公式：前几个月总天数 + 当月天数
例如：5月10日
计算：31 29 31 30 + 10
"""   

exercise02:
"""
将列表 num_list = [1,2,3,4,5,6,7,8,9,10] 里面的偶数添加到一个新列表中，并输出出来
扩展：使用列表推导式
"""   

exercise03:
"""
现有列表cities存放城市名称，但内容存在些许错误，请按照要求进行修改。
cities = ["北京", "南昌", "波士顿", "深圳", "湖南", "成都", "洛杉矶", "武汉", "浙江", "香港", "澳门"]
要求：
一、在北京和南昌中间插入上海；
二、删除不属于中国的城市；
三、将省份名称改为其省会城市；
四、在末尾加上台北
""" 

exercise04:
"""
有列表 li = [1, "A", 2, "b", 3, "c", 4, "d"],通过列表的切片，切出[1, 2, 3, 4]并输出
拓展：使用列表推导式
"""
```











