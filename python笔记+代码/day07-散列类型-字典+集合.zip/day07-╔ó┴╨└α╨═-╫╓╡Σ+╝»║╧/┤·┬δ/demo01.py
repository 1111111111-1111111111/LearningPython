# 字典的创建
person = {"name": "老王", "age": 40, "like": "饺子"}
print(person)

person = dict(name="老王", age=40, like="饺子")
print(person)

person = dict([("name", "老王"), ("age", 40), ("like", "饺子")])
print(person)

# 定位
person = {"name": "老王", "age": 40, "like": "饺子"}
name = person["name"]
print(name)

# get() 安全的访问字典中的键
print(person.get("name"))
print(person.get("sex"))

person["age"] = 41
person["address"] = "北京"
print(person)

# 删除元素
person = {"name": "老王", "age": 40, "like": "饺子"}
age = person.pop("age")
print(age)
print(person)

del person["like"]
print(person)

# 遍历字典
person = {"name": "老王", "age": 40, "like": "饺子"}
for key in person:
    print(key)

for value in person.values():
    print(value)

for item in person.items():
    print(item, item[0], item[1])

for key, value in person.items():
    print(key, value)

# 字典推导式
# 生成一个数字及其平方的字典
dict01 = {}  # 空字典
for i in range(1, 10):
    if i % 2 == 0:
        dict01[i] = i * i
print(dict01)

dict02 = {i: i * i for i in range(1, 10) if i % 2 == 0}
print(dict02)
