# 创建
set01 = {"悟空", "八戒", "唐僧"}
print(set01)
list01 = ["悟空", "八戒", "唐僧", "悟空", "八戒"]

set02 = set(list01)  # 去重
print(set02)

dict03 = {}
set04 = set()

# 集合的添加
set01 = {"悟空", "八戒", "唐僧"}
set01.add("白龙马")
print(set01)

set01.update(["金角大王", "银角大王"])
print(set01)

# 集合的删除
set01 = {'小白龙', '金角大王', '银角大王', '八戒', '唐僧', '悟空'}
set01.remove("悟空")
print(set01)
# set01.remove("六耳猕猴")
# print(set01)
set01.discard("六耳猕猴")
print(set01)

# 集合的遍历
set01 = {'小白龙', '八戒', '唐僧', '悟空'}
for i in set01:
    print(i)

# 集合推导式
list01 = ['小白龙', '唐僧', '悟空', '八戒', '唐僧', '悟空']
set01 = set()
for i in list01:
    set01.add(i)
print(set01)
set01 = {i for i in list01}
print(set01)
