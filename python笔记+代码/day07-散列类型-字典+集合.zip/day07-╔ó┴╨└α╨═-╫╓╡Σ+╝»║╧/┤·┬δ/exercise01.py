# exercise01:
"""将两个列表，合并为一个字典
姓名列表["张无忌","赵敏","周芷若"]
房间列表[101,102,103]
{101: '张无忌', 102: '赵敏', 103: '周芷若'}
"""
name_list = ["张无忌", "赵敏", "周芷若"]
number_list = [101, 102, 103]
dict01 = {}
for i in range(3):
    dict01[number_list[i]] = name_list[i]
print(dict01)

dict02 = {number_list[i]: name_list[i] for i in range(3)}
print(dict02)

# exercise02：
"""颠倒练习1字典键值
{'张无忌': 101, '赵敏': 102, '周芷若': 103}
"""
dict03 = {}
for k, v in dict02.items():
    dict03[v] = k
print(dict03)



