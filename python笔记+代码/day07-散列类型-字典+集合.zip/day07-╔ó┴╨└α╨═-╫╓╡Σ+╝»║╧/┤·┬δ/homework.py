# exercise01:
"""
根据月日,计算是这一年的第几天.2月算29天
公式：前几个月总天数 + 当月天数
例如：5月10日
计算：31 29 31 30 + 10
"""
# tuple_days = (31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
# month = int(input("请输入月份："))
# days = int(input("请输入日："))
# total_days = 0
# for i in range(month - 1):
#     total_days += tuple_days[i]
# total_days += days
# print(f"{month}月{days}日是一年当中的第{total_days}天")

# exercise02:
"""
将列表 num_list = [1,2,3,4,5,6,7,8,9,10] 里面的偶数添加到一个新列表中，并输出出来
扩展：使用列表推导式
"""
num_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
new_list = []
for i in num_list:
    if i % 2 == 0:
        new_list.append(i)
print(new_list)
new_list = [i for i in num_list if i % 2 == 0]
print(new_list)

# exercise03:
"""
现有列表cities存放城市名称，但内容存在些许错误，请按照要求进行修改。
cities = ["北京", "南昌", "波士顿", "深圳", "湖南", "成都", "洛杉矶", "武汉", "浙江", "香港", "澳门"]
要求：
一、在北京和南昌中间插入上海；
二、删除不属于中国的城市；
三、将省份名称改为其省会城市；
四、在末尾加上台北
"""
cities = ["北京", "南昌", "波士顿", "深圳", "湖南", "成都", "洛杉矶", "武汉", "浙江", "香港", "澳门"]
# 一、在北京和南昌中间插入上海；
cities.insert(1, "上海")
print(cities)

# 二、删除不属于中国的城市；
cities.remove("波士顿")
del cities[cities.index("洛杉矶")]
print(cities)

# 三、将省份名称改为其省会城市；
cities[4] = "长沙"
cities[cities.index("浙江")] = "杭州"
print(cities)

# 四、在末尾加上台北
cities.append("台北")
print(cities)

# exercise04:
"""
有列表 li = [1, "A", 2, "b", 3, "c", 4, "d"],通过列表的切片，切出[1, 2, 3, 4]并输出
拓展：使用列表推导式
"""
li = [1, "A", 2, "b", 3, "c", 4, "d"]
newlist = []
for i in range(len(li)):
    if type(li[i]) == int:
        newlist.append(li[i])
print(newlist)
print(li[::2])













