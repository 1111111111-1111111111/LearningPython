# 数据类型-散列

## 上节课回顾

```python
-列表
	增删查改
    遍历
    推导式
-元组
	创建
    定位
    遍历
    
-作业
exercise01:
"""
根据月日,计算是这一年的第几天.2月算29天
公式：前几个月总天数 + 当月天数
例如：5月10日
计算：31 29 31 30 + 10
"""   
tuple_days = (31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
month = int(input("请输入月份："))
days = int(input("请输入日："))
total_days = 0
for i in range(month - 1):
    total_days += tuple_days[i]
total_days += days
print(f"{month}月{days}日是一年当中的第{total_days}天")

exercise02:
"""
将列表 num_list = [1,2,3,4,5,6,7,8,9,10] 里面的偶数添加到一个新列表中，并输出出来
扩展：使用列表推导式
"""   
num_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
new_list = []
for i in num_list:
    if i % 2 == 0:
        new_list.append(i)
print(new_list)
new_list = [i for i in num_list if i % 2 == 0]
print(new_list)

exercise03:
"""
现有列表cities存放城市名称，但内容存在些许错误，请按照要求进行修改。
cities = ["北京", "南昌", "波士顿", "深圳", "湖南", "成都", "洛杉矶", "武汉", "浙江", "香港", "澳门"]
要求：
一、在北京和南昌中间插入上海；
二、删除不属于中国的城市；
三、将省份名称改为其省会城市；
四、在末尾加上台北
""" 
cities = ["北京", "南昌", "波士顿", "深圳", "湖南", "成都", "洛杉矶", "武汉", "浙江", "香港", "澳门"]
# 一、在北京和南昌中间插入上海；
cities.insert(1, "上海")
print(cities)

# 二、删除不属于中国的城市；
cities.remove("波士顿")
del cities[cities.index("洛杉矶")]
print(cities)

# 三、将省份名称改为其省会城市；
cities[4] = "长沙"
cities[cities.index("浙江")] = "杭州"
print(cities)

# 四、在末尾加上台北
cities.append("台北")
print(cities)

exercise04:
"""
有列表 li = [1, "A", 2, "b", 3, "c", 4, "d"],通过列表的切片，切出[1, 2, 3, 4]并输出
拓展：使用列表推导式
"""
li = [1, "A", 2, "b", 3, "c", 4, "d"]
newlist = []
for i in range(len(li)):
    if type(li[i]) == int:
        newlist.append(li[i])
print(newlist)
print(li[::2])

```

## 目标

散列类型是通过使用散列函数来实现的一种数据类型，非常适合需要高效处理大量数据的情况。散列函数的作用是将输入转换为固定大小的哈希值。这些哈希值用于在内存中确定数据的存储位置。这种机制使得查找、插入和删除操作非常高效

```python
-字典
	字典的创建
    定位
    删除
    遍历
    推导式
-集合
	集合的创建
    增删查改
    遍历
    集合的运算
    集合推导式
-综合性练习
```

## 1.字典

- 由一系列**键值对**组成的可变散列容器。
- 散列：对键进行哈希运算，确定在内存中的存储位置，每条数据存储无先后顺序。
- 键必须惟一且不可变(字符串/数字/元组)，值没有限制。

### 1.1字典的创建

```python
语法：
    字典名 = {键1：值1，键2：值2}
    字典名 = dict (可迭代对象)
    
person = {"name": "老王", "age": 40, "like": "饺子"}
print(person)

person = dict(name="老王", age=40, like="饺子")
print(person)

person = dict([("name", "老王"), ("age", 40), ("like", "饺子")])
print(person)
    
```

### 1.2定位

```python
语法：
	#添加/修改元素
	字典名[键] = 数据
    注意：
        键不存在，创建记录。
        键存在，修改值
    #获取元素
    变量 = 字典名[键]  # 没有键则错误

person = {"name": "老王", "age": 40, "like": "饺子"}
name = person["name"]
print(name)

# get() 安全的访问字典中的键
print(person.get("name"))
print(person.get("sex"))

person["age"] = 41
person["address"] = "北京"
print(person)
    

```

### 1.3删除元素

```python
语法：
	del 字典名[键]	
	被删除的值 = pop("键")
    
person = {"name": "老王", "age": 40, "like": "饺子"}
age = person.pop("age")
print(age)
print(person)

del person["like"]
print(person)
    
```

### 1.4遍历字典

```python
语法：
	# 获取键
	for key in 字典名：
	# 获取值
    for value in 字典名.values():
	# 获取键值,打印为元组形式
    for item in 字典名.items():
	# 获取键值
    for k,v in 字典名.items():	
        
person = {"name": "老王", "age": 40, "like": "饺子"}
for key in person:
    print(key)

for value in person.values():
    print(value)

for item in person.items():
    print(item, item[0], item[1])

for key, value in person.items():
    print(key, value)
        
```

### 1.5字典推导式

```python
语法：
	新字典={变量：变量 for 变量 in 可迭代对象 if 条件}

# 生成一个数字及其平方的字典
dict01 = {}  # 空字典
for i in range(1, 10):
    if i % 2 == 0:
        dict01[i] = i * i
print(dict01)

dict02 = {i: i * i for i in range(1, 10) if i % 2 == 0}
print(dict02)

```

练习：

```python
exercise01:
"""将两个列表，合并为一个字典
姓名列表["张无忌","赵敏","周芷若"]
房间列表[101,102,103]
{101: '张无忌', 102: '赵敏', 103: '周芷若'}
"""
name_list = ["张无忌", "赵敏", "周芷若"]
number_list = [101, 102, 103]
dict01 = {}
for i in range(3):
    dict01[number_list[i]] = name_list[i]
print(dict01)

dict02 = {number_list[i]: name_list[i] for i in range(3)}
print(dict02)


exercise02：
"""颠倒练习1字典键值
{'张无忌': 101, '赵敏': 102, '周芷若': 103}
"""
dict03 = {}
for k, v in dict02.items():
    dict03[v] = k
print(dict03)

```

## 2.集合

- 集合（`set`）是一种**无序的、不重复**的数据集合

### 2.1集合的创建

```python
语法：
	set01={元素，元素，元素}
	set02=set(可迭代数据)
    
set01 = {"悟空", "八戒", "唐僧"}
print(set01)
list01 = ["悟空", "八戒", "唐僧", "悟空", "八戒"]

set02 = set(list01)  # 去重
print(set02)
    
```

### 2.2集合的添加

```python
语法：
	集合名.add(元素) # 添加单个元素
    集合名.update(可迭代对象) # 添加多个元素
    
set01 = {"悟空", "八戒", "唐僧"}
set01.add("白龙马")
print(set01)

set01.update(["金角大王", "银角大王"])
print(set01)
    
```

### 2.3集合的删除

```python
语法：
	集合名.remove(元素) # 不存在会报错
    集合名.discard(元素) # 不存在不报错
    
set01 = {'小白龙', '金角大王', '银角大王', '八戒', '唐僧', '悟空'}
set01.remove("悟空")
print(set01)
# set01.remove("六耳猕猴")
# print(set01)
set01.discard("六耳猕猴")
print(set01)
    
```

### 2.4集合的遍历

```python
语法：
	for item in 集合名:
        
set01 = {'小白龙', '八戒', '唐僧', '悟空'}
for i in set01:
    print(i)
        
```

### 2.5集合的运算

```python
- 交集 & == intersection() ：返回共同元素

s1 = {1, 2, 3}
s2 = {2, 3, 4}

# 使用 & 符号计算交集
s3 = s1 & s2
print(s3)  # 输出: {2, 3}

# 使用 intersection() 方法计算交集
s3 = s1.intersection(s2)
print(s3)  # 输出: {2, 3}
```

```python
- 并集 | ==union() ：返回不重复元素

s1 = {1, 2, 3}
s2 = {2, 3, 4}

# 使用 | 符号计算并集
s3 = s1 | s2
print(s3)  # 输出: {1, 2, 3, 4}

# 使用 union() 方法计算并集
s3 = s1.union(s2)
print(s3)  # 输出: {1, 2, 3, 4}
```

```python
- 差集 - == difference() ：返回只属于其中之一的元素

s1 = {1, 2, 3}
s2 = {2, 3, 4}

# 使用 - 符号计算差集
s3 = s1 - s2 # 属于s1但不属于s2
print(s3)  # 输出: {1}

# 使用 difference() 方法计算差集
s3 = s1.difference(s2)
print(s3)  # 输出: {1}
```

```python
-  补集 ^ == symmetric_difference() ：返回不同的的元素

s1 = {1, 2, 3}
s2 = {2, 3, 4}

# 使用 ^ 符号计算对称差集
s3 = s1 ^ s2
print(s3)  # 输出: {1, 4}

# 使用 symmetric_difference() 方法计算对称差集
s3 = s1.symmetric_difference(s2)
print(s3)  # 输出: {1, 4}
```

```python
- 子集 < ：判断一个集合的所有元素是否完全在另一个集合中
- 超集 > ：判断一个集合是否具有另一个集合的所有元素

s1 = {1, 2, 3}
s2 = {2, 3}
s2 < s1 # True
s1 > s2 # True

- 相同或不同 == != ：判断集合中的所有元素是否和另一个集合相同

s1 = {1, 2, 3}
s2 = {2, 3}
s2 == s1 # False
s1 != s2 # True
```



### 2.6集合推导式

```python
语法：
	集合名 = {表达式 for 变量 in 可迭代对象 if 条件}
    
list01 = ['小白龙', '唐僧', '悟空', '八戒', '唐僧', '悟空']
set01 = set()
for i in list01:
    set01.add(i)
print(set01)
set01 = {i for i in list01}
print(set01)    

```

## 3.容器综合练习

```python
exercise01:
"""
二维列表
list01 = [
    [1, 2, 3, 4, 5],
	[6, 7, 8, 9, 10],
	[11, 12, 13, 14, 15]
]
1. 将第一行从左到右逐行打印
效果：
1
2
3
4
5
2. 将第二行从右到左逐行打印
效果：
10
9
8
7
6
3. 将第三列从上到下逐个打印
效果：
3
8
13
4. 将第四列从下到上逐个打印
效果：
14
9
4
5. 将二维列表以表格状打印
效果：
1 2 3 4 5
6 7 8 9 10
11 12 13 14 15		
"""    
list01 = [
    [1, 2, 3, 4, 5],
    [6, 7, 8, 9, 10],
    [11, 12, 13, 14, 15]
]
#1. 将第一行从左到右逐行打印
for i in list01[0]:
    print(i)

#2. 将第二行从右到左逐行打印
for i in range(len(list01[1]) - 1, -1, -1):
    print(list01[1][i])

#3. 将第三列从上到下逐个打印
for i in range(len(list01)):
    print(list01[i][2])

#4. 将第四列从下到上逐个打印
for i in range(len(list01) - 1, -1, -1):
    print(list01[i][3])

#5. 将二维列表以表格状打印
for item in list01:
    for i in item:
        print(i, end='\t')
    print()  # 换行



exercise02:
"""
多个人的多个爱好
dict_hobbies = {
 "于谦": ["抽烟", "喝酒", "烫头"],
 "郭德纲": ["说", "学", "逗", "唱"],
}
1. 打印于谦的所有爱好(一行一个)
效果：
抽烟
喝酒
烫头
2. 计算郭德纲所有爱好数量
效果：4
3. 打印所有人(一行一个)
效果：
于谦
郭德纲
4. 打印所有爱好(一行一个)
抽烟
喝酒
烫头
说
学
逗
唱
"""  
dict_hobbies = {
    "许航": ["抽烟", "喝酒", "烫头"],
    "郭德纲": ["说", "学", "逗", "唱"],
}
# 1. 打印许航的所有爱好(一行一个)
for item in dict_hobbies["许航"]:
    print(item)

# 2. 计算郭德纲所有爱好数量
print(len(dict_hobbies["郭德纲"]))

# 3. 打印所有人(一行一个)
for key in dict_hobbies:
    print(key)

# 4. 打印所有爱好(一行一个)
for value in dict_hobbies.values():
    for item in value:
        print(item)



exercise03:
"""
dict_travel_info = {
    "北京": {
        "景区": ["长城", "故宫"],
        "美食": ["烤鸭", "豆汁焦圈", "炸酱面"]
    },
    "四川": {
        "景区": ["九寨沟", "峨眉山"],
        "美食": ["火锅", "兔头"]
    }
}
1. 打印北京的第一个景区
效果：
长城
2. 打印四川的第二个美食
效果：兔头
3. 所有城市 (一行一个)
效果：
北京
四川
4. 北京所有美食(一行一个)
效果：
烤鸭
豆汁焦圈
炸酱面
5. 打印所有城市的所有美食(一行一个)
效果：
烤鸭
豆汁焦圈
炸酱面
火锅
兔头
"""    
dict_travel_info = {
    "北京": {
        "景区": ["长城", "故宫"],
        "美食": ["烤鸭", "豆汁焦圈", "炸酱面"]
    },
    "四川": {
        "景区": ["九寨沟", "峨眉山"],
        "美食": ["火锅", "兔头"]
    }
}  
# 1. 打印北京的第一个景区
print(dict_travel_info["北京"]["景区"][0])

# 2. 打印四川的第二个美食
print(dict_travel_info["四川"]["美食"][1])

# 3. 所有城市 (一行一个)
for key in dict_travel_info:
    print(key)

# 4. 北京所有美食(一行一个)
for item in dict_travel_info["北京"]["美食"]:
    print(item)

# 5. 打印所有城市的所有美食(一行一个)
for value in dict_travel_info.values():
    for item in value["美食"]:
        print(item)


 
```

## 作业

```python
exercise01:
"""
# 商品字典
dict_commodity_infos = {
 1001: {"name": "屠龙刀", "price": 10000},
 1002: {"name": "倚天剑", "price": 10000},
 1003: {"name": "金箍棒", "price": 52100},
 1004: {"name": "口罩", "price": 20},
 1005: {"name": "酒精", "price": 30},
}
# 订单列表
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
1. 打印所有商品信息,
格式：商品编号xx,商品名称xx,商品单价xx.
2. 打印所有订单中的信息,
格式：商品编号xx,购买数量xx.
3. 打印所有订单中的商品信息,
格式：商品名称xx,商品单价:xx,数量xx.
4. 查找数量最多的订单(使用自定义算法,不使用内置函数)
5. 根据购买数量对订单列表降序(大->小)排列
"""    

exercise02:
"""
写程序：循环提示用户输入的游戏角色，将输入的角色名存储到集合中；如果出现输入过的角色，则提示已经记录；输入空的话，退出程序
"""    
```

