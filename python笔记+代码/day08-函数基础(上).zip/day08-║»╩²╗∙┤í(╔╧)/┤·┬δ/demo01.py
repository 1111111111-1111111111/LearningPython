def add(a, b):
    print(a + b)

data01 = 5
data02 = 6
add(data01, data02)
print(add)

# 位置传参
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)

func01(1, 2, 3)

# 序列传参
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)
# 拆包
list01 = [1, 2, 3]
name = "孙悟空"
tuple01 = (4, 5, 6)
func01(*list01)
func01(*name)
func01(*tuple01)
func01(list01, name, tuple01)

# 关键字传参
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)

func01(p1 = 1, p3 = 2, p2 = 3)

# 字典关键字传参
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)

dict01 = {"p2": 3, "p1": 999,"p3": 80000}
func01(**dict01)