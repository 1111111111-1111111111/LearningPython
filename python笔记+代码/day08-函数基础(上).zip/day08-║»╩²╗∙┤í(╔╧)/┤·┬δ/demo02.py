# 缺省形参(默认参数):
def func01(p1=2000, p2="老王", p3=100):
    print(p1, p2, p3)


func01(1, 2, 3)
func01(p2="小明")
# 支持位置传参和关键字传参同时使用
func01(10, p3="小明")


# func01(p1 = 10, 2 , 3) # 报错


# 星号元组形参
def func01(*args):
    print(args)


func01()
func01(1, 2, 3, 4)
func01(1, 2, 3, 4, 56, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18)


# 命名关键字形参
def func01(*args, p1, p2):
    print(args)
    print(p1, p2)


func01(1, 2, p1=3, p2=4)
func01(p1=3, p2=4)


def func02(*, p1, p2):
    print(p1, p2)


func02(p1=1, p2=2)

# 双星号字典形参
def func03(**kwargs):
    print(kwargs)

func03(a=1,b=2)












