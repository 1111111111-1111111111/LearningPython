def func01(list01):
    print(list01)


def func02(*args):
    print(args)


def func03(*args, **kwargs):
    print(args)
    print(kwargs)


# 位置形参 --> 星号元组形参 --> 命名关键字形参 --> 双星号字典形参
def func04(p1, p2, *args, p3=False, **kwargs):
    print(p1, p2)
    print(args)
    print(p3)
    print(kwargs)


func01([1, 2, 3])
func02(*[1, 2, 3])
func03(1, 2, 3, a="老王", b="串门")
func04(1, 2, 3, 4, 5, 6, 7, 8, a="老王", b="串门")
