"""
定义函数，根据传入的整数值来打印“老王串门”文本的次数
"""


def txt(n):
    print("老王串门" * n)


txt(5)

"""
定义函数,根据小时、分钟、秒,计算总秒数
调用：提供小时、分钟、秒
调用：提供分钟、秒
调用：提供小时、秒
调用：提供分钟
"""


def total_seconds(hours=0, minutes=0, seconds=0):
    all_seconds = hours * 3600 + minutes * 60 + seconds
    print(all_seconds)


hours = int(input("hour:"))
minutes = int(input("minute:"))
seconds = int(input("second:"))
time_dict = {"hours": hours, "minutes": minutes, "seconds": seconds}
# 调用：提供小时、分钟、秒
total_seconds(1, 1, 1)
# 调用：提供分钟、秒
total_seconds(minutes=1, seconds=1)
# 调用：提供小时、秒
total_seconds(hours=1, seconds=1)
# 调用：提供分钟
total_seconds(minutes=1)

total_seconds(**time_dict)