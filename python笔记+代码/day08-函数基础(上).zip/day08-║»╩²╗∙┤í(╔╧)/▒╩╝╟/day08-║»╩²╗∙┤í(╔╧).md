# Python函数基础（上）

## 上节课回顾

```python
-字典
	字典的创建
    定位
    删除
    遍历
    推导式
-集合
	集合的创建
    增删查改
    遍历
    集合的运算
    集合推导式
-综合性练习

-作业：
exercise01:
"""
# 商品字典
dict_commodity_infos = {
 1001: {"name": "屠龙刀", "price": 10000},
 1002: {"name": "倚天剑", "price": 10000},
 1003: {"name": "金箍棒", "price": 52100},
 1004: {"name": "口罩", "price": 20},
 1005: {"name": "酒精", "price": 30},
}
# 订单列表
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
1. 打印所有商品信息,
格式：商品编号xx,商品名称xx,商品单价xx.
2. 打印所有订单中的信息,
格式：商品编号xx,购买数量xx.
3. 打印所有订单中的商品信息,
格式：商品名称xx,商品单价:xx,数量xx.
4. 查找数量最多的订单(使用自定义算法,不使用内置函数)
5. 根据购买数量对订单列表降序(大->小)排列
"""    
# 订单列表
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
# 1. 打印所有商品信息,
for key, value in dict_commodity_infos.items():
    print(f"商品编号：{key}商品名称：{value["name"]}，商品价格：{value["price"]}")

# 2. 打印所有订单中的信息,
for item in list_orders:
    print(f"商品编号：{item["cid"]},购买数量:{item["count"]}")

# 3. 打印所有订单中的商品信息,
for item in list_orders: # item = {"cid": 1001, "count": 1}
    cid = item["cid"] # cid = 1001
    count = item["count"]
    # dict_commodity_infos[cid] = {"name": "屠龙刀", "price": 10000}
    # name = dict_commodity_infos[cid]["name"]  = "屠龙刀"
    name = dict_commodity_infos[cid]["name"]
    price = dict_commodity_infos[cid]["price"]
    print(f"商品编号：{cid}商品名称：{name}，商品价格：{price}, 购买数量:{count}")

# 4. 查找数量最多的订单(使用自定义算法,不使用内置函数)
# max_item = {"cid": 1001, "count": 1}
max_item = list_orders[0]
for item in list_orders[1:]: #  {"cid": 1002, "count": 3}
    if item["count"] > max_item["count"]:
        max_item = item
print(max_item)

# 5. 根据购买数量对订单列表降序(大->小)排列
for i in range(len(list_orders)):  # list_orders[i] = {"cid": 1001, "count": 1}
    for j in range(i + 1, len(list_orders)):  # j = {"cid": 1002, "count": 3}
        if list_orders[i]["count"] < list_orders[j]["count"]:
            list_orders[i], list_orders[j] = list_orders[j], list_orders[i]
print(list_orders)

       
exercise02:
"""
写程序：循环提示用户输入的游戏角色，将输入的角色名存储到集合中；如果出现输入过的角色，则提示已经记录；输入空的话，退出程序
"""
set_name = set()
while True:
    name = input("请输入名字：")
    if not name:
        break
    elif name not in set_name:
        set_name.add(name)
    else:
        print("名字已经存在!")

for item in set_name:
    print(item)

```

## 目标

```python
- 初始函数
- 函数的定义
- 函数的调用
- 函数参数
	实参传递方法
    形参定义方法   
```

## 1.初始函数 function

- 函数是编程中用于封装特定功能的代码块，可以重复执行和调用。函数的定义有助于提高代码的可重用性和可维护性，使代码的结构更清晰

```python
学过的函数：
print() input() int() type() sum() max()

```

## 2.函数的定义

```python
语法：
	def 函数名(形参):
    	函数体 # 实现特定功能的代码块

def func01():
    print("func01")
```

- `def` 关键字：`def`是函数定义的关键字，全称为"define"，用于定义一个函数。
- 函数名：函数名是用来唯一标识函数的名称，遵循变量命名的规则，用于在代码中调用函数。
- 形参：形参是函数中用于接收外部传入的值的变量，也称为函数的输入。形式参数可以有零个或多个，多个参数之间使用逗号 `,` 分隔。
- 函数体：函数体是实现函数功能的代码块，可以包含一条或多条语句。函数体通常使用缩进来表示代码块的范围。

## 3.函数的调用

- 函数调用是指执行函数体中的代码

- 通过函数调用，我们可以使用已定义好的函数来执行特定的功能

```python
语法：
	函数名(实参)
注意：先定义再执行    

def func01(data01):
    print("number is :", data01)


num = 99
func01(num)

注意：
	func01() 函数调用
	func01 函数对象
    data01 形参
    num 实参
```

## 4.函数参数

### 4.1实参传递方式

- 位置传参：实参与形参的位置依次对应

```python
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)

func01(1, 2, 3)

```

- 序列传参：实参用*将序列拆解后与形参的位置依次对应

```python
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)
# 拆包
list01 = [1, 2, 3]
name = "孙悟空"
tuple01 = (4, 5, 6)
func01(*list01)
func01(*name)
func01(*tuple01)
func01(list01, name, tuple01)

```

- 关键字传参:实参根据形参的名字进行对应

```python
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)

func01(p1 = 1, p3 = 2, p2 = 3)

```

- 字典关键字传参:实参用**将字典拆解后与形参的名字进行对应

  配合形参的缺省参数，可以使调用者随意传参

```python
def func01(p1, p2, p3):
    print(p1)
    print(p2)
    print(p3)

dict01 = {"p2": 3, "p1": 999,"p3": 80000}
func01(**dict01)

```

### 4.2形参定义方式

- 缺省形参(默认参数):缺省参数必须自右至左依次存在，如果一个参数有缺省参数，则其右侧的所有参数都必须有缺省参数

```python
语法：
	def 函数名(形参名1=默认实参1, 形参名2=默认实参2, ...):
		函数体

def func01(p1 = 2000, p2 = "老王", p3 = 100):
    print(p1, p2, p3)

func01(1,2,3)
func01(p2 = "小明")
# 支持位置传参和关键字传参同时使用
func01(10,p3 = "小明")
# func01(p1 = 10, 2 , 3) # 报错       

```

- 位置形参

```python
语法：
    def 函数名(形参名1, 形参名2, ...):
   		 函数体
            
def func01(p1, p2, p3):
    print(p1, p2, p3)

func01(1,2,3)
            
           
```

- 星号元组形参: 可以将多个位置实参合并为一个元组

```python
语法：
    def 函数名(*args):
    	函数体
注意：一般命名为'args'
	形参列表中最多只能有一个        
        
def func01(*args):
    print(args)

func01()
func01(1,2,3,4)
func01(1,2,3,4,56,7,8,9,10,11,12,13,14,15,16,17,18)
        
```

- 命名关键字形参: 强制实参使用关键字传参

```python
语法：
    def 函数名(*args, 命名关键字形参1, 命名关键字形参2, ...):
    	函数体
    def 函数名(*, 命名关键字形参1, 命名关键字形参2, ...):
		函数体
# *后面必须使用关键字传参        
def func01(*args,p1,p2):
    print(args)
    print(p1,p2)

func01(1,2,p1 = 3,p2 = 4)
func01(p1 = 3,p2 = 4)
   
    
def func02(*, p1, p2):
    print(p1, p2)


func02(p1=1, p2=2)    
```

- 双星号字典形参：可以将多个关键字实参合并为一个字典

```python
语法：	
    def 函数名(**kwargs):
    	函数体
注意：一般命名为'kwargs'
	形参列表中最多只能有一个  
def func03(**kwargs):
    print(kwargs)

func03(a=1,b=2)
```

- 参数自左至右的顺序：位置形参 --> 星号元组形参 --> 命名关键字形参 --> 双星号字典形参

```python
def func01(list01):
    print(list01)


def func02(*args):
    print(args)


def func03(*args, **kwargs):
    print(args)
    print(kwargs)


# 位置形参 --> 星号元组形参 --> 命名关键字形参 --> 双星号字典形参
def func04(p1, p2, *args, p3=False, **kwargs):
    print(p1, p2)
    print(args)
    print(p3)
    print(kwargs)


func01([1, 2, 3])
func02(*[1, 2, 3])
func03(1, 2, 3, a="老王", b="串门")
func04(1, 2, 3, 4, 5, 6, 7, 8, a="老王", b="串门")


```

练习：

```python
exercise01:
"""
定义函数，根据传入的整数值来打印“老王串门”文本的次数
""" 
def txt(n):
    print("老王串门" * n)


txt(5)


exercise02:
"""
定义函数,根据小时、分钟、秒,计算总秒数
调用：提供小时、分钟、秒
调用：提供分钟、秒
调用：提供小时、秒
调用：提供分钟
"""
def total_seconds(hours=0, minutes=0, seconds=0):
    all_seconds = hours * 3600 + minutes * 60 + seconds
    print(all_seconds)


hours = int(input("hour:"))
minutes = int(input("minute:"))
seconds = int(input("second:"))
time_dict = {"hours": hours, "minutes": minutes, "seconds": seconds}
# 调用：提供小时、分钟、秒
total_seconds(1, 1, 1)
# 调用：提供分钟、秒
total_seconds(minutes=1, seconds=1)
# 调用：提供小时、秒
total_seconds(hours=1, seconds=1)
# 调用：提供分钟
total_seconds(minutes=1)

total_seconds(**time_dict)

 
```

## 作业：

```python
exercise01:
"""
定义一个函数，功能是输出n个数中最大的一个数，并求出它们的和
当输入为空时，打印结果
效果：
请输入数字：1
请输入数字：2
请输入数字：3
请输入数字：4
请输入数字：
您输入的这4个数中最大的数为：4
他们的和为：10
"""

exercise02:
"""
BMI是Body Mass Index 的缩写，BMI中文是“体质指数”的意思，是以你的身高体重计算出来的。BMI是世界公认的一种评定肥胖程度的分级方法，世界卫生组织(WHO)也以BMI来对肥胖或超重进行定义。
　　身高体重指数这个概念，是由19世纪中期的比利时通才凯特勒最先提出。它的定义如下：
　　体重指数(BMI)=体重(kg)÷身高^2(m)
　　成人的BMI数值：
　　过轻：低于18.5
　　适中：20-25
　　过重：25-30
　　肥胖：30-35
　　非常肥胖, 高于35
　　专家指出最理想的体重指数是22。
    请你定义一个函数， 用户输入体重(kg单位) ,输入身高(m单位) 作为参数传入函数，计算出BMI 然后根据BMI 输出 过轻，适中，过重，肥胖，非常肥胖
"""
```

