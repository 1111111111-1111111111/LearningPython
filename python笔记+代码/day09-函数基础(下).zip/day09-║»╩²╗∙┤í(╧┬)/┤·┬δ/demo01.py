# 没有返回值
def func():
    print("func")


data = func()
print(data)


# 返回值可以是任意类型
def func01():
    return 11


def func02():
    return 11.11


def func03():
    return "老王"


def func04():
    return True


print(func01())
print(func02())
print(func03())
print(func04())


# 当函数执行到return时，就会终止函数的所有代码
# 用函数做龙王归来系统
def func():
    count = 0
    while True:
        if count == 3:
            print("您的3次登录机会已经用完")
            break
        num = input("请输入四位密码：")
        count += 1
        if not num:
            print("放弃登录")
            break
        elif num == "8888":
            print("登陆成功")
            return "欢迎龙王回归！"
        else:
            print(f"密码错误，你还剩{3 - count}次机会")
    print("func finish")
    return "这辈子比只能是一个普通人"


data = func()
print(data)
print()
