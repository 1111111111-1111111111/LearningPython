# 函数可以被引用（赋值给变量）
def func01():
    print('func01')


f = func01
func01()
f()


# 函数可以作为另一个函数的参数传入
def func01():
    print('func01')


def func02(a):  # a : 函数对象
    a()


func02(func01)


# 函数可以作为返回值返回
def func01():
    print('func01')


def func02():
    return func01  # 返回函数对象


data = func02()
data()


# 函数可以作为容器里面的元素
def func():
    return 22


data_list = ["老王", func, func()]
print(data_list[0])
print(data_list[1])
print(data_list[1]())
print(data_list[2])
