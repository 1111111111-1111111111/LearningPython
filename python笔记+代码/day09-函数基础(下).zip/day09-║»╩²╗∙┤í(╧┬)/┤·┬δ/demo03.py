def func():
    y = 5
    print(y)


func()


# print(y)


def outer():
    a = 10

    def inner():
        b = 20
        print(a + b)

    inner()
    # print(a + b)


outer()
# print(a)
# inner()

x = 5


def func(X):
    print(X)
    print(x)


func(9)
print(x)
print(len([1, 2, 3]))

number = 0  # 全局变量


def func01():
    global number
    number += 1
    print("func01", number)


def func02():
    number = 5  # 局部作用域
    print("func02", number)


func01()
func02()
number += 1
print("global", number)


def func1():
    num = 0

    def func2():
        nonlocal num
        num = num + 1
        print("func2", num)

    func2()
    num += 1
    print("func1", num)


func1()
