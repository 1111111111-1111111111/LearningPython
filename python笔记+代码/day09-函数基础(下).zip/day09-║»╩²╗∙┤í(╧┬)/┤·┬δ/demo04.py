# 1、有参数有返回值
# def func01(p1, p2):
#     return p1 > p2


func01 = lambda p1, p2: p1 > p2
print(func01(1, 2))

# 2、有参数无返回值
# def func02(p1):
#     print("参数为：", p1)

func02 = lambda p1: print("参数为：", p1)
func02(9)

# 3、无参数有返回值
# def func03():
#     return 100


func03 = lambda: 100
print(func03())


# 4、无参数无返回值
# def func04():
#     print("hello")


func04 = lambda: print("hello")
func04()


