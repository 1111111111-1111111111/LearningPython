# exercise01:
"""
定义一个函数，功能是输出n个数中最大的一个数，并求出它们的和
当输入为空时，打印结果
效果：
请输入数字：1
请输入数字：2
请输入数字：3
请输入数字：4
请输入数字：
您输入的这4个数中最大的数为：4
他们的和为：10
"""


def number(*args):
    num_max = max(args)
    num_sum = sum(args)
    num_count = len(args)
    print(f"您输入的这{num_count}个数中最大的数为：{num_max} 他们的和为：{num_sum}")


num_list = []
while True:
    num = input("请输入数字：")
    if not num:
        break
    num_list.append(int(num))
number(*num_list)

# exercise02:
"""
BMI是Body Mass Index 的缩写，BMI中文是“体质指数”的意思，是以你的身高体重计算出来的。BMI是世界公认的一种评定肥胖程度的分级方法，世界卫生组织(WHO)也以BMI来对肥胖或超重进行定义。
　　身高体重指数这个概念，是由19世纪中期的比利时通才凯特勒最先提出。它的定义如下：
　　体重指数(BMI)=体重(kg)÷身高^2(m)
　　成人的BMI数值：
　　过轻：低于18.5
　　适中：20-25
　　过重：25-30
　　肥胖：30-35
　　非常肥胖, 高于35
　　专家指出最理想的体重指数是22。
    请你定义一个函数， 用户输入体重(kg单位) ,输入身高(m单位) 作为参数传入函数，计算出BMI 然后根据BMI 输出 过轻，适中，过重，肥胖，非常肥胖
"""


def bmi(weight, height):
    bmi_info = weight / (height ** 2)
    print("您的体质指数为：", bmi_info)
    if bmi_info <= 18.5:
        print("过轻")
    elif bmi_info <= 25:
        print("适中")
    elif bmi_info <= 30:
        print("过重")
    elif bmi_info <= 35:
        print("肥胖")
    else:
        print("非常肥胖")


weight = float(input("请输入您的体重(kg):"))
height = float(input("请输入您的身高(m):"))
bmi(weight, height)
