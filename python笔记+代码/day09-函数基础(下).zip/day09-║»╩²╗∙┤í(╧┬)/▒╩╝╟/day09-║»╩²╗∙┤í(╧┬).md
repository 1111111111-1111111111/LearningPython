# Python函数基础（下）

## 上节课回顾

```python
- 初始函数
- 函数的定义
	def 函数名(形参):
    	函数体 
- 函数的调用
	函数名(实际参数)
- 函数参数
	实参传递方法
    	位置传参
        序列传参
        关键字传参
        字典关键字传参
    形参定义方法 
    	缺省形参
        位置形参
        命名关键字形参
        星号元组形参 *args
        双星号字典形参 **kwargs

-作业
exercise01:
"""
定义一个函数，功能是输出n个数中最大的一个数，并求出它们的和
当输入为空时，打印结果
效果：
请输入数字：1
请输入数字：2
请输入数字：3
请输入数字：4
请输入数字：
您输入的这4个数中最大的数为：4
他们的和为：10
"""
def number(*args):
    num_max = max(args)
    num_sum = sum(args)
    num_count = len(args)
    print(f"您输入的这{num_count}个数中最大的数为：{num_max} 他们的和为：{num_sum}")


num_list = []
while True:
    num = input("请输入数字：")
    if not num:
        break
    num_list.append(int(num))
number(*num_list)


exercise02:
"""
BMI是Body Mass Index 的缩写，BMI中文是“体质指数”的意思，是以你的身高体重计算出来的。BMI是世界公认的一种评定肥胖程度的分级方法，世界卫生组织(WHO)也以BMI来对肥胖或超重进行定义。
　　身高体重指数这个概念，是由19世纪中期的比利时通才凯特勒最先提出。它的定义如下：
　　体重指数(BMI)=体重(kg)÷身高^2(m)
　　成人的BMI数值：
　　过轻：低于18.5
　　适中：20-25
　　过重：25-30
　　肥胖：30-35
　　非常肥胖, 高于35
　　专家指出最理想的体重指数是22。
    请你定义一个函数， 用户输入体重(kg单位) ,输入身高(m单位) 作为参数传入函数，计算出BMI 然后根据BMI 输出 过轻，适中，过重，肥胖，非常肥胖
"""
def bmi(weight, height):
    bmi_info = weight / (height ** 2)
    print("您的体质指数为：", bmi_info)
    if bmi_info <= 18.5:
        print("过轻")
    elif bmi_info <= 25:
        print("适中")
    elif bmi_info <= 30:
        print("过重")
    elif bmi_info <= 35:
        print("肥胖")
    else:
        print("非常肥胖")


weight = float(input("请输入您的体重(kg):"))
height = float(input("请输入您的身高(m):"))
bmi(weight, height)

```

## 目标

```python
- 函数的返回值
- 函数使用的高级特征
- LEGB作用域
- 匿名函数 lambda
```

## 1.函数的返回值

在函数中，可以使用 `return` 语句指定应该返回的值。如果没有显式使用 `return` 语句，函数默认返回 `None`

`None` 是Python中表示空值的特殊对象。它是 `NoneType` 数据类型的唯一值，用于表示没有值的情况。在函数中，如果没有指定返回值或直接省略 `return` 语句，函数将隐式返回`None`。

需要注意的是，在同一个函数中，一旦执行到一个 `return` 语句，函数的执行将立即结束，并且后续的代码将被忽略。因此，如果函数包含多个 `return` 语句，只有第一个被执行到的 `return` 语句之后的代码将被忽略

```python
语法：
	def func():
        函数体
        return 数据

# 没有返回值
def func():
    print("func")


data = func()
print(data)


# 返回值可以是任意类型
def func01():
    return 11


def func02():
    return 11.11


def func03():
    return "老王"


def func04():
    return True


print(func01())
print(func02())
print(func03())
print(func04())


# 当函数执行到return时，就会终止函数的所有代码
# 用函数做龙王归来系统
def func():
    count = 0
    while True:
        if count == 3:
            print("您的3次登录机会已经用完")
            break
        num = input("请输入四位密码：")
        count += 1
        if not num:
            print("放弃登录")
            break
        elif num == "8888":
            print("登陆成功")
            return "欢迎龙王回归！"
        else:
            print(f"密码错误，你还剩{3 - count}次机会")
    print("func finish")
    return "这辈子比只能是一个普通人"


data = func()
print(data)


```

## 2.函数使用的高级特征

- 函数可以被引用（赋值给变量）

```python
def func01():
    print('func01')


f = func01
func01()
f()

```

- 函数可以作为另一个函数的参数传入

```python
def func01():
    print('func01')


def func02(a):  # a : 函数对象
    a()


func02(func01)

```

- 函数可以作为返回值返回

```python
def func01():
    print('func01')


def func02():
    return func01  # 返回函数对象


data = func02()
data()

```

- 函数可以作为容器里面的元素

```python
def func():
    return 22


data_list = ["老王", func, func()]
print(data_list[0])
print(data_list[1])
print(data_list[1]())
print(data_list[2])

```

## 3、LEGB作用域

变量起作用的范围

-  Local局部作用域：函数内部

```python
# 局部作用域的生命周期：局部作用域就是在函数调用时创建，在调用结束时销毁
def func():
    y = 5
    print(y)


func()
# print(y)

```

- Enclosing嵌套作用域：嵌套作用域是指在函数内部可以访问外部函数定义的变量。每当创建一个新的函数，就会创建一个新的嵌套作用域

```python
def outer():
    a = 10

    def inner():
        b = 20
        print(a + b)

    inner()
    # print(a + b)


outer()
# print(a)
# inner()

```

- Global全局作用域：模块(.py文件)内部

```python
x = 5


def func(X):
    print(X)
    print(x)


func(9)
print(x)

```

- Builtin内置模块作用域：builtins.py文件

```python
print(len([1, 2, 3]))

```

在 Python 中，变量的作用域遵循 LEGB 原则，即在查找变量时按照以下顺序进行搜索：局部作用域（Local Scope） -> 嵌套作用域（Enclosing Scope） -> 全局作用域（Global Scope） -> 内置作用域（Built-in Scope）。也就是说，如果在局部作用域找不到变量，就会向上一层作用域继续查找，直到找到为止。如果在所有作用域中都找不到变量，则会抛出 NameError 异常。

-  global 语句

  在函数内部修改全局变量。
  在函数内部定义全局变量(全局声明)。

```python
# 在函数内直接为全局变量赋值，视为创建新的局部变量。
# 不能先声明局部的变量，再用global声明为全局变量

number = 0 # 全局变量
def func01():
    global number
    number += 1
    print("func01", number)

def func02():
    number = 5
    print("func02", number)


func01()
func02()
number += 1
print("global", number)

```

- nonlocal 语句：在内层函数修改外层嵌套函数内的变量

```python
def func1():
    num = 0

    def func2():
        nonlocal num
        num = num + 1
        print("func2", num)

    func2()
    num += 1
    print("func1", num)


func1()

```

## 4、匿名函数

匿名函数，也称为lambda函数，是一种在代码中创建函数的方式，它没有显式的函数定义和命名。

-- 作为参数传递时语法简洁，优雅，代码可读性强。
-- 随时创建和销毁，减少程序耦合度

```python
语法：
	变量 = lambda 形参: 方法体
    变量(实参)
   
# 1、有参数有返回值
# def func01(p1, p2):
#     return p1 > p2


func01 = lambda p1, p2: p1 > p2
print(func01(1, 2))

# 2、有参数无返回值
# def func02(p1):
#     print("参数为：", p1)

func02 = lambda p1: print("参数为：", p1)
func02(9)

# 3、无参数有返回值
# def func03():
#     return 100


func03 = lambda: 100
print(func03())


# 4、无参数无返回值
def func04():
    print("hello")


func04 = lambda: print("hello")
func04()

```

## 作业

```python
"""
创建一个学生管理系统
可以实现学生信息的录入（学号、姓名、年龄）
以及增删查改功能
"""
"""
    学生管理系统
"""
主函数
    打印菜单
    增 录入
    删
    查
    改
    退出


```



















