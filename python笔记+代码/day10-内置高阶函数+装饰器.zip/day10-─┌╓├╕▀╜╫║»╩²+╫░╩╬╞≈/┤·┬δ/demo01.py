# map（函数，可迭代对象）
# numbers = [1, 2, 3, 4, 5]
# new_numbers = []
# for i in numbers:
#     new_numbers.append(i ** 2)
# print(new_numbers)

numbers = [1, 2, 3, 4, 5]
new_numbers = list(map(lambda x: x ** 2, numbers))
print(new_numbers)

data01 = ["a", "b", "c", "d"]
data02 = list(map(lambda x: x + "你好", data01))
print(data02)

# filter(函数，可迭代对象)
# numbers = [1, 2, 3, 4, 5]
# new_numbers = []
# for i in numbers:
#     if i % 2 == 0:
#         new_numbers.append(i)
# print(new_numbers)

numbers = [1, 2, 3, 4, 5]
even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
print(even_numbers)

# sorted(可迭代对象，key = 函数, reverse = bool值)
# 对列表进行升序排序
numbers = [5, 2, 8, 3, 1]
sorted_numbers = sorted(numbers, reverse=True)
print(sorted_numbers)

# 对字典列表按照特定字段进行排序
# 订单列表
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
sorted_list_orders = sorted(list_orders, key=lambda order: order["count"], reverse=True)
print(sorted_list_orders)

# max(可迭代对象，key = 函数)
# min(可迭代对象，key = 函数)

# 获取字典列表中特定字段的最大值和最小值
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
max_order = max(list_orders, key=lambda order: order["count"])
min_order = min(list_orders, key=lambda order: order["count"])
print(max_order)
print(min_order)



