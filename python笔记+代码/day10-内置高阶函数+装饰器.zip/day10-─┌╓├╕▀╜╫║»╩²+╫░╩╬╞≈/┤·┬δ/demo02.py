def get_money(money):
    print(f"获得{money}元压岁钱。")

    def child_money(commodity, price):
        nonlocal money
        money -= price
        print(f"购买{commodity}花了{price}元，还剩{money}")

    return child_money


person01 = get_money(1000)  # person01 --> child_money
person01("奥特曼", 200)
person01("芭比娃娃", 300)


# 装饰器
# 闭包版本
def do_something(func):
    def inner(count, kg):
        print("老王进了邻居家的门")
        func(count, kg)
        print("老王从邻居家离开")

    return inner


def neighbor(count, kg):
    print(f"老王吃了{count}个饺子，沾了{kg}斤醋")


new_neighbor = do_something(neighbor)
new_neighbor(15, 1)


# 装饰器版本
def do_something(func):
    def inner(count, kg):
        print("老王进了邻居家的门")
        func(count, kg)
        print("老王从邻居家离开")

    return inner


@do_something
def neighbor(count, kg):
    print(f"老王吃了{count}个饺子，沾了{kg}斤醋")


neighbor(15, 1)
