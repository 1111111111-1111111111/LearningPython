"""
使用闭包模拟以下情景：
在银行开户存入10000
购买xx商品花了xx元,余额xx元
购买xx商品花了xx元,余额xx元
"""
def bank(money):
    print(f"在银行存入{money}")

    def spend(commodity, price):
        nonlocal money
        money -= price
        print(f"购买{commodity}花了{price}元，还剩{money}")

    return spend


laowang = bank(10000)  # person01 --> child_money
laowang("牛肉", 200)
laowang("肾宝片", 1500)
