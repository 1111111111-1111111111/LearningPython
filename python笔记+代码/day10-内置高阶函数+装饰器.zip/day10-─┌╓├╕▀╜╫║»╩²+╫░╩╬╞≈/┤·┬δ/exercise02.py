# 增加运行时间的功能
import time


def run_time(func):
    def inner(*args):
        # 原函数前增加的功能
        start = time.time()
        time.sleep(1)

        res = func(*args)

        # 原函数后增加的功能
        end = time.time()
        print("运行时间：", end - start)
        return res

    return inner


@run_time
def num_sum(*args):
    """
    计算累计和
    :param args:
    :return:
    """
    result = 0
    for num in args:
        result += num
    return result


all = num_sum(1, 2, 3, 4, 5, 6, 7, 8)
print(all)
