"""
创建一个学生管理系统
可以实现学生信息的录入（学号、姓名、年龄）
以及增删查改功能
"""
"""
    学生管理系统
"""


def display():
    """
    打印菜单
    :return:
    """
    print("""
    ===================================
                学生管理系统
    1. 录入信息             2.查看信息
    3.修改信息              4.删除信息
    5.退出系统
    ===================================
    """)


def add():
    """
    录入学生信息
    :return:
    """
    cid = input("请输入学生学号：")
    if cid in dict_student:
        print("学生已经被录入")
        return
    name = input("请输入学生姓名：")
    age = input("请输入学生年龄：")
    list_student = [name, age]
    dict_student[cid] = list_student


def show():
    """
    展示学生信息
    :return:
    """
    for key, value in dict_student.items():
        print(f"学号：{key} 姓名：{value[0]} 年龄：{value[1]}")


def change():
    """
    修改学生信息
    :return:
    """
    cid = input("请输入要修改的学生学号：")
    name = input("请输入要修改的学生姓名：")
    age = input("请输入要修改的学生年龄：")
    dict_student[cid] = [name, age]
    print("修改成功")
    show()


def delete():
    """
    删除学生信息
    :return:
    """
    cid = input("请输入要删除的学生学号：")
    del dict_student[cid]
    print("删除成功！")
    show()


def menu(num):
    """
    选择功能
    :param num:
    :return:
    """
    if num == "1":
        add()
    elif num == "2":
        show()
    elif num == "3":
        change()
    elif num == "4":
        delete()
    else:
        print("您的输入有误！")


def main():
    """
    启动函数
    :return:
    """
    while True:
        display()
        num = input("请输入选项：")
        if num == "5":
            print("退出系统")
            break
        menu(num)


dict_student = {}
main()
