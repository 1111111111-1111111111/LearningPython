# 内置高阶函数+装饰器

## 上节课回顾

```python
- 函数的返回值
	return 数据/None
	当函数内部执行到return就会终止函数后面的代码
- 函数使用的高级特征
	函数可以被引用
    函数可以作为参数传入到另一个函数
    函数可以作为返回值返回
    函数可以作为数据容器里面的元素
- LEGB作用域
	Local局部作用域：函数内部
    Enclosing嵌套作用域：嵌套作用域是指在函数内部可以访问外部函数定义的变量。每当创建一个新的函数，就会创建一个新的嵌套作用域
    Global全局作用域：模块(.py文件)内部
    Builtin内置模块作用域：builtins.py文件
    global关键字：global 语句
        在函数内部修改全局变量。
        在函数内部定义全局变量(全局声明)。
    nonlocal关键字：在内层函数修改外层嵌套函数内的变量
    
- 匿名函数 lambda
	变量 = lambda 形参: 方法体
    #1、有参数有返回值
    func01=lambda p1, p2: p1> p2
    #2、有参数无返回值
    func02=lambda p1: print("参数是：",p1)
    #3、无参数有返回值
    func03=lambda : 100
    #4、无参数无返回值
    func04=lambda : print("hello")

-作业
"""
创建一个学生管理系统
可以实现学生信息的录入（学号、姓名、年龄）
以及增删查改功能
"""
"""
    学生管理系统
"""


def display():
    """
    打印菜单
    :return:
    """
    print("""
    ===================================
                学生管理系统
    1. 录入信息             2.查看信息
    3.修改信息              4.删除信息
    5.退出系统
    ===================================
    """)


def add():
    """
    录入学生信息
    :return:
    """
    cid = input("请输入学生学号：")
    if cid in dict_student:
        print("学生已经被录入")
        return
    name = input("请输入学生姓名：")
    age = input("请输入学生年龄：")
    list_student = [name, age]
    dict_student[cid] = list_student


def show():
    """
    展示学生信息
    :return:
    """
    for key, value in dict_student.items():
        print(f"学号：{key} 姓名：{value[0]} 年龄：{value[1]}")


def change():
    """
    修改学生信息
    :return:
    """
    cid = input("请输入要修改的学生学号：")
    name = input("请输入要修改的学生姓名：")
    age = input("请输入要修改的学生年龄：")
    dict_student[cid] = [name, age]
    print("修改成功")
    show()


def delete():
    """
    删除学生信息
    :return:
    """
    cid = input("请输入要删除的学生学号：")
    del dict_student[cid]
    print("删除成功！")
    show()


def menu(num):
    """
    选择功能
    :param num:
    :return:
    """
    if num == "1":
        add()
    elif num == "2":
        show()
    elif num == "3":
        change()
    elif num == "4":
        delete()
    else:
        print("您的输入有误！")


def main():
    """
    启动函数
    :return:
    """
    while True:
        display()
        num = input("请输入选项：")
        if num == "5":
            print("退出系统")
            break
        menu(num)


dict_student = {}
main()

```

## 目标

```python
- 内置高阶函数
- 扩展内置函数
- 闭包
- 函数装饰器decorator
```

## 1、内置高阶函数

内置高阶函数是指Python内建的一些可以直接使用的、能接受函数作为参数或者将函数作为结果返回的函数。这些函数极大地增强了语言的表达能力和代码的简洁性。 

- `map`（函数，可迭代对象）：使用可迭代对象中的每个元素调用函数，将返回值作为新可迭代对象元素；返回值为新可迭代对象

```python
语法：
	map（函数，可迭代对象）
    
# numbers = [1, 2, 3, 4, 5]
# new_numbers = []
# for i in numbers:
#     new_numbers.append(i ** 2)
# print(new_numbers)

numbers = [1, 2, 3, 4, 5]
new_numbers = list(map(lambda x: x ** 2, numbers))
print(new_numbers)

data01 = ["a", "b", "c", "d"]
data02 = list(map(lambda x: x + "你好", data01))
print(data02)
```

- `filter`(函数，可迭代对象)：根据条件筛选可迭代对象中的元素，返回值为新可迭代对象。

```python
语法：
	filter(函数，可迭代对象)
    
# numbers = [1, 2, 3, 4, 5]
# new_numbers = []
# for i in numbers:
#     if i % 2 == 0:
#         new_numbers.append(i)
# print(new_numbers)

numbers = [1, 2, 3, 4, 5]
even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
print(even_numbers)
    
```

- sorted(可迭代对象，key = 函数,reverse = bool值)：排序，返回值为排序结果。

```python
语法：
	sorted(可迭代对象，key = 函数,reverse = bool值)
    
# 对列表进行升序排序
numbers = [5, 2, 8, 3, 1]
sorted_numbers = sorted(numbers, reverse=True)
print(sorted_numbers)

# 对字典列表按照特定字段进行排序
# 订单列表
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
sorted_list_orders = sorted(list_orders, key=lambda order: order["count"], reverse=True)
print(sorted_list_orders)

```

- max(可迭代对象，key = 函数)：根据函数获取可迭代对象的最大值。
- min(可迭代对象，key = 函数)：根据函数获取可迭代对象的最小值。

```python
语法：
	max(可迭代对象，key = 函数)
	min(可迭代对象，key = 函数)
    
# 获取字典列表中特定字段的最大值和最小值
list_orders = [
{"cid": 1001, "count": 1},
{"cid": 1002, "count": 3},
{"cid": 1005, "count": 2},
]
max_order = max(list_orders, key=lambda order: order["count"])
min_order = min(list_orders, key=lambda order: order["count"])
print(max_order)
print(min_order)
```

## 2、扩展内置函数

- sum()函数用于计算所有可迭代对象（列表，元组。。。）中元素的总和

```python
ret1 = sum([1, 2, 3, 4, 5])
print(ret1)  # 15
ret2 = sum((1, 2, 3, 4, 5), 100)
print(ret2)  # 115

```

-  round() 函数用于将浮点数四舍五入到指定的小数位数

```python
number = 4.5456
ret = round(number, 2)
print(ret)  # 4.55

```

- abs() 函数返回一个数的绝对值，即不考虑其符号的数值大小

```python
ret = abs(-10)
print(ret)  # 10

```

## 3、闭包

构成闭包函数的基本条件

- 必须有一个内嵌函数：闭包函数需要在其内部定义一个或多个函数，这些内部函数被称为内嵌函数或嵌套函数。
- 内嵌函数必须引用外部函数中的变量：闭包函数的内嵌函数必须引用外部函数中的变量。这意味着内嵌函数可以访问和操作外部函数的变量，并且这些变量的状态在内嵌函数被调用时保留。
- 外部函数返回值必须是内嵌函数：外部函数需要返回其内部定义的内嵌函数。这样，外部函数调用后返回的是内嵌函数本身，而不是执行内嵌函数的结果。

满足这三个要素的函数就是一个闭包函数。闭包可以被视为一种封装机制。封装是面向对象编程中的一个重要概念，它允许将数据和相关的操作封装在一个单元中。

```python
# 定义：
def 外部函数名(参数):
   外部变量
   def 内部函数名(参数):
       使用外部变量
   return 内部函数名
# 调用：
变量 = 外部函数名(参数)
变量(参数)
# 在python中闭包的关键作用就是保存外部函数的局部变量，并且这些变量不会随着外部函数的执行结束而销毁

def get_money(money):
    print(f"获得{money}元压岁钱。")

    def child_money(commodity, price):
        nonlocal money
        money -= price
        print(f"购买{commodity}花了{price}元，还剩{money}")

    return child_money


person01 = get_money(1000)  # person01 --> child_money
person01("奥特曼", 200)
person01("芭比娃娃", 300)

```

练习：

```python
"""
使用闭包模拟以下情景：
在银行开户存入10000
购买xx商品花了xx元,余额xx元
购买xx商品花了xx元,余额xx元
"""
def bank(money):
    print(f"在银行存入{money}")

    def spend(commodity, price):
        nonlocal money
        money -= price
        print(f"购买{commodity}花了{price}元，还剩{money}")

    return spend


laowang = bank(10000)  # person01 --> child_money
laowang("牛肉", 200)
laowang("肾宝片", 1500)

```

## 4、函数装饰器decorator

装饰器允许在不修改原始函数代码的情况下，通过包装函数来扩展或修改其行为。

```python
语法：
# 装饰器模板
def decorator_func(original_func):
    def wrapper(*args,**kwargs):
        # 这里是在调用原始函数前添加的新功能
        before_call_code()
       
        result =original_func(*args, **kwargs)
       
        # 这里是在调用原始函数后添加的新功能
        after_call_code()
        
        return result
    return wrapper

@decorator_func
def new_func(参数):
   pass
new_func(参数)

本质：
使用“@函数装饰器名称”修饰原函数，等同于创建与原函数名称相同的变量，关联内嵌函数；故调用原函数时执行内嵌函数

```

- 装饰器其本质就是闭包，是特殊的闭包函数

```python
# 闭包版本
def do_something(func):
    def inner():
        print("老王进了邻居家的门")
        func()
        print("老王从邻居家离开")

    return inner


def neighbor():
    print("老王吃饺子")


new_neighbor = do_something(neighbor)
new_neighbor()


# 装饰器版本
def do_something(func):
    def inner():
        print("老王进了邻居家的门")
        func()
        print("老王从邻居家离开")

    return inner


@do_something
def neighbor():
    print("老王吃饺子")


neighbor()

```

通过在函数定义上方使用 `@do_something`，我们将 `neighbor`函数应用了装饰器。这意味着在调用 `neighbor()` 时，实际上是在调用装饰器返回的`inner`函数。这样，我们可以在不修改 `neighbor` 的情况下，为其添加额外的行为

- 带参数的装饰器

```python
def do_something(func):
    def inner(count, kg):
        print("老王进了邻居家的门")
        func(count, kg)
        print("老王从邻居家离开")

    return inner


@do_something
def neighbor(count, kg):
    print(f"老王吃了{count}个饺子，沾了{kg}斤醋")


neighbor(15, 1)

-------------------------------------------
# 增加运行时间的功能
import time


def run_time(func):
    def inner(*args):
        # 原函数前增加的功能
        start = time.time()
        time.sleep(1)

        res = func(*args)

        # 原函数后增加的功能
        end = time.time()
        print("运行时间：", end - start)
        return res

    return inner


@run_time
def num_sum(*args):
    """
    计算累计和
    :param args:
    :return:
    """
    result = 0
    for num in args:
        result += num
    return result


all = num_sum(1, 2, 3, 4, 5, 6, 7, 8)
print(all)

```

- 装饰器链：一个函数可以被多个装饰器修饰，执行顺序为从近到远

```python
# 思考输出结果
def AA(func):
    print("AA 1 ")

    def func_a(*args, **kwargs):
        print("AA 2 before")
        result_a = func(*args, **kwargs)
        print("AA 2 after")
        return result_a

    return func_a


def BB(func):
    print("BB 1")

    def func_b(*args, **kwargs):
        print("BB 2 before")
        result_b = func(*args, **kwargs)
        print("BB 2 after")
        return result_b

    return func_b


@BB
@AA
def func(x):
    print("FUNC")
    return x * 10


print(func(1))

输出：
AA 1 
BB 1
BB 2 before
AA 2 before
FUNC
AA 2 after
BB 2 after
10
```



练习

```python
exercise01:
"""
不改变插入函数与删除函数代码，为其增加验证权限的功能
def verify_permissions():
   print("验证权限")
def insert():
   print("插入")
def delete():
   print("删除")
insert()
delete()
"""




exercise02:
""" 
为sum_data,增加打印函数执行时间的功能.
函数执行时间公式： 执行后时间 - 执行前时间
def sum_data(n):
   sum_value = 0
   for number in range(n):
       sum_value += number
   return sum_value
print(sum_data(10))
print(sum_data(1000000))
"""


```

## 作业

```python
exercise01:
"""
有一个字符串列表，使用map()将所有字符串转换为大写得到新的列表之后并输出
words = ["apple", "banana", "cherry", "orange"]
"""

exercise02:
"""
将一串字符串 '1 3 5 7 9' 裂开到列表中，并且保证转化为整型，并以列表形式输出变化流程：'1 3 5 7 9' => ['1','3','5','7','9'] => [1,3,5,7,9]
					split                    map
"""

exercise03:
"""
有一个结合了学生姓名-学生分数的字符串列表，使用sorted()函数对这个列表按照分数进行排序。
student_list = ["路飞-100", "柯南-80", "孙悟空-95", "张三-76"]
"""
```

