list01 = [1, 2, 3]
data = iter(list01)
print(data)
print(type(data))

value01 = next(data)
print(value01)

value02 = next(data)
print(value02)

value03 = next(data)
print(value03)

# value04 = next(data)
# print(value04) # StopIteration

# 原始的for循环
list01 = [1, 2, 3]
for item in list01:
    print(item)

# 使用while循环模仿for循环的本质
iterator = iter(list01)
while True:
    try:
        # 获取下一个元素
        item = next(iterator)
        print(item)
    except StopIteration:
        break








