def func():
    print("f1")
    yield 1 # 第一次调用后停止
    print("f2")
    yield 2 # 第二次调用后停止
    print("f3")
    yield 3 # 第三次调用后停止
    print("f4")
    yield 4 # 第四次调用后停止

# 执行生成器函数时，函数体不会被执行，返回了一个生成器对象
data = func()
print(data)
print(type(data))

# next方法中放生成器对象，进入生成器函数，执行代码
f1 = next(data)
print(f1)

f2 = next(data)
print(f2)

f3 = next(data)
print(f3)

f4 = next(data)
print(f4)

# f5 = next(data)
# print(f5)

for i in func():
    print(i)