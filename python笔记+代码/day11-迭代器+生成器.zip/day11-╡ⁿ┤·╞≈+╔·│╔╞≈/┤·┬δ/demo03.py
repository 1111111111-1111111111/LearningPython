# 十进制转二进制
val01 = bin(22)
print(val01)

# 十进制转八进制
val02 = oct(22)
print(val02)

# 十进制转16进制
val03 = hex(22)
print(val03)

# 其他进制转十进制
val_01 = int("0b10110", base=2)
val_02 = int("0o26", base=8)
val_03 = int("0x16", base=16)
print(val_01)
print(val_02)
print(val_03)
