name = "挽风"
v1 = name.encode('utf-8')  # 编码
print(v1)
v2 = b'\xe6\x8c\xbd\xe9\xa3\x8e'.decode('utf-8')  # 解码
print(v2)
