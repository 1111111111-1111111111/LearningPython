# exercise01:
"""
不改变插入函数与删除函数代码，为其增加验证权限的功能
def verify_permissions():
   print("验证权限")
def insert():
   print("插入")
def delete():
   print("删除")
insert()
delete()
"""


def add_func(func):
    def verify_permissions():
        print("验证权限")
        func()

    return verify_permissions


@add_func
def insert():
    print("插入")


@add_func
def delete():
    print("删除")


insert()
delete()

# exercise02:
""" 
为sum_data,增加打印函数执行时间的功能.
函数执行时间公式： 执行后时间 - 执行前时间
def sum_data(n):
   sum_value = 0
   for number in range(n):
       sum_value += number
   return sum_value
print(sum_data(10))
print(sum_data(1000000))
"""
import time


def run_time(func):
    def inner(n):
        start_time = time.time()
        time.sleep(1)
        sum_value = func(n)
        end_time = time.time()
        print(end_time - start_time)
        return sum_value

    return inner


@run_time
def sum_data(n):
    sum_value = 0
    for number in range(n):
        sum_value += number
    return sum_value


print(sum_data(10))
print(sum_data(1000000))

# - 作业
# exercise01:
"""
有一个字符串列表，使用map()将所有字符串转换为大写得到新的列表之后并输出
words = ["apple", "banana", "cherry", "orange"]
"""
words = ["apple", "banana", "cherry", "orange"]
new_words = list(map(lambda item: item.upper(), words))
print(new_words)

# exercise02:
"""
将一串字符串 '1 2 3 4 5 6 7 8 9' 裂开到列表中，转化为整型，再保留奇数，并以列表形式输出变化流程：
1 2 3 4 5 6 7 8 9 --->  split()
['1', '2', '3', '4', '5', '6', '7', '8', '9'] --->  map()
[1, 2, 3, 4, 5, 6, 7, 8, 9] --->  filter()
[1, 3, 5, 7, 9]
"""
str_num = '1 2 3 4 5 6 7 8 9'
list_num = str_num.split()
list_num_int = list(map(lambda x: int(x), list_num))
list_num_odd = list(filter(lambda x: x % 2 != 0, list_num_int))
print(f"{str_num} --> \n{list_num} --> \n{list_num_int} --> \n{list_num_odd}")

# exercise03:
"""
有一个结合了学生姓名-学生分数的字符串列表，使用sorted()函数对这个列表按照分数进行排序。
student_list = ["路飞-100", "柯南-80", "孙悟空-95", "张三-76"]
"""
student_list = ["路飞-100", "柯南-80", "孙悟空-95", "张三-76"]
# "路飞-100" --> ["路飞", "100"] --> "100" --> 100
new_student_list = sorted(student_list, key=lambda item: int(item.split("-")[1]))
print(new_student_list)














