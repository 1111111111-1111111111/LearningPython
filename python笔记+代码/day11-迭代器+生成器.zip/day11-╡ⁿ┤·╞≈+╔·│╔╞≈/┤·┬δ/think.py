# 思考输出结果
def AA(func):
    print("AA 1 ")

    def func_a(*args, **kwargs):
        print("AA 2 before")
        result_a = func(*args, **kwargs)
        print("AA 2 after")
        return result_a

    return func_a


def BB(func):
    print("BB 1")

    def func_b(*args, **kwargs):
        print("BB 2 before")
        result_b = func(*args, **kwargs)
        print("BB 2 after")
        return result_b

    return func_b


def func(x):
    print("FUNC")
    return x * 10

func_a = AA(func)
func_b = BB(func_a)
print(func_b(1))

"""输出：
AA 1 
BB 1
BB 2 before
AA 2 before
FUNC
AA 2 after
BB 2 after
10"""
