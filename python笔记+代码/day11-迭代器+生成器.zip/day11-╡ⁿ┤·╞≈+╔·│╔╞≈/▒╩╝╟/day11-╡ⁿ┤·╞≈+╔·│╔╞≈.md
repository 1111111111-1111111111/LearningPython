# 迭代器+生成器

## 上节课回顾

```python
- 内置高阶函数
	-- map（函数，可迭代对象）
    -- filter(函数，可迭代对象)
    -- sorted(可迭代对象，key = 函数,reverse = bool值)
    -- max(可迭代对象，key = 函数)
	-- min(可迭代对象，key = 函数)
- 扩展内置函数
	-- sum()函数用于计算所有可迭代对象（列表，元组。。。）中元素的总和
    -- round() 函数用于将浮点数四舍五入到指定的小数位数
    -- abs() 函数返回一个数的绝对值，即不考虑其符号的数值大小
- 闭包
	-- 必须有一个内嵌函数。
	-- 内嵌函数必须引用外部函数中变量。
	-- 外部函数返回值必须是内嵌函数
- 函数装饰器decorator
	-- 通过闭包的方式实现在不修改原函数代码的情况下，通过包装函数来扩展或修改其行为
    
- 练习
exercise01:
"""
不改变插入函数与删除函数代码，为其增加验证权限的功能
def verify_permissions():
   print("验证权限")
def insert():
   print("插入")
def delete():
   print("删除")
insert()
delete()
"""
def add_func(func):
    def verify_permissions():
        print("验证权限")
        func()

    return verify_permissions


@add_func
def insert():
    print("插入")


@add_func
def delete():
    print("删除")


insert()
delete()

exercise02:
""" 
为sum_data,增加打印函数执行时间的功能.
函数执行时间公式： 执行后时间 - 执行前时间
def sum_data(n):
   sum_value = 0
   for number in range(n):
       sum_value += number
   return sum_value
print(sum_data(10))
print(sum_data(1000000))
"""
import time


def run_time(func):
    def inner(n):
        start_time = time.time()
        time.sleep(1)
        sum_value = func(n)
        end_time = time.time()
        print(end_time - start_time)
        return sum_value
    return inner


@run_time
def sum_data(n):
    sum_value = 0
    for number in range(n):
        sum_value += number
    return sum_value


print(sum_data(10))
print(sum_data(1000000))

- 作业
exercise01:
"""
有一个字符串列表，使用map()将所有字符串转换为大写得到新的列表之后并输出
words = ["apple", "banana", "cherry", "orange"]
"""
words = ["apple", "banana", "cherry", "orange"]
new_words = list(map(lambda item: item.upper(), words))
print(new_words)

exercise02:
"""
将一串字符串 '1 2 3 4 5 6 7 8 9' 裂开到列表中，转化为整型，再保留奇数，并以列表形式输出变化流程：
1 2 3 4 5 6 7 8 9 --->  split()
['1', '2', '3', '4', '5', '6', '7', '8', '9'] --->  map()
[1, 2, 3, 4, 5, 6, 7, 8, 9] --->  filter()
[1, 3, 5, 7, 9]
"""
str_num = '1 2 3 4 5 6 7 8 9'
list_num = str_num.split()
list_num_int = list(map(lambda x: int(x), list_num))
list_num_odd = list(filter(lambda x: x % 2 != 0, list_num_int))
print(f"{str_num} --> \n{list_num} --> \n{list_num_int} --> \n{list_num_odd}")

exercise03:
"""
有一个结合了学生姓名-学生分数的字符串列表，使用sorted()函数对这个列表按照分数进行排序。
student_list = ["路飞-100", "柯南-80", "孙悟空-95", "张三-76"]
"""
student_list = ["路飞-100", "柯南-80", "孙悟空-95", "张三-76"]
# "路飞-100" --> ["路飞", "100"] --> "100" --> 100
new_student_list = sorted(student_list, key=lambda item: int(item.split("-")[1]))
print(new_student_list)

- 思考：
# 思考输出结果
def AA(func):
    print("AA 1 ")

    def func_a(*args, **kwargs):
        print("AA 2 before")
        result_a = func(*args, **kwargs)
        print("AA 2 after")
        return result_a

    return func_a


def BB(func):
    print("BB 1")

    def func_b(*args, **kwargs):
        print("BB 2 before")
        result_b = func(*args, **kwargs)
        print("BB 2 after")
        return result_b

    return func_b


@BB
@AA
def func(x):
    print("FUNC")
    return x * 10


print(func(1))

输出：
AA 1 
BB 1
BB 2 before
AA 2 before
FUNC
AA 2 after
BB 2 after
10
```

![1751551161910](C:\Users\EDY\AppData\Roaming\Typora\typora-user-images\1751551161910.png)

## 目标

```python
- 迭代器
- 生成器
- 字符编码
```

## 1、迭代器

迭代是指重复执行某个操作的过程，并且每次迭代得到的结果会作为下一次迭代的初始值

可迭代对象：从语法形式上讲，内置有 `__iter__` 方法的对象都是可迭代对象，字符串、列表、元组、字典、集合都是可迭代对象

调用 `__iter__` 方法返回的结果就是一个迭代器对象(Iterator)。迭代器对象是内置有 `__iter__` 和 `__next__` 方法的对象

- 执行迭代器对象 `__iter__` 方法得到的仍然是迭代器本身
- 而执行迭代器 `__next__` 方法就会计算出迭代器中的下一个值。

```python
 # 注意，虽然可以直接使用 __iter__  和 __next__ 这些方法，但是python官方并不推荐我们直接使用这种双下划线的方法，不符合习惯性，所以提供了2个内置函数iter() 和 next() 
# 它们本质上也是用__iter__ 和 __next__

list01 = [1, 2, 3]
data = iter(list01)
print(data)
print(type(data))

value01 = next(data)
print(value01)

value02 = next(data)
print(value02)

value03 = next(data)
print(value03)

value04 = next(data)
print(value04) # StopIteration

```

for循环原理

- `for` 循环是一种迭代循环，用于遍历可迭代对象中的元素。
- `for`循环语法中的`in`后可以跟任何可迭代对象，如列表、元组、字符串、字典等。
- 当`for`循环开始执行时，它会首先调用可迭代对象的内置`__iter__`方法，以获取一个迭代器对象。
- 然后，`for`循环会重复调用迭代器对象的`__next__`方法，以获取可迭代对象中的下一个值，并将这个值赋给循环变量。
- 这个过程会一直重复，直到迭代器对象耗尽，即可迭代对象中的所有元素都被访问完毕，或者遇到`break`语句提前终止循环。
- 当迭代器对象耗尽时，它会引发`StopIteration`异常，这时`for`循环会捕捉到该异常，结束迭代过程。

```python
# 原始的for循环
list01 = [1, 2, 3]
for item in list01:
    print(item)

# 使用while循环模仿for循环的本质
iterator = iter(list01)
while True:
    try:
        # 获取下一个元素
        item = next(iterator)
        print(item)
    except StopIteration:
        break


```

迭代器提供了一种统一的遍历方式，无论是对列表、字典、集合还是自定义的可迭代对象，都可以使用相同的`for`循环语法进行遍历。

## 2、生成器 generator

若函数体包含yield关键字，再调用函数，并不会执行函数体代码，得到的返回值即生成器对象，生成器内置有 `__iter__` 和 `__next__` 方法，所以生成器本身就是一个迭代器。我们可以用 `__next__` 触发生成器所对应函数的执行

```python
- 列表推导式		 变量 = [表达式 for 变量 in 可迭代对象 if 条件]
- 生成器表达式	变量 = (表达式 for 变量 in 可迭代对象 if 条件)
				for i in 变量:
					print(i)
            
# 创建一个1-100000000的一个序列
# 列表推导式
list01  = [for i in range(100000000)] # 一次性全部加载到内存，非常占用时间和空间

# 生成器
gen01  = (for i in range(100000000)) # 想拿的时候，就拿一个，再生成一个 非常节省资源
```

在循环过程中，按照某种算法**推算**数据，不必创建容器存储完整的结果，从而节省内存空间。数据量越大，优势越明显。以上作用也称之为延迟操作或惰性操作，通俗的讲就是在需要的时候才计算结果，而不是一次构建出所有结果

```python
语法：
	# 创建：
    def 函数名():
        …
        yield 数据
        …
    # 调用：
    for 变量名 in 函数名():
       语句
    
def func():
    print("f1")
    yield 1 # 第一次调用后停止
    print("f2")
    yield 2 # 第二次调用后停止
    print("f3")
    yield 3 # 第三次调用后停止
    print("f4")
    yield 4 # 第四次调用后停止

# 执行生成器函数时，函数体不会被执行，返回了一个生成器对象
data = func()
print(data)
print(type(data))

# next方法中放生成器对象，进入生成器函数，执行代码
f1 = next(data)
print(f1)

f2 = next(data)
print(f2)

f3 = next(data)
print(f3)

f4 = next(data)
print(f4)

# f5 = next(data)
# print(f5)

for i in func():
    print(i)
```

有了yield关键字，我们就有了一种自定义迭代器的实现方式。yield可以用于返回值，但不同于return，函数一旦遇到return就结束了，而yield可以保存函数的运行状态挂起函数，用来返回多次值

## 3.字符编码

进制：计算机中底层的所有数据都是以`010101`的形式存在（图片，文本，视频等）

```python
二进制：01
八进制：01234567
十进制：0123456789
十六进制：0123456789abcdef

注意：十进制是以整型存在，二进制，八进制，十六进制是以字符串的形式存在
```

进制转换：

```python
# 十进制转二进制
val01 = bin(22)
print(val01)

# 十进制转八进制
val02 = oct(22)
print(val02)

# 十进制转16进制
val03 = hex(22)
print(val03)

# 其他进制转十进制
val_01 = int("0b10110", base=2)
val_02 = int("0o26", base=8)
val_03 = int("0x16", base=16)
print(val_01)
print(val_02)
print(val_03)

```

计算机中的单位：

```python
- b（bit），比特位
1     1位
10	  2位
101   3位
1101  4位

- B（byte），字节
8位是一个字节
10011001  1个字节
10011001 10011001 2个字节

- KB（kilobyte），千字节
1024个字节就是1个KB
1KB = 1024B = 1024 * 8b

- MB（Megabyte），兆字节
1024KB就是1MB
1MB = 1024KB = 1024 * 1024B = 1024 * 1024 * 8b

- G（Gigabyte），千兆
1024MB就是1G
1G = 1024MB = 1024 * 1024KB = 1024 * 1024 * 1024B = 1024 * 1024 * 1024 * 8b

- T（Terabyte），万亿字节
1024G就是1T

- 更大的单位PB/EB/ZB/YB...
```

字符编码：

字符编码是一种将字符映射到二进制数据的规则或方案。由于计算机内部是以二进制形式存储和处理数据，因此需要一种方式来表示和处理文本字符。

- ASCII：ASCII是最早的字符编码方案，使用7位二进制数表示128个标准ASCII字符，包括英文字母、数字和一些常见的符号。ASCII只能表示英文字符，无法表示其他语言字符。

  ![ASCII字符代码表](ASCII字符代码表.png)

```
规定使用一个字节表示字母与二进制的对应关系，也就是256种ascll字符

00000000
00000001
00000010
00000011
......
11111111

2 ** 8 = 256
```

- GBK：GBK是中国制定的字符编码标准，用于表示中文字符和英文字符。GBK扩展了ASCII编码，一个英文字符使用1个字节（8位）表示，一个中文字符使用2个字节（16位）表示。

```
单字节表示：用一个字节表示对应关系 (256种)
双字节表示：用两个字节表示对应关系 (65536种)
```

- Unicode：Unicode是一种字符编码标准，旨在统一全球各个语言的字符表示。Unicode可以表示几乎所有的语言字符，包括英文、中文、日文以及其他语言字符。UCS-2使用2个字节表示每个字符，而UCS-4使用4个字节表示每个字符。UCS-4可以表示Unicode的全部字符，但在存储和传输上占用的空间较大。

- UTF-8：UTF-8是Unicode的一种变长字符编码方案。它可以使用1至4个字节来表示一个字符，根据字符的不同而变化字节长度。UTF-8编码中的ASCII字符（0-127）与标准的ASCII编码是相同的，所以UTF-8编码是兼容ASCII的。UTF-8编码的优点是可以节省存储空间，因为它能够灵活地根据字符的实际需要来调整字节长度。对于使用较少的字符，只需使用1个字节表示，而对于需要表示更多字符的语言，则使用2、3或4个字节。

```
unicode码位范围(16进制)    utf-8          转换模板
0000 ~ 007F             1个字节表示     0xxxxxxx
0080 ~ 07FF             2个字节表示     110xxxxx 10xxxxxx
0800 ~ FFFF             3个字节表示     1110XXXX 10XXXXXX 10XXXXXX
10000 ~ 10FFFF          4个字节表示     11110XXX 110xxxxx 10xxxxxx 10xxxxxx
```

- python相关的编码

```
字符串（str）   "路飞是要成为海贼王的"       unicode处理            一般在内存
字节（byte）    b'\xe8\xb7\xaf\......    utf-8编码或者gbk编码     一般用于文件或网络处理

name = "挽风"
v1 = name.encode('utf-8')  # 编码
print(v1)
v2 = b'\xe6\x8c\xbd\xe9\xa3\x8e'.decode('utf-8')  # 解码
print(v2)


```



































