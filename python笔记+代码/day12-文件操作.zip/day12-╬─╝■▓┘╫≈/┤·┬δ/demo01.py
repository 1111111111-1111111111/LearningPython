file = open("qiangjinjiu.txt", "rb")

for line in file:
    print(line.decode('utf-8'), end="")

file.close()
