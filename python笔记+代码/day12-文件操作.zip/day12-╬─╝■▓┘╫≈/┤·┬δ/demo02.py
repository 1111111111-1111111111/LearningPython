file = open('txt01.txt', 'w', encoding='utf-8')

list_txt = ["我是老王\n", "今天天气很不错\n", "闲来无事\n", "去邻居家逛逛\n"]
file.writelines(list_txt)

file.close()















