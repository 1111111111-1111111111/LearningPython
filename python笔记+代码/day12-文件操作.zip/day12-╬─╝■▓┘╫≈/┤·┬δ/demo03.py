file = open("qiangjinjiu.txt", "rb")

print(file.tell())
for i in range(3):
    data = file.readline()
    print(data.decode('utf-8'), end="")

print(file.tell())
file.seek(0)
print(file.tell())
data = file.readline()
print(data.decode('utf-8'), end="")

file.seek(3, 0)
print(file.tell())
data = file.readline()
print(data.decode('utf-8'), end="")

file.seek(-9, 2)
print(file.tell())
data = file.readline()
print(data.decode('utf-8'), end="")

file.close()
