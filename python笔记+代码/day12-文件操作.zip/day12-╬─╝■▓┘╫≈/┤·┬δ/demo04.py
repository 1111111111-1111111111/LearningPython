with (open("qiangjinjiu.txt", "rb") as file01, \
      open("txt01.txt", "rb") as file02):
    data01 = file01.read()
    print(data01.decode())
    data02 = file02.read()
    print(data02.decode())
