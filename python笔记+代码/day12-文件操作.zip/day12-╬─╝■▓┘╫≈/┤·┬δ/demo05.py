name_list = ["老王", "老刘", "老张头"]
age_list = [40, 60, 42]
tuple01 = tuple(zip(name_list, age_list))
print(tuple01)
dict01 = dict(zip(name_list, age_list))
print(dict01)

name_list = ["老王", "老刘", "老张头"]
for i, v in enumerate(name_list):
    print(f"i={i},v={v}")