def copy(filename):
    """
    复制一份文件
    :param filename: 文件的路径
    :return: None
    """
    # 预处理文件名
    copy_filename = "copy_" + filename.split("\\")[-1]
    file_read = open(filename, "rb")
    file_write = open(copy_filename, "wb") \
    # 边读边写
    while True:
        data = file_read.read(1024)
        if not data:
            break
        file_write.write(data)
    file_read.close()
    file_write.close()


file_name = input("请输入文件路径：")
# D:\wf\2025.06.19基础班\day12-文件操作\代码\evolution.jpg
copy(file_name)
