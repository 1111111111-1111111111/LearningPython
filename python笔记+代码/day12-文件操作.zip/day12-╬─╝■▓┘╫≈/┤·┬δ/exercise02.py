# 创建一个角色注册表，如果已经存在，则提示重新输入，输入为空时，退出程序并展示已创建角色
with open('characters.txt', 'ab+') as file:
    while True:
        name = input('请输入角色名字：')
        file.seek(0)
        name_read = file.read().decode('utf-8')
        if not name:
            break
        if name in name_read:
            print("角色已经存在！")
        else:
            # 老王
            # 老刘
            file.write((name + "\n").encode('utf-8'))
            file.flush()

    print(name_read)
