str01 = R"D:\wf\2025.06.19基础班\day12-文件操作\代码\evolution.jpg"
str_list = str01.split("\\")
print(str_list)
print(str_list[-1])
print("老王" + str_list[-1])
