# 文件操作

- 什么是文件
  文件是保存在持久化存储设备(硬盘、U盘、光盘..)上的一段数据，一个文本，一个py文件，一张图片，视频音频等这些都是文件。
- 文件分类
  - 文本文件：打开后会自动解码为字符，如txt文件，word文件，py程序文件。
  - 二进制文件：内部编码为二进制码，无法通过文字编码解析，如压缩包，音频，视频，图片等 

- 字节串类型

  - 概念 ： 在python3中引入了字节串的概念，与str不同，字节串以字节序列值表达数据，更方便用来处理
    二进程数据。
  - 字符串与字节串相互转化方法

  ```python
  - 普通的英文字符字符串常量可以在前面加b转换为字节串，例如：b'hello'
  - 变量或者包含非英文字符的字符串转换为字节串方法 ：str.encode()
  - 字节串转换为字符串方法 : bytes.decode()
  注意：python字符串用来表达utf8字符，因为并不是所有二进制内容都可以转化为utf8字符，所以不是所有字
  节串都能转化为字符串，但是所有字符串都能转化成二进制，所以所有字符串都能转换为字节串。
  ```

  

## 目标

```python
-open函数
	- 文件对象读取操作
    - 文件对象写入操作
    - 关闭文件
    - 文件偏移量
    - 读写缓冲区
    - with语句
- 内置函数
```



## 1、open函数

`open()` 函数用于打开文件，并返回一个文件对象，可以用于读取、写入或操作文件。

```python
语法：
file_object = open(
    'file',  # 文件路径
    mode='r',  # 打开文件的模式,如果不写默认为‘r’
    encoding=None,  # 设置打开文件的编码方式
    buffering=-1  # 1表示有行缓冲，默认则表示使用系统默认提供的缓冲机制。
)
返回值：成功返回文件操作对象

```

### 关闭文件

打开一个文件后我们就可以通过文件对象对文件进行操作了，当操作结束后可以关闭文件操作

- 可以销毁对象节省资源
- 防止后面对这个对象的误操作。

```python
语法：
	file_object.close()
```

文件路径用于指定文件的位置。文件路径可以是相对路径或绝对路径。

- 绝对路径：总是从根文件夹开始，Window 系统中以盘符（C：、D：）作为根文件夹。
- 相对路径：指的是文件相对于当前工作目录所在的位置。

```python
file_path = 'C:\Users\86199\Desktop\python_project\day16\test.py'
# 当路径出现转义时
- 原始字符串
file_path = r'C:\Users\86199\Desktop\python_project\day16\test.py'

- 转义字符
file_path = 'C:\Users\86199\Desktop\python_project\day16\\test.py'
    
```

打开文件的模式：

| 打开模式 |                          效果                          |
| :------: | :----------------------------------------------------: |
|    r     |               以读方式打开，文件必须存在               |
|    w     |    以写方式打开，文件不存在则创建，存在清空原有内容    |
|    a     | 以追加模式打开，文件不存在则创建，存在则继续进行写操作 |
|    r+    |              以读写模式打开 文件必须存在               |
|    w+    |   以读写模式打开文件，不存在则创建，存在清空原有内容   |
|    a+    | 追加并可读模式，文件不存在则创建，存在则继续进行写操作 |
|    rb    |                 以二进制读模式打开 同r                 |
|    wb    |                 以二进制写模式打开 同w                 |
|    ab    |                以二进制追加模式打开 同a                |
|   rb+    |               以二进制读写模式打开 同r+                |
|   wb+    |               以二进制读写模式打开 同w+                |
|   ab+    |               以二进制读写模式打开 同a+                |

### 文件对象读取操作

- `read(size)`: 读取指定大小的字符数或字节数，并返回读取的内容作为字符串或字节对象。如果省略`size`参数或指定为负数，则读取整个文件内容。

```python
file = open("qiangjinjiu.txt", "r", encoding="utf -8")

# data01 = file.read()
# print(data01)


data02 = file.read(100000)
print(data02)

file.close()

```



- `readline()`: 逐行读取文件内容，每次读取一行，并返回包含该行内容的字符串

```python
file = open("qiangjinjiu.txt", "rb")

while True:
    data01 = file.readline()
    if not data01:
        break
    print(data01.decode('utf-8'))

file.close()


```



- `readlines()`: 一次性读取整个文件内容，并将每行内容作为字符串存储在列表中返回。

```python
file = open("qiangjinjiu.txt", "rb")

data = file.readlines() # 列表
for line in data:
    print(line.decode('utf-8'), end="")

file.close()


```



- 文件对象本身也是一个可迭代对象，在for循环中可以迭代文件的每一行。

```python
file = open("qiangjinjiu.txt", "rb")

for line in file:
    print(line.decode('utf-8'), end="")

file.close()


```

### 文件对象写入操作

- `write(str)`: 将指定的字符串写入文件。如果文件以文本模式打开，参数 `str` 必须是字符串类型。如果文件以二进制模式打开，参数 `str`可以是字节对象。

```python
file = open('txt01.txt', 'wb')
file.write('老王啊老王我爱你'.encode('utf-8'))
file.close()

```



- `writelines(lines)`: 将一个字符串列表写入文件。每个字符串都会被写入为一行。需要注意的是，`writelines()` 方法不会自动在每行末尾添加换行符，需要手动添加。

```python
file = open('txt01.txt', 'w', encoding='utf-8')

list_txt = ["我是老王\n", "今天天气很不错\n", "闲来无事\n", "去邻居家逛逛\n"]
file.writelines(list_txt)

file.close()


```

### 文件偏移量

```python
注意：
1. r或者w方式打开，文件偏移量在文件开始位置
2. a方式打开，文件偏移量在文件结尾位置
```

```python
语法：
文件名.tell()
	功能：获取文件偏移量大小
	返回值：文件偏移量
文件名.seek(offset[,whence])
	功能: 移动文件偏移量位置
	参数：offset 代表相对于某个位置移动的字节数。负数表示向前移动，正数表示向后移动。
		whence是基准位置的默认值为 0，代表从文件开头算起
        1代表从当前位置算起
        2 代表从文件末尾算起
       #注意：必须以二进制方式打开文件时，基准位置才能是1或者2
    
file = open("qiangjinjiu.txt", "rb")

print(file.tell())
for i in range(3):
    data = file.readline()
    print(data.decode('utf-8'), end="")

print(file.tell())
file.seek(0)
print(file.tell())
data = file.readline()
print(data.decode('utf-8'), end="")

file.seek(3, 0)
print(file.tell())
data = file.readline()
print(data.decode('utf-8'), end="")

file.seek(-9, 2)
print(file.tell())
data = file.readline()
print(data.decode('utf-8'), end="")

file.close()

```

### 读写缓冲区

- 定义

  系统自动的在内存中为每一个正在使用的文件开辟一个空间，在对文件读写时都是先将文件内容加载到缓冲
  区，再进行读写。

  ![1736919396678](imgs/1736919396678.png)

- 作用
  1. 减少和磁盘的交互次数，保护磁盘。
  2. 提高了对文件的读写效率。

- 缓冲回区设置

![1736919511488](imgs/1736919511488.png)

- 刷新缓冲区条件

  1. 缓冲区被写满

  2. 程序执行结束或者文件对象被关闭

  3. 程序中调用ﬂush()函数

     flush() 方法是用来刷新缓冲区的，即将缓冲区中的数据立刻写入文件，同时清空缓冲区，不需要是被动的等待输出缓冲区写入。

```python
语法：
	文件名.flush()
file = open("t,txt", "a", encoding = "utf-8")
file.write("到点了，去吃饭")
file.flush() # 立刻写入文件
file.close()

```



### with语句

在Python中，`with` 语句提供了一种方便的方式来管理资源，例如文件操作、网络连接等。它可以确保在使用完资源后自动进行清理和释放。

```python
with 资源 as 变量:
    # 在此处使用资源进行操作
    # 代码块结束后，资源会自动进行清理和释放
```

一个常见的应用是使用 `with` 语句来打开文件，进行文件操作，然后自动关闭文件。

```python
with open("qiangjinjiu.txt", "rb") as file:
    data = file.read()
    print(data.decode())

```

with支持同时对多个文件进行管理

```python
with (open("qiangjinjiu.txt", "rb") as file01, \
      open("txt01.txt", "rb") as file02):
    data01 = file01.read()
    print(data01.decode())
    data02 = file02.read()
    print(data02.decode())

```

练习：

```python
exercise01:
# 编写一个函数,参数传入一个指定的文件名,将这个文件复制到程序运行目录下,
# 通过边读边写的方式将一张图片复制一份到该目录下	
def copy(filename):
    """
    复制一份文件
    :param filename: 文件的路径
    :return: None
    """
    # 预处理文件名
    copy_filename = "copy_" + filename.split("\\")[-1]
    file_read = open(filename, "rb")
    file_write = open(copy_filename, "wb")
    # 边读边写
    while True:
        data = file_read.read(1024)
        if not data:
            break
        file_write.write(data)
    file_read.close()
    file_write.close()


file_name = input("请输入文件路径：")

# D:\wf\2025.06.19基础班\day12-文件操作\代码\evolution.jpg
copy(file_name)


exercise02:
# 创建一个角色注册表，如果已经存在，则提示重新输入，输入为空时，退出程序并展示已创建角色
with open('characters.txt', 'ab+') as file:
    while True:
        name = input('请输入角色名字：')
        file.seek(0)
        name_read = file.read().decode('utf-8')
        if not name:
            break
        if name in name_read:
            print("角色已经存在！")
        else:
            # 老王
            # 老刘
            file.write((name + "\n").encode('utf-8'))
            file.flush()

    print(name_read)


```



## 2、内置函数

| 函数          | 功能描述                                                     |
| ------------- | ------------------------------------------------------------ |
| `print()`     | 打印输出内容到控制台。                                       |
| `input()`     | 从用户输入读取一行文本。                                     |
| `len()`       | 返回对象的长度或元素个数。                                   |
| `type()`      | 返回对象的类型。                                             |
| `range()`     | 生成一个指定范围的整数序列。                                 |
| `sum()`       | 计算可迭代对象的总和。                                       |
| `max()`       | 返回可迭代对象的最大值。                                     |
| `min()`       | 返回可迭代对象的最小值。                                     |
| `abs()`       | 返回一个数的绝对值。                                         |
| `round()`     | 对一个数进行四舍五入。                                       |
| `sorted()`    | 对可迭代对象进行排序并返回一个新列表。                       |
| `any()`       | 判断可迭代对象中是否存在至少一个为真的元素。                 |
| `all()`       | 判断可迭代对象中所有元素是否都为真。                         |
| `zip()`       | 将多个可迭代对象打包成一个元组序列。                         |
| `enumerate()` | 返回一个枚举对象，包含可迭代对象的索引和值。                 |
| `map()`       | 对可迭代对象的每个元素应用给定函数，并返回一个结果列表。     |
| `filter()`    | 根据给定函数的返回值筛选可迭代对象中的元素，并返回一个结果列表。 |
| `open()`      | 打开文件并返回文件对象。                                     |
| `help()`      | 提供对象的帮助信息。                                         |
| `exit()`      | 终止程序的执行。                                             |

- `any()`: 判断可迭代对象中是否存在至少一个为真的元素。

```
list01 = [0, 0.0, (), []]
print(any(list01))

```

- `all()`: 判断可迭代对象中所有元素是否都为真。

```
list02 = [0, 3.14, "老王"]
print(all(list02))

```

- `zip()`: 将多个可迭代对象打包成一个元组序列。

```python
name_list = ["老王", "老刘", "老张头"]
age_list = [40, 60, 42]
tuple01 = tuple(zip(name_list, age_list))
print(tuple01)
dict01 = dict(zip(name_list, age_list))
print(dict01)

```

- `enumerate()`: 返回一个枚举对象，包含可迭代对象的索引和值。

```python
name_list = ["老王", "老刘", "老张头"]
for i, v in enumerate(name_list):
    print(f"i={i},v={v}")

```

## 作业

```python
-1
"""
编写一个程序,循环不停的写入日志 (my.log)。每2秒写入一行,要求每写入一行都要显示出来。结束程序后（强行结束）,
重新运行要求继续往下写，序号衔接
1. 2020-12-28  18:18:20
2. 2020-12-28  18:18:22
3. 2020-12-28  18:20:25
4. 2020-12-28  18:20:27

提示: time.ctime() 获取当前时间
    time.sleep() 间隔
# 每行及时显示
"""
from time import *

tm = "%d. %s\n" % (n, ctime())
time.sleep(2)

-2
"""
有一个`student_info.txt`的文本文件，刷选出身高超过180的所有学生信息并输出。
姓名,id,年龄,身高,性别
小红,3,18,172.3,女
小白,2,19,190.9,男
小帅,5,19,193.1,男
小明,1,17,183.5,男
小美,4,17,170.2,女
"""


```

