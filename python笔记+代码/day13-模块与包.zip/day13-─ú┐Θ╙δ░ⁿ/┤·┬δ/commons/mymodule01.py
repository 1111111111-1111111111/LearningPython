def greet(name):
    print("Hello " + name + "!")


def add(a, b):
    return a + b


def func01():
    print("func01")


def func02():
    print("func02")


def func03():
    print("func03")


name = "老王"

__all__ = ["greet", "add", "func01", "name"]

if __name__ == '__main__':
    greet("老王001")
    add(100, 1001)
    func01()
    func02()
    func03()
    print(name)
