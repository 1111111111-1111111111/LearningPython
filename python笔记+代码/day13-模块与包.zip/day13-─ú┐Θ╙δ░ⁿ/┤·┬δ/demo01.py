import time
print(time.time())
print(time.time())
time01 = time.localtime()
print(time01)
print(time01.tm_year)
print(list(time01)[1])
print(time.strftime('%Y %m %d')) # 紧接着后面跟上你要转换的时间
print(time.strftime('%Y %m %d %H:%M:%S'))











