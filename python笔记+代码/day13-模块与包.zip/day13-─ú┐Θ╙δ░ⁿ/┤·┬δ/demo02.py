import random

# 1.获取范围内的随机整数
value01 = random.randint(1, 10)
print(value01)

# 2.获取范围内的随机小数
value02 = random.uniform(1, 10.5)
print(value02)

# 3.随机获取一个元素
list01 = ["剪刀", "石头", "布"]
value03 = random.choice(list01)
print(value03)

# 4.随机获取多个元素
value04 = random.choices(list01, k=5)
print(value04)

value05 = random.choices(list01, k=3)
print(value05)

# 5.打乱顺序
num_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
random.shuffle(num_list)
print(num_list)
