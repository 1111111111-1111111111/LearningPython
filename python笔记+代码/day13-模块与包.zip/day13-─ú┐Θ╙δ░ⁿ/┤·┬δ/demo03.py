import pprint
import sys
pprint.pprint(sys.path)