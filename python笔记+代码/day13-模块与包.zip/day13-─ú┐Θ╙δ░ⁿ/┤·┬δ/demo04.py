import os

# 1.获取当前脚本绝对路径
abs_path = os.path.abspath(__file__)
print(abs_path)

# 2.获取当前文件的上级目录
base_path = os.path.dirname(abs_path)
print(base_path)

print(os.getcwd())

# 3.路径拼接
file_aa = os.path.join(base_path, 'aa')
print(file_aa)
file_aa_bb = os.path.join(base_path, 'aa', "bb", "info.txt")
print(file_aa_bb)

# 4.判断路径是否存在
print(os.path.exists(file_aa))
print(os.path.exists(os.path.join(base_path, 'commons')))

# 5.创建文件夹
if not os.path.exists(file_aa):
    os.makedirs(file_aa)

# 6.是否为文件夹
print(os.path.isdir(os.path.join(base_path, 'commons')))
print(os.path.isdir(abs_path))

# 7.是否为文件
print(os.path.isfile(os.path.join(base_path, 'commons')))
print(os.path.isfile(abs_path))

# 8.删除文件
# file_module03 = os.path.join(base_path, 'commons', 'mymodule03.py')
# os.remove(file_module03)

# 9.删除文件夹
os.rmdir(os.path.join(base_path, 'aa'))

# 10.获取指定文件夹包含的文件或者文件夹名字的列表
print(os.listdir(base_path))

# 11.获取文件大小
print(os.path.getsize(os.path.join(base_path, 'student_info.txt')))
