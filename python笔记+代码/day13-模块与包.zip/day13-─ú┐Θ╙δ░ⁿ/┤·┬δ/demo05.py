# python数据类型与json格式的相互转换
import json

# 数据类型 ——》json类型，序列化
data = [{"name": "小明", "age": 18}, {"name": "老王", "age": 40}]
result = json.dumps(data)
print(result)
print(type(result))

result = json.dumps(data, ensure_ascii=False)
print(result)
print(type(result))

# json类型 ——》数据类型，反序列化
data_list = json.loads(result)
print(data_list)
print(type(data_list))



data = [{"name": "小明", "age": 18}, {"name": "老王", "age": 40}]
with open("my_info.json", "w", encoding="utf-8") as file:
    json.dump(data, file, ensure_ascii=False)

with open("my_info.json", "r", encoding="utf-8") as file:
    value = json.load(file)
print(value)
print(value[0])
















