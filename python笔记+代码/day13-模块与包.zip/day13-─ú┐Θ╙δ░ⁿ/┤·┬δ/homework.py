# -1
"""
编写一个程序,循环不停的写入日志 (my.log)。每1秒写入一行,要求每写入一行都要显示出来。结束程序后（强行结束）,
重新运行要求继续往下写，序号衔接
1. 2020-12-28  18:18:20
2. 2020-12-28  18:18:22
3. 2020-12-28  18:20:25
4. 2020-12-28  18:20:27
提示: time.ctime() 获取当前时间
    time.sleep() 间隔
# 每行及时显示
"""
# 直接打印写入的内容
"""from time import *

with open('my.log', 'ab+') as file:
    while True:
        # 获取当前行数
        file.seek(0)
        line_count = len(file.readlines())
        next_line_count = line_count + 1

        # 生成新的日志行 4. 2020-12-28  18:20:27
        log_line = f"{next_line_count}. {ctime()}\n"

        # 写入文件并且刷新到磁盘
        file.write(log_line.encode('utf-8'))
        file.flush()

        # 打印最新的行
        print(log_line, end="")

        sleep(1)"""

# 读取文件内容并打印
"""from time import *

with open('my.log', 'ab+') as file:
    while True:
        # 获取当前行数
        file.seek(0)
        data_list = file.readlines()
        n = len(data_list) + 1

        # 生成新的日志行
        message = "%d. %s\n" % (n, ctime())
        file.write(message.encode('utf-8'))
        file.flush()

        # 读取并打印
        file.seek(0)
        new_data_list = file.readlines()
        print(new_data_list[-1].decode(), end="")

        sleep(1)"""

# -2
"""
有一个`student_info.txt`的文本文件，刷选出身高超过180的所有学生信息并输出。
姓名,id,年龄,身高,性别
小红,3,18,172.3,女
小白,2,19,190.9,男
小帅,5,19,193.1,男
小明,1,17,183.5,男
小美,4,17,170.2,女
"""
file = open('student_info.txt', "rb")
mess0 = file.readline()
while True:
    mess = file.readline().decode('utf-8')
    if not mess:
        break
    high = float(mess.split(",")[-2])
    if high > 180:
        print(mess, end="")
file.close()