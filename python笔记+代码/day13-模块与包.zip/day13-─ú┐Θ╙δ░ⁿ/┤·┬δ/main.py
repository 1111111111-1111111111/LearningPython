from commons.mymodule01 import *

if __name__ == '__main__':
    greet("老王")
    print(add(1, 1))
    print(name)
    func01()
    # func02()

    print(__name__)
    path = __file__
    print(path)
