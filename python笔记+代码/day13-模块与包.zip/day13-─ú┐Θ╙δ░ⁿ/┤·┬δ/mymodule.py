def greet(name):
    print("Hello " + name + "!")


def add(a, b):
    return a + b

print("1111")