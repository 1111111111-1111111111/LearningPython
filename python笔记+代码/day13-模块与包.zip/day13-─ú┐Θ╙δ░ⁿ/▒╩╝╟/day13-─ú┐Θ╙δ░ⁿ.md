# 模块与包

## 上节课回顾

```python
-open函数
	file_object = open(file_name, access_mode='r', buffering=-1，encoding=None)
	- 文件对象读取操作
    	read()
        readline()
        readlines()
        迭代文件对象本身
    - 文件对象写入操作
    	write(str)
        writelines(lines)
    - 关闭文件
    	file_object.close()
    - 文件偏移量
    	tell()
        seek(offset[,whence])
    - 读写缓冲区
    	file_obj.flush()
    - with语句
    	with 资源 as 变量:
- 内置函数    
	- any() 判断可迭代对象中是否存在至少一个为真的元素
    - all()	判断可迭代对象中所有元素是否都为真
    - zip() 将多个可迭代对象打包成一个元组序列
    - enumerate() 返回一个枚举对象，包含可迭代对象的索引和值
    
- 作业：       
-1
"""
编写一个程序,循环不停的写入日志 (my.log)。每2秒写入一行,要求每写入一行都要显示出来。结束程序后（强行结束）,
重新运行要求继续往下写，序号衔接
1. 2020-12-28  18:18:20
2. 2020-12-28  18:18:22
3. 2020-12-28  18:20:25
4. 2020-12-28  18:20:27
提示: time.ctime() 获取当前时间
    time.sleep() 间隔
# 每行及时显示
"""
# 直接打印写入的内容
from time import *

with open('my.log', 'ab+') as file:
    while True:
        # 获取当前行数
        file.seek(0)
        line_count = len(file.readlines())
        next_line_count = line_count + 1

        # 生成新的日志行 4. 2020-12-28  18:20:27
        log_line = f"{next_line_count}. {ctime()}\n"

        # 写入文件并且刷新到磁盘
        file.write(log_line.encode('utf-8'))
        file.flush()

        # 打印最新的行
        print(log_line, end="")

        sleep(1)

# 读取文件内容并打印
from time import *

with open('my.log', 'ab+') as file:
    while True:
        # 获取当前行数
        file.seek(0)
        data_list = file.readlines()
        n = len(data_list) + 1

        # 生成新的日志行
        message = "%d. %s\n" % (n, ctime())
        file.write(message.encode('utf-8'))
        file.flush()

        # 读取并打印
        file.seek(0)
        new_data_list = file.readlines()
        print(new_data_list[-1].decode(), end="")

        sleep(1)        

-2
"""
有一个`student_info.txt`的文本文件，刷选出身高超过180的所有学生信息并输出。
姓名,id,年龄,身高,性别
小红,3,18,172.3,女
小白,2,19,190.9,男
小帅,5,19,193.1,男
小明,1,17,183.5,男
小美,4,17,170.2,女
"""
file = open('student_info.txt', "rb")
mess0 = file.readline()
while True:
    mess = file.readline().decode('utf-8')
    if not mess:
        break
    high = float(mess.split(",")[-2])
    if high > 180:
        print(mess, end="")
file.close()

```

## 目标

```python
- 模块
	自定义模块
    模块导入语法
    	import
        import as
        from import 
        from import  *
        __all__
    内置变量
    	if __name__ == '__main__':
    常用模块 
    	time 提供了处理时间相关操作的函数
        random 生成随机数
        pprint 加强版print，输出更美化
        sys sys模块提供了一些变量和函数可以直接操作python解释器
        os os模块是Python标准库模块，包含了大量的文件处理函数。
- 包
- 第三方模块
	pip list            查询
    pip install 库名     安装
    pip uninstall 库名   卸载
```

## 1、模块

在Python中，模块是一种组织代码的方式，可以将相关的功能封装在一个单独的文件中，以便在其他程序中重复使用。Python中模块可以分为自定义的模块，第三方的模块，内置的模块

### 1.1 自定义模块

- **创建模块**：创建一个模块很简单，只需创建一个包含Python代码的文件，并以`.py`为扩展名。例如，创建一个名为`mymodule.py`的模块文件。

```python
# mymodule.py
def greet(name):
    print("Hello " + name + "!")


def add(a, b):
    return a + b
```

- **导入模块：** 在其他Python文件中，可以使用`import`关键字导入模块，然后使用模块中的功能。

```python
import mymodule

mymodule.greet("老王")
print(mymodule.add(1, 1))
```

当我们导入一个模块时，模块内的所有语句都会被执行。并创建一个模块对象，该对象包含了模块中定义的函数、类和变量等。以供后续导入和使用。

当你在一个程序中多次导入同一个模块时，模块内的代码只会在第一次导入时执行一次。后续的导入操作将直接使用先前创建的模块对象。

### 1.2 模块导入语法

- `import` 语句的作用是将整个模块导入到当前模块中。你可以使用模块名作为前缀来访问模块中的成员。

```python
import mymodule

mymodule.greet("老王")
print(mymodule.add(1, 1))

```



- `import` 语句也可以使用 `as` 关键字为模块设置别名，以便在当前模块中更方便地引用它。这对于模块名很长或容易与其他名称冲突的情况很有用。

```python
import mymodule as my

my.greet("老王")
print(my.add(1, 1))


```



- `from import` 语句用于从模块中导入特定的成员到当前模块的作用域中。你可以直接使用成员名进行访问，无需使用模块名前缀。这种方式可以减少代码中的冗长，并提供更直接的访问方式。

```python
from commons.mymodule01 import greet, add

greet("老王")
print(add(1, 1))


from commons.mymodule01 import greet as g
from commons.mymodule01 import add as a

g("老王")
print(a(1, 1))
```



- `from import *` 语句用于将一个模块中的所有成员导入到当前模块中。这种方式不推荐使用，因为它可能导致命名冲突和命名空间污染。通常建议明确导入所需的成员，以提高代码的可读性和可维护性。

```python
from commons.mymodule01 import *

greet("老王")
print(add(1, 1))
print(name)


```

- `__all__` 变量用于定义可以被导入的成员列表。当使用 `from module import *` 语句时，只有列在 `__all__` 变量中的成员才会被导入，其他成员将被视为隐藏成员。

```python
# mymodule01.py
def greet(name):
    print("Hello " + name + "!")


def add(a, b):
    return a + b


def func01():
    print("func01")


def func02():
    print("func02")


def func03():
    print("func03")


name = "老王"

__all__ = ["greet","add", "func01", "name"]


# main.py
from commons.mymodule01 import *

greet("老王")
print(add(1, 1))
print(name)
func01()
# func02()
```

### 1.3 内置变量

内置变量是Python语言本身提供的一些特殊变量，它们在解释器中预先定义，不需要导入任何模块就可以直接使用。这些内置变量具有特定的用途和功能。

- `__name__`：描述了当前模块的名称。当模块作为主程序直接执行时，`__name__` 的值为 `'__main__'`；当模块被其他模块导入时，`__name__` 的值为模块的名称。

```python
# commons.mymodule01
def greet(name):
    print("Hello " + name + "!")


def add(a, b):
    return a + b


def func01():
    print("func01")


def func02():
    print("func02")


def func03():
    print("func03")


name = "老王"

__all__ = ["greet","add", "func01", "name"]
print(__name__)

# main.py
from commons.mymodule01 import *

greet("老王")
print(add(1, 1))
print(name)
func01()
# func02()

print(__name__)

# 结论
	# 执行py文件
    __name__ == "__main__"
    
    # 导入的py文件
    __name__ == "模块名"
```

```python
# mymodule.py
def greet(name):
    print("Hello " + name + "!")


def add(a, b):
    return a + b


def func01():
    print("func01")


def func02():
    print("func02")


def func03():
    print("func03")


name = "老王"

__all__ = ["greet", "add", "func01", "name"]

if __name__ == '__main__':
    greet("老王001")
    add(100, 1001)
    func01()
    func02()
    func03()
    print(name)

# main.py
from commons.mymodule01 import *

if __name__ == '__main__':
    greet("老王")
    print(add(1, 1))
    print(name)
    func01()
    # func02()

    print(__name__)

```



- `__file__`：描述了当前模块所在的文件路径名

```python
path = __file__
    print(path)

```

### 1.4 常用模块

#### 1.4.1 time

- 获得时间戳：time.time()

```python
import time
print(time.time()) # 时间戳指：1970年1月1日开始到现在所经过的秒数
```

- 获得时间对象: time.localtime()

```python
import time

time01 = time.localtime()
print(time01)  # 返回一个时间对象，具体信息，并且可以单独拿到属性

# tm_year 代表当前年份
# tm_mon  代表当前月份
# tm_mday 代表当前日期
# tm_hour 代表当前小时
# tm_min  代表当前分钟
# tm_sec 代表当前秒数
# tm_wday=4, 代表当前的星期(范围0-6)
# tm_yday=250, 代表今年的第几天

print(time01.tm_year)
print(list(time01))

```

- 程序休眠: time.sleep(s)

```python
time.sleep(s) # 功能：让程序休眠s秒，休眠后程序继续执行

while True:
    time.sleep(1) # 休眠1秒
    print("hello,world") # 每隔1秒才输出1次

```

- 格式化时间

```python
time.localtime()时间看起来依旧不太舒服，可以使用格式化，改为自己习惯的格式

time.strftime() # 将时间转为字符串，自主格式化

# 需要记住一些特别的时间占位符
%Y 年 
%m 月  
%d 日 
%H 时 
%M 分 
%S 秒
# 技巧：只有 月 和 日 是小写，其余都是大写
print(time.strftime('%Y %m %d')) # 紧接着后面跟上你要转换的时间
print(time.strftime('%Y %m %d %H:%M:%S'))

```

#### 1.4.2 random

```python
import random

# 1.获取范围内的随机整数
value01 = random.randint(1, 10)
print(value01)

# 2.获取范围内的随机小数
value02 = random.uniform(1, 10.5)
print(value02)

# 3.随机获取一个元素
list01 = ["剪刀", "石头", "布"]
value03 = random.choice(list01)
print(value03)

# 4.随机获取多个元素
value04 = random.choices(list01, k=5)
print(value04)

value05 = random.choices(list01, k=3)
print(value05)

# 5.打乱顺序
num_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
random.shuffle(num_list)
print(num_list)

```

#### 1.4.3 pprint

pprint是加强版本的print，可以自动美化输出（输出格式化）

```python
import pprint 
pprint.pprint(输出内容)

import pprint

list01 = [i ** 2 for i in range(20)]
print(list01)
pprint.pprint(list01)

```



#### 1.4.4 sys

system ： 系统

sys模块提供了一些变量和函数可以直接操作python解释器

- sys.path : 返回一个列表，列表中保存的是模块的搜索路径

```python
import pprint
import sys
pprint.pprint(sys.path)

# 添加自定义模块的搜索路径
sys.path.append("路径")
```

- sys.exit() : 退出python程序

```python
import sys
print('hello,world')
sys.exit() # 直接结束程序！
print('hello,world')
"""
关于退出的语句:
	return: 结束函数
	break: 结束整个循环
	continue:跳过本次循环
	sys.exit()： 结束程序
"""


```

#### 1.4.5 os

os模块是Python标准库模块，包含了大量的文件处理函数。

```python
import os

# 1.获取当前脚本绝对路径
abs_path = os.path.abspath(__file__)
print(abs_path)

# 2.获取当前文件的上级目录
base_path = os.path.dirname(abs_path)
print(base_path)

print(os.getcwd())

# 3.路径拼接
file_aa = os.path.join(base_path, 'aa')
print(file_aa)
file_aa_bb = os.path.join(base_path, 'aa', "bb", "info.txt")
print(file_aa_bb)

# 4.判断路径是否存在
print(os.path.exists(file_aa))
print(os.path.exists(os.path.join(base_path, 'commons')))

# 5.创建文件夹
if not os.path.exists(file_aa):
    os.makedirs(file_aa)

# 6.是否为文件夹
print(os.path.isdir(os.path.join(base_path, 'commons')))
print(os.path.isdir(abs_path))

# 7.是否为文件
print(os.path.isfile(os.path.join(base_path, 'commons')))
print(os.path.isfile(abs_path))

# 8.删除文件
# file_module03 = os.path.join(base_path, 'commons', 'mymodule03.py')
# os.remove(file_module03)

# 9.删除文件夹
os.rmdir(os.path.join(base_path, 'aa'))

# 10.获取指定文件夹包含的文件或者文件夹名字的列表
print(os.listdir(base_path))

# 11.获取文件大小
print(os.path.getsize(os.path.join(base_path, 'student_info.txt')))

```



#### 1.4.6 json

json模块是python内置的一个模块，可以将python的数据格式转换成json格式的数据，也可以将json格式的数据转换为python的数据格式

json格式，是一个数据格式（本质上就是一个字符串，常用于网络数据传输）

```python
# python中的数据类型格式
data = [{"name": "小明", "age": 18}]

# json格式
value = '[{"name": "小明", "age": 18}]'
```

```python
json格式的主要作用：
可以被大部分编程语言所识别 跨语言 跨平台
跨语言数据传输

A系统 《——josn格式——》B系统
```

```python
# python数据类型与json格式的相互转换
import json

# 数据类型 ——》json类型，序列化
data = [{"name": "小明", "age": 18}, {"name": "老王", "age": 40}]
result = json.dumps(data)
print(result)
print(type(result))

result = json.dumps(data, ensure_ascii=False)
print(result)
print(type(result))

# json类型 ——》数据类型，反序列化
data_list = json.loads(result)
print(data_list)
print(type(data_list))

```

python的数据类型转换成json格式，对数据类型是有要求的，默认只支持：

|  python   |  json  |
| :-------: | :----: |
|   dict    | object |
|   list    | array  |
|    str    | string |
| int,float | number |
|   True    |  true  |
|   False   | false  |
|   None    |  null  |

写入和读取json文件

```python
# 写入json文件
data = [{"name": "小明", "age": 18}, {"name": "老王", "age": 40}]
with open("my_info.json", "w", encoding="utf-8") as file:
    json.dump(data, file, ensure_ascii=False)
```

```python
# 读取json文件
with open("my_info.json", "r", encoding="utf-8") as file:
    value = json.load(file)
print(value)
print(value[0])
```





## 2、包

在Python中，包是一种用于组织模块的层次结构。它允许将相关的模块放在一个目录中，以便更好地组织和管理代码。一个包通常包含一个特殊的 `__init__.py` 文件，用于标识该目录为一个包。 `__init__.py `中，你可以执行一些初始化工作。

```python
mypackage/
|-- __init__.py
|-- module1.py
|-- module2.py
|-- subpackage/
|   |-- __init__.py
|   |-- module3.py
```

`mypackage` 是一个包，包含了两个模块 `module1.py` 和 `module2.py`，以及一个子包 `subpackage`，其中包含了 `module3.py`。从Python 3.3版本开始，`__init__.py` 文件不再是必需的，但为了兼容和清晰性，建议保留这个文件。

当导入包时，`__init__.py ` 文件的代码会被执行一次。

## 3、第三方模块

Python的第三方模块是指由社区开发者创建和维护，非Python官方发布的软件包或库。这些模块极大地丰富了Python的功能，覆盖了从网络请求、数据分析、机器学习、Web框架、数据库操作到GUI开发等众多领域。使用第三方模块，开发者可以快速集成复杂功能，提高开发效率。 

如何安装第三方模块：需要使用到pip的管理工具

pip是一个第三方模块包管理工具，默认安装Python解释器时自动会安装

```python
pip install 模块名
——>安装第三方模块

pip list
——>查询安装的模块

pip uninstall 模块名
——>删除第三方模块
```

由于pip默认是从外网安装下载:https://pypi.org/
模块较小下载的话没有什么问题
模块较大下载速度就会比较慢

```python
换源安装：
pip install 模块名 -i https://pypi.tuna.tsinghua.edu.cn/simple
出现Successfully installed表示安装成功

requests（爬虫阶段就需要学习到的库）

PIP国内源:
1）清华大学
PIP源地址：https://pypi.tuna.tsinghua.edu.cn/simple
2）阿里云
PIP源地址：http://mirrors.aliyun.com/pypi/simple/
3）豆瓣
PIP源地址：http://pypi.douban.com/simple/
4）中国科学技术大学
PIP源地址：http://pypi.mirrors.ustc.edu.cn/simple/
5）华中科技大学
PIP源地址：http://pypi.hustunique.com/
```

