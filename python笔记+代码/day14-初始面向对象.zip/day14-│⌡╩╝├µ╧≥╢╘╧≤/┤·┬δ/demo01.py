class Person:
    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex

    def show(self):
        print(self.name, self.age, self.sex)

    def eat(self):
        print("在吃饭")

    def sleep(self, time):
        print(f"睡了{time}个小时")

    def play(self, thing):
        print(f"{self.name}在玩{thing}")


wang = Person("老王", 40, "男")
wang.show()
wang.eat()
wang.sleep(8)
wang.play("篮球")
print(wang.name)
print(wang.age)
wang.age += 1
print(wang.age)
wang.show()

liu = Person("老刘", 45, "男")
liu.show()
liu.eat()
liu.sleep(6)
