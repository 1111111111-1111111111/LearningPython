class Student:
    # 类属性
    cid = 1001

    def __init__(self, name):
        # 实例属性
        self.name = name
        self.cid = Student.cid
        Student.cid += 1


stu01 = Student("aa")
print(stu01.cid)

stu02 = Student("bb")
print(stu02.cid)

stu03 = Student("cc")
print(stu03.cid)

print(Student.cid)