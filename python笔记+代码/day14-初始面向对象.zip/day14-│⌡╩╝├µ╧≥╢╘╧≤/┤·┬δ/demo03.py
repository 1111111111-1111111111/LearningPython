def func():
    """
    func干什么用的
    :return:
    """
    pass


print(func.__doc__)


class A:
    """
    类文档
    对类中的属性进行说明
    方法函数的说明
    类的说明书
    """
    pass


print(A.__doc__)
