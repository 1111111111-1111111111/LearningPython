# 老王旅游乘坐交通工具
class Person:
    def __init__(self, name):
        self.name = name

    def go_to(self, vehicle, position):
        print(self.name, "去", position)
        vehicle.run()


class Car:
    def run(self):
        print("出发喽！")


lw = Person("老王")
daben = Car()
baoma = Car()
lw.go_to(daben, "东北")
lw.go_to(baoma, "东北")
