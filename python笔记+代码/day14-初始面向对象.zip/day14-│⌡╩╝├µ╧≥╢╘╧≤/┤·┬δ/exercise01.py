# 支行与总行之间钱的关系
class ICBC:
    """
        工商银行
    """
    # 类变量：总行的钱
    total_money = 10000000

    # 类方法：操作类变量
    @classmethod
    def print_money(cls):
        # print("总行的钱：", ICBC.total_money)
        print("总行的钱：", cls.total_money)

    def __init__(self, name, money=0):
        # 实例属性
        self.name = name
        # 支行的钱
        self.money = money
        # 创建支行，总行的钱会变少
        ICBC.total_money -= money

    # 实例方法
    def show(self):
        print(f"{self.name}: {self.money}")


ttzh = ICBC("天坛支行", 1000000)
ttzh.show()
ICBC.print_money()
xdzh = ICBC("西单支行", 2000000)
xdzh.show()
# print(ICBC.total_money)
ICBC.print_money()
