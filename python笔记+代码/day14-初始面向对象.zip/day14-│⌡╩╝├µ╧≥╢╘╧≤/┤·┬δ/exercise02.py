"""
创建狗类，实例化两个对象并调用其函数
数据：品种、昵称、身长、体重
行为：吃(体重增长)十分之一
"""


class Dog:
    def __init__(self, breed, name, long, weight):
        self.breed = breed
        self.name = name
        self.long = long
        self.weight = weight

    def show(self):
        print(f"品种{self.breed}、昵称{self.name}、身长{self.long}、体重{self.weight}")

    def eat(self, kg):
        self.weight += kg / 10
        self.show()


dog01 = Dog("哈士奇", "哈哈", 50, 10)
dog02 = Dog("拉布拉多", "小拉", 100, 30)
dog01.show()
dog02.show()
dog01.eat(10)
dog02.eat(20)
