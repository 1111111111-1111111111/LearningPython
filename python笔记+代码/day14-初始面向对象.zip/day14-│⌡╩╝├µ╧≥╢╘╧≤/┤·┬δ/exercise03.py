"""
创建一个学生类（Student）、
实例属性：
	姓名、年龄、性别、总分、学号、（根据实例对象创建顺序自动生成且不重复）
实例方法：
	展示学生信息
	修改成绩
	根据分数判定学习等级
"""


class Student:
    # 类变量
    stu_cid = 1001

    # 查看下一个学生的学号
    @classmethod
    def get_stu_cid(cls):
        return cls.stu_cid

    def __init__(self, name, age, sex, score):
        self.name = name
        self.age = age
        self.sex = sex
        self.score = score
        self.cid = Student.stu_cid
        Student.stu_cid += 1

    # 展示学生信息
    def show(self):
        print(f"姓名:{self.name} 年龄:{self.age} 性别:{self.sex} 总分:{self.score} 学号:{self.cid}")

    # 修改成绩
    def change_score(self, score):
        self.score = score
        print("成绩修改成功")
        self.show()

    # 根据分数判定学习等级
    def grade(self):
        if self.score >= 90:
            print(self.name, "优秀")
        elif self.score >= 75:
            print(self.name, "良好")
        elif self.score >= 60:
            print(self.name, "及格")
        else:
            print(self.name, "不及格")


stu01 = Student("小明", 18, "男", 90)
stu02 = Student("小美", 17, "女", 80)
stu03 = Student("小花", 19, "女", 59)
stu01.show()
stu02.show()
stu03.show()
stu01.change_score(100)
stu01.grade()
stu02.grade()
stu03.grade()
