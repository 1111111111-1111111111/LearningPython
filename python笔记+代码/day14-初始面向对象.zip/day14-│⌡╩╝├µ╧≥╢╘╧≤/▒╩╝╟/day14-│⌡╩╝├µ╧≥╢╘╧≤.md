# 初始面向对象

## 上节课回顾

```python
- 模块
	自定义模块
    模块导入语法
    	import
        import as
        from import 
        from import  *
        __all__
    内置变量
    	if __name__ == '__main__':
    常用模块 
    	time 提供了处理时间相关操作的函数
        random 生成随机数
        pprint 加强版print，输出更美化
        sys sys模块提供了一些变量和函数可以直接操作python解释器
        os os模块是Python标准库模块，包含了大量的文件处理函数。
        json
- 包
- 第三方模块
	pip list            查询
    pip install 库名     安装
    pip uninstall 库名   卸载
```

## 目标

```python
- 编程范式
	-面向过程
	-面向对象
- 类和对象
	-创建和使用
    -__init__ 初始化方法
    - self与属性
    -类文档
```

## 1、编程范式

面向对象是一种编程范式，编程范式是一种编程方法论。

编程范式是指编程语言中用于指导程序结构和设计的模式，它定义了编写程序时的规则、方法和技巧。不同的编程范式提供了不同的视角和方法来组织代码，解决计算问题。 不同的编程语言就遵循这不同的编程范式，面向对象就是其中的一种。

### 面向过程

- 分析出解决问题的步骤，然后逐步实现

  ```python
  婚礼筹办
      -- 请柬（选照片、措词、制作）
      -- 宴席（场地、找厨师、准备桌椅餐具、计划菜品、购买食材）
      -- 仪式（定婚礼仪式流程、请主持人）
  ```

- 优点：所有环节、细节自己掌控
- 缺点：考虑所有细节，工作量大

### 面向对象

- 找出解决问题的人，然后分配职责

  ```python
  婚礼筹办
      -- 发请柬：找摄影公司（拍照片、制作请柬）
      -- 宴席：找酒店（告诉对方标准、数量、挑选菜品）
      -- 婚礼仪式：找婚庆公司（对方提供司仪、制定流程、提供设备、帮助执行）
  ```

- 优势

```python
思想层面：
    -- 可模拟现实情景，更接近于人类思维
    -- 有利于梳理归纳、分析解决问题
技术层面：    
    -- 高复用：对重复的代码进行封装，提高开发效率。
    -- 高扩展：增加新的功能，不修改以前的代码。
    -- 高维护：代码可读性好，逻辑清晰，结构规整	 
```

面向对象编程可以帮助我们从宏观上把握和分析问题，但具体的实现细节仍然可以使用面向过程的思路。面向对象和面向过程不是对立的，而是相辅相成的。

## 2、类和对象

类：一个抽象的概念，从具体事物中抽离出共性、本质，舍弃个别、非本质过程。在程序中为了创建具有**共同特征**和**行为**的一组对象而定义的一个“模板”

对象：拥有**属性**以及**行为**的实体；在程序中是通过类来创建的

```python
**手机**
你用的那个小米手机就是对象，手机有特征和行为
特征：
	- 品牌：华为，苹果，小米
    - 颜色：
    - 价格:
行为:
    - 聊天
    - 电话
    - 打游戏
    - 刷剧
    
**车**
小米yu7就是对象，车有特征和行为
特征：
	- 品牌：兰博基尼 雪佛兰 马自达
    - 颜色：
    - 价格:
行为:
    - 代步
    - 运输 
```

### 2.1创建和使用

```python
语法：
- 定义类
	class 类名:
    	"""
    	文档说明
    	"""
    	def __init__(self,参数):
    		self.实例变量 = 参数
    	方法成员
 
- 创建对象/实例化一个具体的对象
    变量 = 类名(参数)
        
类名：使用大驼峰命名法，首字母大写，如果有多个单词，每一个首字母都大写    
```

```python
class Person:
    def eat(self):
        print("在吃饭")

    def sleep(self, time):
        print(f"睡了{time}个小时")


wang = Person()
wang.eat()
wang.sleep(8)

liu = Person()
liu.eat()
liu.sleep(6)
```

### 2.2  _\_init\_\_ 初始化方法

- __ init __ 也叫构造函数，创建对象时被调用，也可以省略,用来设计对象自身属性

```python
class Person:
    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex

    def show(self):
        print(self.name, self.age, self.sex)

    def eat(self):
        print("在吃饭")

    def sleep(self, time):
        print(f"睡了{time}个小时")


wang = Person("老王", 40, "男")
wang.show()
wang.eat()
wang.sleep(8)

liu = Person("老刘", 45, "男")
liu.show()
liu.eat()
liu.sleep(6)

```

### 2.3 self与属性

self:表示实例对象自己，实例在调用方法的时候，方法中的self代表当前调用这个方法的对象

```python
class Person:
    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex

    def show(self):
        print(self.name, self.age, self.sex)

    def eat(self):
        print("在吃饭")

    def sleep(self, time):
        print(f"睡了{time}个小时")

    def play(self, thing):
        print(f"{self.name}在玩{thing}")


wang = Person("老王", 40, "男")
wang.show()
wang.eat()
wang.sleep(8)
wang.play("篮球")
print(wang.name)
print(wang.age)
wang.age += 1
print(wang.age)
wang.show()

liu = Person("老刘", 45, "男")
liu.show()
liu.eat()
liu.sleep(6)


```

属性分2种：

- 实例属性：在init里面通过self来定义的，是各个对象独立的

- 类属性：直接定义在类名下面。 

  ```python
  类属性是可以由类和实例都能直接访问，并且它是创建在类的空间中。可以用类属性去做记录
  class Student:
      # 类属性
      cid = 1001
  
      def __init__(self, name):
          # 实例属性
          self.name = name
          self.cid = Student.cid
          Student.cid += 1
  
  
  stu01 = Student("aa")
  print(stu01.cid)
  
  stu02 = Student("bb")
  print(stu02.cid)
  
  stu03 = Student("cc")
  print(stu03.cid)
  
  print(Student.cid)
  
  
  ```

- 区别总结

  - 定义位置：
    实例属性：在init方法中使用 self 关键字定义
    类属性：直接在类体内定义，不使用self关键字定义
  - 作用范围：
    实例属性：每个实例都有自己独立的空间，独立的实例属性，互不共享
    类属性：所有实例共享同一个类属性，修改类属性会影响所有实例对象
  - 使用场景：
    实例属性：适用于需要在每个实例中存储不同数据的情况。
    类属性：适用于需要所有实例之间共享相同数据的情况。 

### 2.4类方法

```python
语法：
	@classmethod
 	def 方法名称(cls,参数):
    	方法体
        
类名.方法名(参数)
 # 不建议通过对象访问类方法
    
# 支行与总行之间钱的关系
class ICBC:
    """
        工商银行
    """
    # 类变量：总行的钱
    total_money = 10000000

    # 类方法：操作类变量
    @classmethod
    def print_money(cls):
        # print("总行的钱：", ICBC.total_money)
        print("总行的钱：", cls.total_money)

    def __init__(self, name, money=0):
        # 实例属性
        self.name = name
        # 支行的钱
        self.money = money
        # 创建支行，总行的钱会变少
        ICBC.total_money -= money

    # 实例方法
    def show(self):
        print(f"{self.name}: {self.money}")


ttzh = ICBC("天坛支行", 1000000)
ttzh.show()
ICBC.print_money()
xdzh = ICBC("西单支行", 2000000)
xdzh.show()
# print(ICBC.total_money)
ICBC.print_money()

```



### 2.5类文档

```python
def func():
    """
    func干什么用的
    :return:
    """
    pass


print(func.__doc__)


class A:
    """
    类文档
    对类中的属性进行说明
    方法函数的说明
    类的说明书
    """
    pass


print(A.__doc__)


```

练习：

```python
"""
创建狗类，实例化两个对象并调用其函数
数据：品种、昵称、身长、体重
行为：吃(体重增长)十分之一
"""
"""
创建狗类，实例化两个对象并调用其函数
数据：品种、昵称、身长、体重
行为：吃(体重增长)十分之一
"""


class Dog:
    def __init__(self, breed, name, long, weight):
        self.breed = breed
        self.name = name
        self.long = long
        self.weight = weight

    def show(self):
        print(f"品种{self.breed}、昵称{self.name}、身长{self.long}、体重{self.weight}")

    def eat(self, kg):
        self.weight += kg / 10
        self.show()


dog01 = Dog("哈士奇", "哈哈", 50, 10)
dog02 = Dog("拉布拉多", "小拉", 100, 30)
dog01.show()
dog02.show()
dog01.eat(10)
dog02.eat(20)



"""
创建一个学生类（Student）、
实例属性：
	姓名、年龄、性别、总分、学号、（根据实例对象创建顺序自动生成且不重复）
实例方法：
	展示学生信息
	修改成绩
	根据分数判定学习等级
"""
"""
创建一个学生类（Student）、
实例属性：
	姓名、年龄、性别、总分、学号、（根据实例对象创建顺序自动生成且不重复）
实例方法：
	展示学生信息
	修改成绩
	根据分数判定学习等级
"""


class Student:
    # 类变量
    stu_cid = 1001

    # 查看下一个学生的学号
    @classmethod
    def get_stu_cid(cls):
        return cls.stu_cid

    def __init__(self, name, age, sex, score):
        self.name = name
        self.age = age
        self.sex = sex
        self.score = score
        self.cid = Student.stu_cid
        Student.stu_cid += 1

    # 展示学生信息
    def show(self):
        print(f"姓名:{self.name} 年龄:{self.age} 性别:{self.sex} 总分:{self.score} 学号:{self.cid}")

    # 修改成绩
    def change_score(self, score):
        self.score = score
        print("成绩修改成功")
        self.show()

    # 根据分数判定学习等级
    def grade(self):
        if self.score >= 90:
            print(self.name, "优秀")
        elif self.score >= 75:
            print(self.name, "良好")
        elif self.score >= 60:
            print(self.name, "及格")
        else:
            print(self.name, "不及格")


stu01 = Student("小明", 18, "男", 90)
stu02 = Student("小美", 17, "女", 80)
stu03 = Student("小花", 19, "女", 59)
stu01.show()
stu02.show()
stu03.show()
stu01.change_score(100)
stu01.grade()
stu02.grade()
stu03.grade()


```

## 3、跨类调用

```python
# 写法1：直接创建对象
# 老王每次旅游开一辆新的车去
class Person:
    def __init__(self, name):
        self.name = name

    def go_to(self, position):
        print(self.name, "去", position)
        car = Car()
        car.run()


class Car:
    def run(self):
        print("出发喽！")


lw = Person("老王")
lw.go_to("东北")
lw.go_to("东北")


```

```python
# 写法2：在构造函数中创建对象
# 老王旅游开自己的车去
class Person:
    def __init__(self, name):
        self.name = name
        self.car = Car()

    def go_to(self, position):
        print(self.name, "去", position)
        self.car.run()


class Car:
    def run(self):
        print("出发喽！")


lw = Person("老王")
lw.go_to("东北")
lw.go_to("东北")


```

```python
# 方式3：通过参数传递
# 老王旅游乘坐交通工具
class Person:
    def __init__(self, name):
        self.name = name

    def go_to(self, vehicle, position):
        print(self.name, "去", position)
        vehicle.run()


class Car:
    def run(self):
        print("出发喽！")


lw = Person("老王")
daben = Car()
baoma = Car()
lw.go_to(daben, "东北")
lw.go_to(baoma, "东北")


```



##  作业

```python
"""
定义手机类
	实例属性：
		例属性：
    	brand # 手机品牌
    	model # 手机型号
    	color # 颜色
    	price # 价格
    	...
    方法：
  		describe(self) # 会介绍该手机的品牌，型号，颜色，价格
  		call(self, minute) # 打了几分钟的电话
"""
```









