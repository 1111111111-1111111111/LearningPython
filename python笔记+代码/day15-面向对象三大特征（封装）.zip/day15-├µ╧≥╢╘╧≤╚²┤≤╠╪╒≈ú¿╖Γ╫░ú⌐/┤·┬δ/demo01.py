class MyClass(object):
    def __init__(self, data):
        # 私有属性
        self.__data = data

    # 私有方法
    def __func01(self):
        print("func01")

    # 暴露必要的接口
    def show(self):
        print(self.__data)
        self.__func01()


m01 = MyClass(10)
# print(m01.data)
# m01.func01()
m01.show()

# 君子协议
print(m01.__dict__)
print(m01._MyClass__data)
m01._MyClass__func01()
