class Student(object):
    def __init__(self):
        self.__age = None

    def get_age(self):
        print("获取属性时执行的代码")
        return self.__age

    def set_age(self, age):
        print("修改属性时执行的代码")
        self.__age = age

    def del_age(self):
        print("删除属性时执行的代码")
        del self.__age

    age = property(get_age, set_age, del_age)


stu01 = Student()
# 设置属性
stu01.age = 18
# 获取属性
print(stu01.age)
# 删除属性
del stu01.age
print(stu01.__dict__)
