class Student(object):
    def __init__(self):
        self.score = 100
        self.__age = None

    @property
    def age(self):
        """可读"""
        print("获取属性时执行的代码")
        return self.__age

    @age.setter
    def age(self, age):
        """可改"""
        print("修改属性时执行的代码")
        self.__age = age

    @age.deleter
    def age(self):
        """可删"""
        print("删除属性时执行的代码")
        del self.__age

    # 属性
    @property
    def print_score(self):
        print(self.score)


stu01 = Student()
# 设置属性
stu01.age = 18
# 获取属性
print(stu01.age)
# 删除属性
del stu01.age
print(stu01.__dict__)
stu01.print_score
print(stu01.__dict__)
