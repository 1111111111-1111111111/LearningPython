#  读取属性
"""class MyClass(object):
    def __init__(self, data):
        self.__data = data

    @property
    def data(self):
        return self.__data

    @data.setter
    def data(self, value):
        self.__data = value


m01 = MyClass(10)
print(m01.data)
m01.data = 20
print(m01.data)"""

# 2. 只读属性
"""class MyClass(object):
    def __init__(self, data):
        self.__data = data

    @property
    def data(self):
        return self.__data


m01 = MyClass(10)
print(m01.data)
# m01.data = 20"""


# 3. 只写属性
class MyClass(object):
    def __init__(self, data):
        self.__data = data

    def data(self, value):
        self.__data = value

    # property(fget = None , fset = None , fdel = None)
    # fget 是获取属性值的方法
    # fset 是设置(修改)属性值的方法
    # fdel 是删除属性值的方法

    data = property(fset=data)


m01 = MyClass(10)
print(m01.__dict__)
# print(m01.data)
m01.data = 20
print(m01.__dict__)
