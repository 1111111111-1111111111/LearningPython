# 用类做数据封装
class UserInfo:
    def __init__(self, name, password):
        self.name = name
        self.password = password


def login():
    """
    注册的操作
    :return:
    """
    user_list = []
    # 用户注册
    while True:
        username = input("请输入用户的名字：")
        if username == '##':
            break
        password = input("请输入密码：")
        user = UserInfo(username, password)
        # user_dict = {"username": username, "password": password}
        user_list.append(user)

    for user in user_list:
        print(user.name, user.password)


login()
