# 数据 + 方法的封装
class GameRole:
    """游戏角色"""

    def __init__(self, name, blood, attack=100, defense=40):
        self.name = name
        self.blood = blood
        self.attack = attack
        self.defense = defense

    def show(self):
        """查看角色状态"""
        message = f"角色{self.name}的生命值为：{self.blood} 攻击力为：{self.attack} 防御值为：{self.defense}"
        print(message)

    def skill(self, other_role):
        """对其他英雄发起攻击"""
        print(f"{self.name}对{other_role.name}发起了攻击")
        true_damage = self.attack - other_role.defense
        other_role.blood -= true_damage
        other_role.show()

    def range_skill(self, *args):
        """发动范围攻击"""
        for role in args:
            # print(f"{self.name}对{role.name}发起了攻击")
            # true_damage = self.attack - role.defense
            # role.blood -= true_damage
            # role.show()
            self.skill(role)


libai = GameRole("李白", 1500, 200, 20)
libai.show()
xiangyu = GameRole("项羽", 5000, defense=100)
xiangyu.show()
libai.skill(xiangyu)
aa = GameRole("aa", 2000)
bb = GameRole("bb", 2000)
cc = GameRole("cc", 2000)
libai.range_skill(aa, bb, cc)
