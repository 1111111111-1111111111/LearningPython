# 银行
class Bank:
    """银行系统"""

    def __init__(self, card, password, money):
        self.card = card
        self.__password = password
        self.__money = money

    def show_money(self, password):
        """展示私有属性money"""
        if password == self.__password:
            print(f"您的余额为：{self.__money}")

    def __show_password(self):
        """私有方法，显示密码"""
        print(f"您的密码为：{self.__password}")

    def change_password(self, password):
        """修改密码"""
        if password == self.__password:
            new_password = input("请输入新的密码：")
            self.__password = new_password
            print(f"密码修改成功")
            self.__show_password()
        else:
            print("您的密码有误！")

    def spend(self, pay_money):
        """花钱消费"""
        self.__money -= pay_money
        self.show_money(self.__password)

    def saving(self, save_money):
        self.__money += save_money
        self.show_money(self.__password)


people01 = Bank("123456", "111111", 10000)
print(people01.card)
people01.show_money("111111")
people01.change_password("111111")
people01.spend(2000)
people01.saving(500)