class Rectangle(object):
    """长方形的类"""

    def __init__(self, length, width):
        self.__length = length
        self.__width = width

    @property
    def length(self):
        """可读"""
        return self.__length

    @length.setter
    def length(self, value):
        """修改权限"""
        if value > 0:
            self.__length = value
        else:
            # 主动抛出异常
            raise ValueError("长度必须为正数")

    @property
    def width(self):
        """可读"""
        return self.__width

    @width.setter
    def width(self, value):
        """修改权限"""
        if value > 0:
            self.__width = value
        else:
            # 主动抛出异常
            raise ValueError("宽度必须为正数")

    @property
    def area(self):
        return self.__length * self.__width


# 创建实例对象
rect = Rectangle(10, 5)

# 访问实例属性
print(rect.length)
print(rect.width)

# 修改实例属性
rect.length = 15
rect.width = 10

# 访问实例属性
print(rect.length)
print(rect.width)

print(rect.area)
