"""
定义手机类
	实例属性：
		例属性：
    	brand # 手机品牌
    	model # 手机型号
    	color # 颜色
    	price # 价格
    	...
    方法：
  		describe(self) # 会介绍该手机的品牌，型号，颜色，价格
  		call(self, minute) # 打了几分钟的电话
"""


class Phone:
    def __init__(self, brand, model, color, price):
        self.brand = brand
        self.model = model
        self.color = color
        self.price = price

    def describe(self):
        print(f"手机品牌: {self.brand} 手机型号: {self.model} 颜色: {self.color} 价格: {self.price}")

    def call(self, minutes):
        print(f"打了{minutes}分钟电话")


# 创建实例对象
phone01 = Phone("小米", 14, "珍珠白", 4000)
phone01.describe()
phone01.call(30)

phone02 = Phone("苹果", "15pro", "暗夜紫", 14000)
phone02.describe()
phone02.call(5)