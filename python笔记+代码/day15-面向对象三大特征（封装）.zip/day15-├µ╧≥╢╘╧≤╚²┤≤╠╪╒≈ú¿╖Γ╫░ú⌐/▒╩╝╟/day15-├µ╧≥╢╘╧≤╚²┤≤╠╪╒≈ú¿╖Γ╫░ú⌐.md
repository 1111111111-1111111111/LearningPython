# 面向对象三大特征（封装）

## 上节课回顾

```python
- 编程范式
	-面向过程：
    	分析出解决问题的步骤，然后逐步实现
    -面向对象
    	找出解决问题的人，然后分配职责
- 类和对象
	类：在程序中为了创建具有共同特征和行为的一组对象而定义的一个“模板”
    对象：拥有属性以及行为的实体；在程序中是通过类来创建的
	-创建和使用
    语法：
    	类的创建：
    	class 类名: #大驼峰命名法
    		"""
    		文档说明
    		"""
    		def __init__(self,参数):
                """__ init __ 也叫构造函数，创建对象时被调用，也可以省略,用来设计对象自身属性"""
    			self.实例变量 = 参数
    		方法成员
        对象的创建 ：
    	变量 = 类名(参数)
    -self与属性
    	self:表示实例对象自己，实例在调用方法的时候，方法中的self代表当前调用这个方法的对象
        实例属性：在init里面通过self来定义的，是各个对象独立的
        类属性：直接定义在类名下面。
	-类文档

- 作业
"""
定义手机类
	实例属性：
		例属性：
    	brand # 手机品牌
    	model # 手机型号
    	color # 颜色
    	price # 价格
    	...
    方法：
  		describe(self) # 会介绍该手机的品牌，型号，颜色，价格
  		call(self, minute) # 打了几分钟的电话
"""
class Phone:
    def __init__(self, brand, model, color, price):
        self.brand = brand
        self.model = model
        self.color = color
        self.price = price

    def describe(self):
        print(f"手机品牌: {self.brand} 手机型号: {self.model} 颜色: {self.color} 价格: {self.price}")

    def call(self, minutes):
        print(f"打了{minutes}分钟电话")


# 创建实例对象
phone01 = Phone("小米", 14, "珍珠白", 4000)
phone01.describe()
phone01.call(30)

phone02 = Phone("苹果", "15pro", "暗夜紫", 14000)
phone02.describe()
phone02.call(5)
```

# 面向对象应用示例

```python
# 用类做数据封装
class UserInfo:
    def __init__(self, name, password):
        self.name = name
        self.password = password


def login():
    """
    注册的操作
    :return:
    """
    user_list = []
    # 用户注册
    while True:
        username = input("请输入用户的名字：")
        if username == '##':
            break
        password = input("请输入密码：")
        user = UserInfo(username, password)
        # user_dict = {"username": username, "password": password}
        user_list.append(user)

    for user in user_list:
        print(user.name, user.password)


login()


```



```python
# 数据 + 方法的封装
class GameRole:
    """游戏角色"""

    def __init__(self, name, blood, attack=100, defense=40):
        self.name = name
        self.blood = blood
        self.attack = attack
        self.defense = defense

    def show(self):
        """查看角色状态"""
        message = f"角色{self.name}的生命值为：{self.blood} 攻击力为：{self.attack} 防御值为：{self.defense}"
        print(message)

    def skill(self, other_role):
        """对其他英雄发起攻击"""
        print(f"{self.name}对{other_role.name}发起了攻击")
        true_damage = self.attack - other_role.defense
        other_role.blood -= true_damage
        other_role.show()

    def range_skill(self, *args):
        """发动范围攻击"""
        for role in args:
            # print(f"{self.name}对{role.name}发起了攻击")
            # true_damage = self.attack - role.defense
            # role.blood -= true_damage
            # role.show()
            self.skill(role)


libai = GameRole("李白", 1500, 200, 20)
libai.show()
xiangyu = GameRole("项羽", 5000, defense=100)
xiangyu.show()
libai.skill(xiangyu)
aa = GameRole("aa", 2000)
bb = GameRole("bb", 2000)
cc = GameRole("cc", 2000)
libai.range_skill(aa, bb, cc)


```



# 三大特征

# 1.封装

面向对象的封装是指将数据和操作数据的方法打包在一起，形成一个类。这个类对外部隐藏了其内部的具体实现细节，只暴露一些必要的接口，使得对象的使用者无需关心对象内部是如何实现的。

## 1.1属性隐藏

隐藏：刻意将一些属性和方法隐藏在类的内部，使得在使用此类时，无法直接调用这些属性或方法，只能通过未隐藏的类方法间接操作。在Python中使用双下划线开头的方式将属性或方法隐藏起来（设置成私有的），即双下划线前缀。私有成员的名称被修改为：`_类名__成员名`。

```python
做法：命名使用双下划线开头
本质：障眼法，实际也可以访问

class MyClass(object):
    def __init__(self, data):
        # 私有属性
        self.__data = data

    # 私有方法
    def __func01(self):
        print("func01")

    # 暴露必要的接口
    def show(self):
        print(self.__data)
        self.__func01()


m01 = MyClass(10)
# print(m01.data)
# m01.func01()
m01.show()

# 君子协议
print(m01.__dict__)
print(m01._MyClass__data)
m01._MyClass__func01()


```

```python
# 银行
class Bank:
    """银行系统"""

    def __init__(self, card, password, money):
        self.card = card
        self.__password = password
        self.__money = money

    def show_money(self, password):
        """展示私有属性money"""
        if password == self.__password:
            print(f"您的余额为：{self.__money}")

    def __show_password(self):
        """私有方法，显示密码"""
        print(f"您的密码为：{self.__password}")

    def change_password(self, password):
        """修改密码"""
        if password == self.__password:
            new_password = input("请输入新的密码：")
            self.__password = new_password
            print(f"密码修改成功")
            self.__show_password()
        else:
            print("您的密码有误！")

    def spend(self, pay_money):
        """花钱消费"""
        self.__money -= pay_money
        self.show_money(self.__password)

    def saving(self, save_money):
        self.__money += save_money
        self.show_money(self.__password)


people01 = Bank("123456", "111111", 10000)
print(people01.card)
people01.show_money("111111")
people01.change_password("111111")
people01.spend(2000)
people01.saving(500)

```



## 1.2property()函数

property函数用于创建一个对象，该对象可以作为类属性使用，可以设置、获取、删除对象属性，可以限制用户对属性的获取（访问）与设置(修改)

```python
property(fget = None , fset = None , fdel = None)

# fget 是获取属性值的方法
# fset 是设置(修改)属性值的方法
# fdel 是删除属性值的方法
```

```python
class Student(object):
    def __init__(self):
        self.__age = None

    def get_age(self):
        print("获取属性时执行的代码")
        return self.__age

    def set_age(self, age):
        print("修改属性时执行的代码")
        self.__age = age

    def del_age(self):
        print("删除属性时执行的代码")
        del self.__age

    age = property(get_age, set_age, del_age)


stu01 = Student()
# 设置属性
stu01.age = 18
# 获取属性
print(stu01.age)
# 删除属性
del stu01.age
print(stu01.__dict__)


```



## 1.3@property装饰器

它通过将类的方法转换为属性，使得可以像访问普通属性一样访问方法的返回值，并且可以通过定义 `getter` 和 `setter` 方法来控制属性的访问和修改。这使得可以在保持简单访问语法的同时，进行更复杂的逻辑处理和验证。

```python
@property提供了比 property() 函数更简洁直观的写法。

被 @property 装饰的方法是获取属性值的方法，被装饰方法的名字会被用做 属性名。
被 @属性名.setter 装饰的方法是设置属性值的方法。
被 @属性名.deleter 装饰的方法是删除属性值的方法。
```

```python
class Student(object):
    def __init__(self):
        self.score = 100
        self.__age = None

    @property
    def age(self):
        """可读"""
        print("获取属性时执行的代码")
        return self.__age

    @age.setter
    def age(self, age):
        """可改"""
        print("修改属性时执行的代码")
        self.__age = age

    @age.deleter
    def age(self):
        """可删"""
        print("删除属性时执行的代码")
        del self.__age

    # 属性
    @property
    def print_score(self):
        print(self.score)


stu01 = Student()
# 设置属性
stu01.age = 18
# 获取属性
print(stu01.age)
# 删除属性
del stu01.age
print(stu01.__dict__)
stu01.print_score
print(stu01.__dict__)


```

练习：

```python
class Rectangle(object):
    """长方形的类"""

    def __init__(self, length, width):
        self.__length = length
        self.__width = width

    @property
    def length(self):
        """可读"""
        return self.__length

    @length.setter
    def length(self, value):
        """修改权限"""
        if value > 0:
            self.__length = value
        else:
            # 主动抛出异常
            raise ValueError("长度必须为正数")

    @property
    def width(self):
        """可读"""
        return self.__width

    @width.setter
    def width(self, value):
        """修改权限"""
        if value > 0:
            self.__width = value
        else:
            # 主动抛出异常
            raise ValueError("宽度必须为正数")

    @property
    def area(self):
        return self.__length * self.__width


# 创建实例对象
rect = Rectangle(10, 5)

# 访问实例属性
print(rect.length)
print(rect.width)

# 修改实例属性
rect.length = 15
rect.width = 10

# 访问实例属性
print(rect.length)
print(rect.width)

print(rect.area)


```

## 1.4属性的设置

```python
#  读取属性
#  读取属性
class MyClass(object):
    def __init__(self, data):
        self.__data = data

    @property
    def data(self):
        return self.__data

    @data.setter
    def data(self, value):
        self.__data = value


m01 = MyClass(10)
print(m01.data)
m01.data = 20
print(m01.data)


```



```python
# 2. 只读属性
class MyClass(object):
    def __init__(self, data):
        self.__data = data

    @property
    def data(self):
        return self.__data


m01 = MyClass(10)
print(m01.data)
# m01.data = 20

```



```python
# 3. 只写属性
class MyClass(object):
    def __init__(self, data):
        self.__data = data

    def data(self, value):
        self.__data = value

    # property(fget = None , fset = None , fdel = None)
    # fget 是获取属性值的方法
    # fset 是设置(修改)属性值的方法
    # fdel 是删除属性值的方法

    data = property(fset=data)


m01 = MyClass(10)
print(m01.__dict__)
# print(m01.data)
m01.data = 20
print(m01.__dict__)

```



## 作业

```python
"""
设计并实现一个圆(Circle)类，用于求圆的面积
    实例属性：
        r(半径) 使用 @property 和 @setter 进行权限设置(验证半径的值为整数以及正数)
    方法：
        1.__init__(self, r)：初始化圆的半径
        2.查看方法
        3.修改方法
        4.求面积方法(返回圆的面积)
        5.求周长的属性
    验证：
        当设置半径时，如果提供的半径不是正数以及不是整数，则抛出 ValueError 异常。
"""
```

































