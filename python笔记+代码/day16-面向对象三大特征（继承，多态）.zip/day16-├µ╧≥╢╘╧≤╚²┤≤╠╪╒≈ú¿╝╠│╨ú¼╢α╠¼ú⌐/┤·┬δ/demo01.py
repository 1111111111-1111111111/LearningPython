class Animal(object):
    """动物类"""

    def sound(self):
        print("发出叫声！")


class Dog(Animal):
    """狗类"""

    def eat(self):
        print("吃骨头")

    def sound(self):
        print("汪汪汪")


class Cat(Animal):
    """猫类"""

    def eat(self):
        print("吃猫粮")


cat = Cat()
cat.eat()
cat.sound()

# 优先使用子类的方法，子类没有，找父类
dog = Dog()
dog.eat()
dog.sound()
