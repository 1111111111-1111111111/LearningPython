class Animal(object):
    """动物类"""

    def __init__(self, name):
        self.name = name

    def show(self):
        print(self.name)


class Cat(Animal):
    """猫类"""

    def __init__(self, name, age):
        super().__init__(name)
        # Animal.__init__(self, name)
        self.age = age

    # 方法的重写
    def show(self):
        print("cat", self.name, self.age)

    def eat(self):
        print("吃")


class Dog(Animal):
    """狗类"""

    def __init__(self, name, age):
        super().__init__(name)
        self.age = age

    # 调用父类的方法并进行添加
    def show(self):
        super().show()
        print("dog", self.name, self.age)


cat = Cat("小白", 2)
cat.show()
cat.eat()
dog = Dog("小黑", 4)
dog.show()

# 创建父类对象
animal01 = Animal("动物1")
animal01.show()
animal01.eat()