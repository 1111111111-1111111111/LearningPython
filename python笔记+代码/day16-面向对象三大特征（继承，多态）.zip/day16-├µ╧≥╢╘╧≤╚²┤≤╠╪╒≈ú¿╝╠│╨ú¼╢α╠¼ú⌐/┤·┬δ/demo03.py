class Horse:
    """马类"""

    def body(self):
        print("体型健硕")

    def run(self):
        print("奔跑速度快")


class Donkey:
    """驴类"""

    def body(self):
        print("体型瘦小")


class Mule(Donkey, Horse):
    """骡子"""
    pass


m = Mule()
m.body()
m.run()

# 查看继承顺序 __mro__
print(Mule.__mro__)
print(Horse.__mro__)

# 查看父类，返回的是一个元组 __bases__
print(Mule.__bases__)
print(Horse.__bases__)

# 返回一个父类 __base__
print(Mule.__base__)
print(Horse.__base__)
