class Animal(object):
    """动物类"""

    def sound(self):
        print("发出叫声！")


class Dog(Animal):
    """狗类"""

    def sound(self):
        print("汪汪汪")


class Cat(Animal):
    """猫类"""

    def sound(self):
        print("喵喵喵")


def animal_sound(animal):
    animal.sound()


dog = Dog()
cat = Cat()
dog.sound()
cat.sound()

# 多态写法
animal_sound(dog)
animal_sound(cat)