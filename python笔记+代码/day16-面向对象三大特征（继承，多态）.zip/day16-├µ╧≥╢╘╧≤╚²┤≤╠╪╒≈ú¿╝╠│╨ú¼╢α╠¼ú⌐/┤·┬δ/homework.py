"""
设计并实现一个圆(Circle)类，用于求圆的面积
    实例属性：
        r(半径) 使用 @property 和 @setter 进行权限设置(验证半径的值为整数以及正数)
    方法：
        1.__init__(self, r)：初始化圆的半径
        2.查看方法
        3.修改方法
        4.求面积方法(返回圆的面积)
        5.求周长的属性
    验证：
        当设置半径时，如果提供的半径不是正数以及不是整数，则抛出 ValueError 异常。
"""
import math


class Circle:
    def __init__(self, r):
        self.__r = r

    @property
    def r(self):
        return self.__r

    @r.setter
    def r(self, value):
        if value > 0 and type(value) == int:
            self.__r = value
        else:
            raise ValueError('半径必须为正整数！')

    def area(self):
        return self.__r ** 2 * math.pi

    @property
    def perimeter(self):
        return 2 * self.__r * math.pi


# 创建一个Circle对象
circle = Circle(2)
# 访问实例属性
print(circle.r)
print(circle.area())
print(circle.perimeter)

# 修改实例属性
circle.r = 3
# 访问实例属性
print(circle.r)
print(circle.area())
print(circle.perimeter)

# 尝试无效值
# circle.r = -3
