class University:
    """大学类"""

    def __init__(self):
        self.university_name = '清华大学'

    def meeting(self):
        print(self.university_name, "召开会议")


class Academy(University):
    """学院类"""

    def __init__(self):
        super().__init__()
        self.academy_name = '计算机学院'

    def meeting(self):
        super().meeting()
        print(self.academy_name, "召开会议")


class Department(University):
    """社团类"""

    def __init__(self):
        super().__init__()
        self.department_name = '机器人社团'

    def meeting(self):
        super().meeting()
        print(self.department_name, "召开会议")


class Teacher(Academy, Department):
    """教师类"""

    def __init__(self):
        super().__init__()
        self.teacher_name = '系主任'

    def meeting(self):
        super().meeting()
        print(self.teacher_name, "召开会议")


teacher = Teacher()
teacher.meeting()
