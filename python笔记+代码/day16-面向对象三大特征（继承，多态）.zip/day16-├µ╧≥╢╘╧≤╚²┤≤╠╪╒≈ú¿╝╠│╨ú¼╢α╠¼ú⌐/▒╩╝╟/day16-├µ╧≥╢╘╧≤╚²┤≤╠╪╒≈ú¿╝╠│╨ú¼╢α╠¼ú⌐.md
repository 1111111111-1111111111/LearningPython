# 面向对象三大特征（继承，多态）

## 上节课回顾

```python
- 封装
	-属性隐藏
    	封装是指将数据和操作数据的方法打包在一起，形成一个类
        在Python中使用双下划线开头的方式将属性或方法隐藏起来（设置成私有的），即双下划线前缀
        self.__name=name
        def __password(self):
    -property()函数
    	property(fget = None , fset = None , fdel = None)

		# fget 是获取属性值的方法
		# fset 是设置(修改)属性值的方法
		# fdel 是删除属性值的方法
    -@property装饰器
		被 @property 装饰的方法是获取属性值的方法，被装饰方法的名字会被用做 属性名。
		被 @属性名.setter 装饰的方法是设置属性值的方法。
		被 @属性名.deleter 装饰的方法是删除属性值的方法。

- 作业
"""
设计并实现一个圆(Circle)类，用于求圆的面积
    实例属性：
        r(半径) 使用 @property 和 @setter 进行权限设置(验证半径的值为整数以及正数)
    方法：
        1.__init__(self, r)：初始化圆的半径
        2.查看方法
        3.修改方法
        4.求面积方法(返回圆的面积)
    验证：
        当设置半径时，如果提供的半径不是正数以及不是整数，则抛出 ValueError 异常。
"""
"""
设计并实现一个圆(Circle)类，用于求圆的面积
    实例属性：
        r(半径) 使用 @property 和 @setter 进行权限设置(验证半径的值为整数以及正数)
    方法：
        1.__init__(self, r)：初始化圆的半径
        2.查看方法
        3.修改方法
        4.求面积方法(返回圆的面积)
        5.求周长的属性
    验证：
        当设置半径时，如果提供的半径不是正数以及不是整数，则抛出 ValueError 异常。
"""
import math


class Circle(object):
    def __init__(self, r):
        self.__r = r

    @property
    def r(self):
        return self.__r

    @r.setter
    def r(self, value):
        if value > 0 and type(value) == int:
            self.__r = value
        else:
            raise ValueError('半径必须为正整数！')

    def area(self):
        return self.__r ** 2 * math.pi

    @property
    def perimeter(self):
        return 2 * self.__r * math.pi


# 创建一个Circle对象
circle = Circle(2)
# 访问实例属性
print(circle.r)
print(circle.area())
print(circle.perimeter)

# 修改实例属性
circle.r = 3
# 访问实例属性
print(circle.r)
print(circle.area())
print(circle.perimeter)

# 尝试无效值
# circle.r = -3


```

# 2.继承

继承：生活中，儿子继承父亲的财产

面向对象编程的一个重要特性是继承。继承允许你创建一个类（称为子类或派生类），它继承另一个类（称为父类或基类）的属性和方法。这样可以重用代码并减少重复，同时还能根据需要添加新的特性和方法。 

在python中所有类都有一个父类就是object类，object被称为”顶级基类“或者”根类“

Python3中所有的类都自动默认继承object类

## 2.1继承方法

```python
语法：
    class 父类:
      def 父类方法(self):
        方法体
    class 子类(父类)：
      def 子类方法(self):
        方法体
    儿子 = 子类()
    儿子.子类方法()
    儿子.父类方法()
    
class Animal(object):
    """动物类"""

    def sound(self):
        print("发出叫声！")


class Dog(Animal):
    """狗类"""

    def eat(self):
        print("吃骨头")

    def sound(self):
        print("汪汪汪")


class Cat(Animal):
    """猫类"""

    def eat(self):
        print("吃猫粮")


cat = Cat()
cat.eat()
cat.sound()

# 优先使用子类的方法，子类没有，找父类
dog = Dog()
dog.eat()
dog.sound()

    
```

## 2.2继承数据

子类如果没有构造函数，将自动执行父类的，但如果有构造函数将覆盖父类的。此时必须通过super()函数调用父类的构造函数，以确保父类实例变量被正常创建

```python
语法：
class 子类(父类):
    def __init__(self,父类参数,子类参数):
      	super().__init__(参数) # 调用父类构造函数
      	self.实例变量 = 参数
        
class Animal(object):
    """动物类"""

    def __init__(self, name):
        self.name = name


class Cat(Animal):
    """猫类"""

    def __init__(self, name,  age):
        super().__init__(name)
        # Animal.__init__(self, name)
        self.age = age

    def show_info(self):
        print(self.name, self.age)


cat = Cat("小白", 2)
cat.show_info()

        
```

- **子类继承父类方法并重写**

`super()`函数用于调用父类中的方法。在子类中，通过`super().父类方法()`可以调用父类中的方法

```python
class Animal(object):
    """动物类"""

    def __init__(self, name):
        self.name = name

    def show(self):
        print(self.name)


class Cat(Animal):
    """猫类"""

    def __init__(self, name, age):
        super().__init__(name)
        # Animal.__init__(self, name)
        self.age = age

    # 方法的重写
    def show(self):
        print("cat", self.name, self.age)


class Dog(Animal):
    """狗类"""

    def __init__(self, name, age):
        super().__init__(name)
        self.age = age

    # 调用父类的方法并进行添加
    def show(self):
        super().show()
        print("dog", self.name, self.age)


cat = Cat("小白", 2)
cat.show()
dog = Dog("小黑", 4)
dog.show()



```

## 2.3多继承

多继承：一个子类继承多个父类

在多继承中同一个方法或者属性遵循就近继承（在父类中从左到右）

 				A 

​			 /		 \ 

​		 / 				\ 

​	 B —  —  — 》C

​		 \				 / 

​			 \		 / 

 				D

D ---> B ---> C---> A

```python
语法：
class A:
    pass

class B(A):
    pass

class C(A):
    pass

class D(B, C):
    pass

```

```python
class Horse:
    """马类"""

    def body(self):
        print("体型健硕")

    def run(self):
        print("奔跑速度快")


class Donkey:
    """驴类"""

    def body(self):
        print("体型瘦小")


class Mule(Donkey, Horse):
    """骡子"""
    pass


m = Mule()
m.body()
m.run()

# 查看继承顺序 __mro__
print(Mule.__mro__)
print(Horse.__mro__)

# 查看父类，返回的是一个元组 __bases__
print(Mule.__bases__)
print(Horse.__bases__)

# 返回一个父类 __base__
print(Mule.__base__)
print(Horse.__base__)


```

思考：

```python
class University:
    """大学类"""

    def __init__(self):
        self.university_name = '清华大学'

    def meeting(self):
        print(self.university_name, "召开会议")


class Academy(University):
    """学院类"""

    def __init__(self):
        super().__init__()
        self.academy_name = '计算机学院'

    def meeting(self):
        super().meeting()
        print(self.academy_name, "召开会议")


class Department(University):
    """社团类"""

    def __init__(self):
        super().__init__()
        self.department_name = '机器人社团'

    def meeting(self):
        super().meeting()
        print(self.department_name, "召开会议")


class Teacher(Academy, Department):
    """教师类"""

    def __init__(self):
        super().__init__()
        self.teacher_name = '系主任'

    def meeting(self):
        super().meeting()
        print(self.teacher_name, "召开会议")


teacher = Teacher()
teacher.meeting()


```

# 3.多态

多态指的是同一操作在不同对象上可能具有不同的行为方式。在Python中，多态性是通过继承和方法重写来实现的。

```python
class Animal(object):
    """动物类"""

    def sound(self):
        print("发出叫声！")


class Dog(Animal):
    """狗类"""

    def sound(self):
        print("汪汪汪")


class Cat(Animal):
    """猫类"""

    def sound(self):
        print("喵喵喵")


def animal_sound(animal):
    animal.sound()


dog = Dog()
cat = Cat()
dog.sound()
cat.sound()

# 多态写法
animal_sound(dog)
animal_sound(cat)

```

面向对象的三大特征：

- 封装：将属性藏起来，只对外界暴露必要的属性，可以自己去控制权限
- 继承：允许一个类从另一个类继承属性和方法，从而实现代码的复用和扩展
- 多态：允许使用统一的接口来操作不同的对象，从而使得代码更加的灵活和可扩展

# 作业：

```python
"""
交通工具模拟：
1.封装：
	创建一个Transportation父类，类中应有私有属性 __username 和 __userage，分别表示使用者的名字和年龄；并且包含抽象方法move()
	使用 @property 和 @name.setter 装饰器来访问和修改 __username 属性。
	使用 @property 和 @age.setter 装饰器来访问和修改 __userage 属性，但要求 @age.setter 方法只能接受大于 0 的年龄，超出范围时打印错误信息。
	并且实现一个方法 get_info() 介绍使用者的名字和年龄
	
2.继承：
	从Transportation派生出三个子类：Car，Bicycle和Boat。
    2.1 Car类的move()方法打印"正在开车前进"。
    2.2 Bicycle类的move()方法打印"正在骑行"。
    2.3 Boat类的move()方法打印"正在航行"。
    
3.多态：
	编写一个函数travel(vehicle)，这个函数会调用对象的get_info()和move()方法。
"""

@abstractmethod 是 Python 中的一个装饰器，用于声明抽象方法。它是在 abc（Abstract Base Classes，抽象基类）模块中定义的。

抽象方法是一个在抽象基类中声明但没有实现的方法，它只包含方法的声明，没有具体的实现代码。抽象方法的存在主要是为了定义一个接口，规定子类必须实现该方法。

使用 @abstractmethod 装饰器可以将一个方法声明为抽象方法。具体来说，需要按照以下步骤进行操作：

导入 abc 模块：from abc import ABC，abstractmethod
定义抽象基类：创建一个继承自 ABC 或其他抽象基类的类。
在抽象基类中使用 @abstractmethod 装饰器：将方法声明为抽象方法。抽象方法可以没有实现代码，只有方法声明。
子类实现抽象方法：子类必须实现抽象基类中的所有抽象方法，否则会引发 TypeError 错误。

from abc import abstractmethod, ABC

class Transportation(ABC):
    """交通工具类"""
    @abstractmethod
    def move(self):
        pass
```















