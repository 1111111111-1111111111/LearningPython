# isinstance(对象, 类型)  # 返回指定对象是否是某个类的对象。
# issubclass(子类，父类) # 返回指定类型是否属于某个类型。
class Student:
    pass


class Teacher:
    pass


stu = Student()
tea = Teacher()
print(isinstance(stu, Student))
print(isinstance(tea, Student))

print(issubclass(Student, Teacher))
print(issubclass(Student, object))
