# __str__ 方法，当调用内置的 `str()` 函数或者 `print()` 函数时，如果对象实现了 `__str__ `方法，将会调用该方法并返回其结果。
class Student:

    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age

    def __str__(self):
        """print()"""
        return f'{self.name}同学，今年{self.age}岁了'

    def __len__(self):
        return len([self.name, self.age])


# 创建Student类的实例对象
stu01 = Student("老王", 20)
print(stu01)

# _len__ 该方法返回对象的长度，会被 len() 函数调用 用于让对象支持 len() 操作。
print(len(stu01))
