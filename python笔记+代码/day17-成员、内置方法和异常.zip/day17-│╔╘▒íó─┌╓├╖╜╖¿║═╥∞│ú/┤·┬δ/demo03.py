class Student:

    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age

    def __add__(self, other):
        """计算年龄和"""
        return self.age + other.age

    def __eq__(self, other):
        """比较年龄"""
        return self.age == other.age


# 创建Student类的实例对象
stu01 = Student("老王", 20)
stu02 = Student("老刘", 20)
print(stu01 == stu02)
print(stu01 + stu02)
