name = "老王"
try:
    print("串门")
    print(name)
except NameError as err:
    print("干点其他的事01")
    print(err)
except TypeError as err:
    print("干点其他的事02")
    print(err)
else:
    print(30)

finally:
    print("离开")










