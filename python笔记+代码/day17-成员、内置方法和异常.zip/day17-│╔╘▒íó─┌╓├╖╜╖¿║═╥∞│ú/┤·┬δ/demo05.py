class Wife:
    def __init__(self, age):
        # 直接操作实例变量 ，未触发验证机制，默认已通过外部验证
        # self.__age = age

        # 通过属性接口进行赋值
        self.age = age

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        if 20 <= value <= 40:
            self.__age = value
        else:
            raise Exception('我不要，年龄不合适！')


while True:
    try:
        age = int(input('请输入女孩年龄：'))
        wife = Wife(age)
        break
    except Exception as err:
        print(err)
