"""
交通工具模拟：
1.封装：
	创建一个Transportation父类，类中应有私有属性 __username 和 __userage，分别表示使用者的名字和年龄；并且包含抽象方法move()
	使用 @property 和 @name.setter 装饰器来访问和修改 __username 属性。
	使用 @property 和 @age.setter 装饰器来访问和修改 __userage 属性，但要求 @age.setter 方法只能接受大于 0 的年龄，超出范围时打印错误信息。
	并且实现一个方法 get_info() 介绍使用者的名字和年龄

2.继承：
	从Transportation派生出三个子类：Car，Bicycle和Boat。
    2.1 Car类的move()方法打印"交通工具为汽车"。
    2.2 Bicycle类的move()方法打印"交通工具为自行车"。
    2.3 Boat类的move()方法打印"交通工具为船"。

3.多态：
	编写一个函数travel(vehicle)，这个函数会调用对象的get_info()和move()方法。
"""
from abc import ABC, abstractmethod


class Transportation(ABC):
    def __init__(self, username, userage):
        self.__username = username
        self.__userage = userage

    @property
    def username(self):
        return self.__username

    @username.setter
    def username(self, value):
        self.__username = value

    @property
    def userage(self):
        return self.__userage

    @userage.setter
    def userage(self, value):
        if value > 0:
            self.__userage = value
        else:
            raise ValueError("年龄不能为负数！")

    @property
    def get_info(self):
        print(f"使用者姓名：{self.__username} 使用者年龄：{self.__userage}")

    @abstractmethod
    def move(self):
        pass


# Car，Bicycle和Boat
class Car(Transportation):
    def move(self):
        print("交通工具为汽车")


class Bicycle(Transportation):
    def move(self):
        print("交通工具为自行车")


class Boat(Transportation):
    def move(self):
        print("交通工具为船")


def travel(vehicle):
    vehicle.move()
    vehicle.get_info


car = Car("老王", 40)
bicycle = Bicycle("老刘", 45)
boat = Boat("老孙", 50)
travel_list = [car, bicycle, boat]
for item in travel_list:
    travel(item)
