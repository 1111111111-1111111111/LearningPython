# 成员、内置方法和异常

## 上节课回顾

```python
- 继承
	子类继承父类属性和方法，可以重用代码并减少重复，同时还能根据需要添加新的特征和方法
    在Python中所有类都有一个父类就是object，称为超类，顶级基类
    -继承方法
    	class 父类:
        class 子类(父类)：
    -继承数据
    	子类如果没有构造函数，将自动执行父类的
        super()函数用于调用父类中的方法
    -多继承：一个子类继承多个父类
    	在多继承中同一个方法或者属性遵循就近继承（在父类中从左到右）
        
- 多态
	多态指的是同一操作在不同对象上可能具有不同的行为方式。在Python中，多态性是通过继承的方法重写来实现的。

- 总结
	- 封装：将属性藏起来，只对外界暴露必要的属性，可以自己去控制权限
	- 继承：允许一个类从另一个类继承属性和方法，从而实现代码的复用和扩展
	- 多态：允许使用统一的接口来操作不同的对象，从而使得代码更加的灵活和可扩展

- 作业
"""
交通工具模拟：
1.封装：
	创建一个Transportation父类，类中应有私有属性 __username 和 __userage，分别表示使用者的名字和年龄；并且包含抽象方法move()
	使用 @property 和 @name.setter 装饰器来访问和修改 __username 属性。
	使用 @property 和 @age.setter 装饰器来访问和修改 __userage 属性，但要求 @age.setter 方法只能接受大于 0 的年龄，超出范围时打印错误信息。
	并且实现一个方法 get_info() 介绍使用者的名字和年龄
	
2.继承：
	从Transportation派生出三个子类：Car，Bicycle和Boat。
    2.1 Car类的move()方法打印"交通工具为汽车"。
    2.2 Bicycle类的move()方法打印"交通工具为自行车"。
    2.3 Boat类的move()方法打印"交通工具为船"。
    
3.多态：
	编写一个函数travel(vehicle)，这个函数会调用对象的get_info()和move()方法。
"""
from abc import ABC, abstractmethod


class Transportation(ABC):
    def __init__(self, username, userage):
        self.__username = username
        self.__userage = userage

    @property
    def username(self):
        return self.__username

    @username.setter
    def username(self, value):
        self.__username = value

    @property
    def userage(self):
        return self.__userage

    @userage.setter
    def userage(self, value):
        if value > 0:
            self.__userage = value
        else:
            raise ValueError("年龄不能为负数！")

    @property
    def get_info(self):
        print(f"使用者姓名：{self.__username} 使用者年龄：{self.__userage}")

    @abstractmethod
    def move(self):
        pass


# Car，Bicycle和Boat
class Car(Transportation):
    def move(self):
        print("交通工具为汽车")


class Bicycle(Transportation):
    def move(self):
        print("交通工具为自行车")


class Boat(Transportation):
    def move(self):
        print("交通工具为船")


def travel(vehicle):
    vehicle.move()
    vehicle.get_info


car = Car("老王", 40)
bicycle = Bicycle("老刘", 45)
boat = Boat("老孙", 50)
travel_list = [car, bicycle, boat]
for item in travel_list:
    travel(item)

```

## 1.成员

### 1.1实例属性

实例属性是对象特有的属性，不同的对象有各自独立的实例属性。实例属性通常在类的初始化方法中定义，并通过 `self` 进行赋值。`self` 代表实例本身，通过 `self` 可以在类的其他方法中访问这些属性。

```python
class Student:
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age

```

实例属性可以通过对象实例访问和修改。

```python
# 创建Student类的实例对象
stu01 = Student("老王", 20)
stu02 = Student("老刘", 24)

# 访问实例属性
print(stu01.name, stu01.age) # 老王 20
print(stu02.name, stu02.age) # 老刘 24

# 修改实例属性
stu01.age = 21
stu02.age = 25
```

实例属性也可以在方法中使用，通过 `self` 关键字访问。

```python
class Student:
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age
        
    def show(self):
        print(f"大家好，我叫{self.name}，今年{self.age}岁了")

# 创建Student类的实例对象
stu01 = Student("老王", 20)     
stu01.show()
```

### 1.2类属性

类属性是属于类本身的属性，所有该类的实例共享同一份类属性。类属性通常在类定义中直接定义，而不是在初始化方法中定义。因为类属性是共享的，因此在任何实例中对类属性的修改都会影响到所有实例。

```python
class Student:
    # 类属性
    school_name = "Python 学院"
    
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age
```

类属性可以通过类名或实例对象访问。

```python
- 读类属性
# 通过类名访问类属性
print(Student.school_name) # Python 学院

# 通过实例对象访问类属性
stu01 = Student("老王", 20)  
print(stu01.school_name) # Python 学院
```

类属性可以通过类名进行修改，直接通过对象修改会创建一个同名的实例属性，而不是修改类属性。

```python
- 改类属性
# 通过类名修改类属性
Student.school_name = "Python 大学"
print(Student.school_name) # Python 大学

# 通过实例对象修改类属性
stu01 = Student("老王", 20)  

stu01.school_name = "Python 小学"
stu01.age = "男"

print(stu01.school_name) # Python 小学
print(Student.school_name) # Python 大学
```

类属性提供了一种在所有对象中共享数据的机制

```python
class Student:
    # 类属性
    school_count = 0 # 用于统计学生数量
    
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age
        Student.school_count += 1
   
	def get_school_count(self):
        return Student.school_count

# 通过实例对象修改类属性
stu01 = Student("老王", 20)
print(stu01.get_school_count()) # 1

stu02 = Student("老刘", 24)
print(stu02.get_school_count()) # 2
```

### 1.3局部变量

方法中还可以定义局部变量。局部变量直接以“变量名=值”的方式进行定义，局部变量只能用于所在函数中。

```python
class Student:
	# 类属性
    school_count = 0 # 用于统计学生数量
    
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age
        Student.school_count += 1
        
    def show(self):
        # 局部变量
        greeting = f"大家好，我叫{self.name}，今年{self.age}岁了"
        print(greeting)

# 创建Student类的实例对象
stu01 = Student("老王", 20)     
stu01.show()  # 大家好，我叫老王，今年20岁了     

# 尝试访问局部变量greeting(报错)
print(stu01.greeting)
```



### 1.4实例方法

实例方法是定义在类内部的方法，第一个参数通常命名为 `self` ，代表类的实例对象。通过 `self`，实例方法可以访问和修改实例属性。

```python
class Student:
    
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age
        
    def show(self):
        # 局部变量
        greeting = f"大家好，我叫{self.name}，今年{self.age}岁了"
        print(greeting)
        
    def birthday(self):
        self.age += 1
        print(f"祝{self.name}生日快乐，今年{self.age}岁了")	

# 创建Student类的实例对象
stu01 = Student("老王", 20)     
stu01.birthday()  # 祝老王生日快乐，今年21岁了    


```



### 1.5类方法

类方法是绑定到类而不是绑定到实例的方法。类方法的第一个参数通常命名为 `cls` ，用于引用类本身，而不是类的实例。类方法通过 `@classmethod` 装饰器来定义，且通常用于操作类属性或实现与类相关的功能。

类方法操作的一定是类属性，因为类方法无法通过self去查询对象的实例属性

```python
class Student:
    # 类属性
    school_count = 0 # 用于统计学生数量
    
    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age
        Student.school_count += 1
   
	@classmethod
	def get_school_count(cls):
        return Student.school_count
    	return cls.school_count

# 通过实例对象修改类属性
stu01 = Student("老王", 20)
print(Student.get_school_count()) # 1

stu02 = Student("老刘", 24)
print(Student.get_school_count()) # 2

```



### 1.6静态方法

静态方法是定义在类中的方法，但不依赖于类实例或类本身。静态方法没有 `self` 或 `cls` 参数，通常用于执行一些与类或实例无关的任务。静态方法通过 `@staticmethod` 装饰器来定义。

静态方法本质上和类无关

```python
class MathUtils:
    @staticmethod
    def add(a, b):
        return a + b
    
    @staticmethod
    def subtract(a, b):
        return a - b
    
    @staticmethod
    def multiply(a, b):
        return a * b
    
    @staticmethod
    def divide(a, b):
        if b == 0:
            return "不能除以零"
        return a / b

# 调用静态方法，不需要创建类的实例    
print(MathUtils.add(10, 5))
print(MathUtils.subtract(10, 5))
print(MathUtils.multiply(10, 5))
print(MathUtils.divide(10, 5))
```

总结

- 实例方法：操作具体对象的属性和行为
- 类方法：操作类级别的属性和行为
- 静态方法：进行一些逻辑相关但不需要属性，只是一个单纯的功能

## 2.检查类型

```python
type() # 检查单个数据类型的
isinstance(对象, 类型)  # 返回指定对象是否是某个类的对象。
issubclass(子类，父类) # 返回指定类型是否属于某个类型。
```

```python
class Student:
    pass


class Teacher:
    pass


stu = Student()
tea = Teacher()
print(isinstance(stu, Student))
print(isinstance(tea, Student))

print(issubclass(Student, Teacher))
print(issubclass(Student, object))

```

## 3.内置方法（了解）

如果没有指定父类，python 的类会默认继承 `object` 类，`object` 是所有python类的基类，它提供了一些常见方法这些方法都是 `__方法__` 格式，这些方法会再某种情况下自动触发执行。我们可以在自定义类中进行重写，从而改变其行为。

```python
__init__
__new__
__str__
__iter__
__next__
__len__
一般来说是不要去手动调用的,有自己专门的执行机制
```

```python
# __str__ 方法，当调用内置的 `str()` 函数或者 `print()` 函数时，如果对象实现了 `__str__ `方法，将会调用该方法并返回其结果。
class Student:

    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age

    def __str__(self):
        """print()"""
        return f'{self.name}同学，今年{self.age}岁了'

    def __len__(self):
        return len([self.name, self.age])


# 创建Student类的实例对象
stu01 = Student("老王", 20)
print(stu01)

# _len__ 该方法返回对象的长度，会被 len() 函数调用 用于让对象支持 len() 操作。
print(len(stu01))

```



- 比较方法(运算符)

|     方法名     |   说明   |
| :------------: | :------: |
|   `__add__`    |   加法   |
|   `__sub__`    |   减法   |
|   `__mul__`    |   乘法   |
| `__truediv__`  |   除法   |
| `__floodiv__`  |   取整   |
|   `__mod__`    |   求余   |
|   `__pow__`    |    幂    |
|   `__iadd__`   |    +=    |
|   `__isub__`   |    -=    |
|   `__imul__`   |    *=    |
| `__itruediv__` |    /=    |
| `__ifloodiv__` |   //=    |
|   `__imod__`   |    %=    |
|   `__ipow__`   |   **=    |
|    `__lt__`    |   小于   |
|    `__le__`    | 小于等于 |
|    `__gt__`    |   大于   |
|    `__ge__`    | 大于等于 |
|    `__eq__`    |   等于   |
|    `__ne__`    |  不等于  |

```python
class Student:

    def __init__(self, name, age):
        # 实例属性name
        self.name = name
        # 实例属性age
        self.age = age

    def __add__(self, other):
        """计算年龄和"""
        return self.age + other.age

    def __eq__(self, other):
        """比较年龄"""
        return self.age == other.age


# 创建Student类的实例对象
stu01 = Student("老王", 20)
stu02 = Student("老刘", 20)
print(stu01 == stu02)
print(stu01 + stu02)


```

## 4.异常处理

异常：在程序指定过程中有逻辑等的其他错误导致程序终止运行。

异常处理：在程序中，将觉得有问题的代码进行处理，让程序运行时，不为其因错误而终止。

### 4.1异常错误

- 语法错误

```python
语法错误是可以避免——SyntaxError
```



- 逻辑错误

|    异常类型    |                   含义                   |
| :------------: | :--------------------------------------: |
| AttributeError |  当试图访问的对象属性不存在时抛出的异常  |
|   IndexError   |       索引超出序列范围会引发此异常       |
|    KeyError    | 字典中查找一个不存在的关键字时引发此异常 |
|   NameError    |  尝试访问一个未声明的变量时，引发此异常  |
|   TypeError    |        不同类型数据之间的无效操作        |
|   Exception    |                 异常基类                 |

### 4.2异常处理

Exception:可以捕获所有的异常

```python
语法：
try:
    代码块(有可能有问题的代码)
except 异常类型 [as 变量]:
    # 可以有一个或者多个
    # as语法将异常类型的值赋值给变量，这样我们通过打印变量便可以知道错误的原因，可以省略
    代码(判断上述是指定异常的类型则执行，否则不执行)
else: 
    #最多只能有一个else
    这里的代码在try中的代码是没有异常的情况下执行
finally: 
    # 最多只能有一个，如果没有except子句，必须存在
    不管代码有没有异常都会执行，一般用于释放资源
...   
```

```python
name = "老王"
try:
    print("串门")
    print(name)
except NameError as err:
    print("干点其他的事01")
    print(err)
except TypeError as err:
    print("干点其他的事02")
    print(err)
else:
    print(30)

finally:
    print("离开")

```

### 4.3raise抛错

主动抛出一个错误，让程序进入异常状态

在程序调用层数较深时，向主调函数传递错误信息要层层return比较麻烦，所以人为抛出异常，可以直接传递错误信息，更清楚的展现程序存在的问题。

```python
raise 异常的类或异常的实例

raise TypeError('name must be str')
```

```python
class Wife:
    def __init__(self, age):
        # 直接操作实例变量 ，未触发验证机制，默认已通过外部验证
        # self.__age = age

        # 通过属性接口进行赋值
        self.age = age

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        if 20 <= value <= 40:
            self.__age = value
        else:
            raise Exception('我不要，年龄不合适！')


while True:
    try:
        age = int(input('请输入女孩年龄：'))
        wife = Wife(age)
        break
    except Exception as err:
        print(err)


```

### 4.4断言assert

`assert` 语句，又称断言语句，可以看做是功能缩小版的 `if` 语句，它用于判断某个表达式的值，如果值为真，则程序可以继续往下执行；反之，Python 解释器会报 `AssertionError` 错误。

```python
mathmark = int(input("请输入成绩"))
# 断言数学考试分数是否位于正常范围内
assert 0 <= mathmark <= 100
# 只有当 mathmark 位于 [0,100]范围内，程序才会继续执行
print("数学考试分数为：", mathmark)
```

- 对比

**1.用途：**

`assert`：

​		用于**开发阶段**的调试和逻辑验证。

​		检查程序假设是否正确（调试工具）。

​		通常只用于开发和测试，不建议在生产环境中使用。

`raise`：

​		用于**生产环境**的错误处理。

​		主动抛出错误，用于明确控制程序的行为。

​		更灵活，可以抛出自定义异常。

**2.灵活性：**

​		`assert` 只能抛出 `AssertionError`，适合快速验证简单条件。

​		`raise` 可以抛出任意类型的异常，更适合复杂场景的精确处理。

**3.代码对比**

```python
mathmark = int(input("请输入成绩："))
assert 0 <= mathmark <= 100
print("数学考试分数为：", mathmark)

mathmark = int(input("请输入成绩："))
if not 0 <= mathmark <= 100:
    raise ValueError("mathmark 必须在0-100之间")
print("数学考试分数为：", mathmark)


```

## 作业

```python
"""
做一个简易学生成绩录入系统（类）
包含name，sex,score,id
要求：
1、id每个学生唯一，由系统自动生成
2、sex只能是男和女，不符合条件则抛出异常
3、score在1-100之间，不符合条件则抛出异常
4、循环录入，录入空时结束并展示已录入信息
"""
```





























