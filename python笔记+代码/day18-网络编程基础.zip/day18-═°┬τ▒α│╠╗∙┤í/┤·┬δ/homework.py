"""
做一个简易学生成绩录入系统（类）
包含name，sex,score,id
要求：
1、id每个学生唯一，由系统自动生成
2、sex只能是男和女，不符合条件则抛出异常
3、score在1-100之间，不符合条件则抛出异常
4、循环录入，录入空时结束并展示已录入信息
"""


class Student(object):
    cid = 1001

    def __init__(self, name, sex, score):
        self.name = name
        self.sex = sex
        self.score = score
        self.id = Student.cid
        Student.cid += 1

    def __str__(self):
        return f"姓名：{self.name} 性别：{self.sex} 分数：{self.score} 学号：{self.id}"


stu_list = []


def add_student():
    while True:
        name = input("请输入姓名：")
        if not name:
            for stu in stu_list:
                print(stu)
            break
        # 在外部对学生的信息做验证
        while True:
            try:
                sex = input("请输入学生性别：")
                if sex in ("男", "女"):
                    break
                raise ValueError("性别只能是男和女")
            except ValueError as err:
                print(err)
        while True:
            try:
                score = int(input("请输入学生成绩："))
                if 0 <= score <= 100:
                    break
                raise ValueError("分数必须在0 - 100 之间！")
            except ValueError as err:
                print(err)
        student = Student(name, sex, score)
        stu_list.append(student)


add_student()
