"""
    客户端
    1.创建套接字
    2.发送/接收消息
    3.关闭套接字
"""
# 导入socket模块
import socket

# 1.创建套接字
# socket.AF_INET ipv4
# socket.SOCK_DGRAM UDP模式
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2.发送消息
message = input(">>:")  # 等待写入
client.sendto(message.encode("utf-8"), ("127.0.0.1", 8888))

# 接收服务端的回复
data, addr = client.recvfrom(1024)
print("服务端回应：:", data.decode("utf-8"))
print(addr)

# 3.关闭套接字
client.close()
