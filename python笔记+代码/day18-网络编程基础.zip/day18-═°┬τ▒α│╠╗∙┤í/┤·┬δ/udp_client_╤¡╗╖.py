"""
    客户端
    1.创建套接字
    2.发送/接收消息
    3.关闭套接字
"""
# 导入socket模块
import socket

ADDR = ("127.0.0.1", 8888)

# 1.创建套接字
# socket.AF_INET ipv4
# socket.SOCK_DGRAM UDP模式
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 保持通讯
while True:
    # 发送消息
    message = input(">>:")

    client.sendto(message.encode(), ADDR)

    # 设置中断
    if message == "##":
        print("客户端退出！")
        break

    # 接受消息
    data, addr = client.recvfrom(1024)
    print("服务端消息：", data.decode('utf-8'))

# 关闭套接字
client.close()
