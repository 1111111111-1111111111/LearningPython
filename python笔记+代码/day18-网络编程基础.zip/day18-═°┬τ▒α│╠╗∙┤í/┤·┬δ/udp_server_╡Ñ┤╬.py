"""
    服务端
    1.创建套接字
    2.绑定ip端口
    3.发送/接收消息
    4.关闭套接字
"""
# 导入socket模块
import socket

# 1.创建套接字
# socket.AF_INET ipv4
# socket.SOCK_DGRAM UDP模式
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2.绑定ip端口
ADDR = ("127.0.0.1", 8888)
server.bind(ADDR)

# 3.接收消息
message, addr = server.recvfrom(1024)  # 阻塞，等待请求
print(addr)

# 打印客户端发送的消息
print("接收到客户端消息：", message.decode('utf-8'))

# 发送消息
server.sendto("你好，收到了你的消息".encode('utf-8'), addr)

# 4.关闭套接字
server.close()
