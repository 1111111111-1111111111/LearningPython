"""
    服务端
    1.创建套接字
    2.绑定ip端口
    3.发送/接收消息
    4.关闭套接字
"""
# 导入socket模块
import socket

ADDR = ("127.0.0.1", 8888)

# 1.创建套接字
# socket.AF_INET ipv4
# socket.SOCK_DGRAM UDP模式
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2.绑定ip端口
server.bind(ADDR)

# 保持通讯
while True:
    # 接收客户端请求
    data, addr = server.recvfrom(1024)
    print(addr)

    # 设置中断
    if data == b"##":
        print("客户端退出！")
        break

    # 打印客户端发送的消息
    print("接收到客户端消息：", data.decode('utf-8'))

    # 发送消息
    server.sendto(("收到了你的消息" + data.decode('utf-8')).encode('utf-8'), addr)

# 关闭套接字
server.close()
