"""
    TCP客户端
    1.创建套接字 socket
    2.发送连接请求 connect
    3.发送/接收消息 send/recv
    4.关闭套接字 close
"""
# 导入 socket模块
import socket

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# UDP: socket.SOCK_DGRAM
# TCP: socket.SOCK_STREAM
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2.发送连接请求 connect
client.connect(ADDR)
print("与服务器连接成功")

# 循环收发消息
while True:
    # 3.发送消息send
    message = input("点菜：")

    if not message:
        continue

    # 设置中断
    if message == "就这些了":
        break

    client.send(message.encode("utf-8"))

    # 接收消息 recv
    data = client.recv(1024).decode("utf-8")
    print("服务端回复：", data)

# 4.关闭套接字close
client.close()  # 发送空字符串
