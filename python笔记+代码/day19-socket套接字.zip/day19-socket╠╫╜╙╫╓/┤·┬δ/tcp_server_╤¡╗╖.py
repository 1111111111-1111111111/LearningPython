"""
    TCP服务器
    1.创建套接字 socket
    2.绑定ip端口 bind
    3.设置监听 listen
    4.等待客户端连接 accept
    5.发送/接收消息 send/recv
    6.关闭连接对象 close
    7.关闭套接字 close
"""
# 导入 socket模块
from socket import *

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# AF_INET 代表ipv4
# SOCK_STREAM 代表TCP模式
server = socket(AF_INET, SOCK_STREAM)

# 2.绑定ip端口 bind
server.bind(ADDR)

# 3.设置监听 listen
# 5 代表最大监听队列
server.listen(5)
print("服务端创建成功，端口号为 8080")

# 4.等待客户端连接 accept
# conn 建立连接后的连接对象
# addr 客户端的地址
conn, addr = server.accept()  # 阻塞
print(f"与{addr}客户端连接成功")

# 循环收发消息
while True:
    # 5.发送/接收消息 send/recv
    # udp: recvfrom
    # tcp: recv
    # 1024: 最大接收消息的字节数
    data = conn.recv(1024)  # 阻塞

    # 设置中断
    if not data:
        print(f"与{addr}断开连接")
        break

    # 打印客户端消息
    print("客户端点菜：", data.decode('utf-8'))

    # 回应客户端消息
    reply = f"{data.decode('utf-8')}菜品已经收到，正在准备，马上就好"
    conn.send(reply.encode('utf-8'))

# 6.关闭连接对象 close
conn.close()

# 7.关闭套接字 close
server.close()
