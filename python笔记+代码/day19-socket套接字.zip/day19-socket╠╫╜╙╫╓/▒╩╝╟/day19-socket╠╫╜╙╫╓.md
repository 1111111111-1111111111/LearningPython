# socket套接字

## 上节课回顾

```python
- 认识网络
	-C/S架构
    	客户机和服务器
        客户端
    -B/S架构
    	浏览器/服务器
- 计算机网络种类    
	局域网 ， 城域网 ， 广域网
- 互联网协议
	OSI七层模型          	TCP/IP协议
    应用层					
    表示层					  应用层
    会话层         --->
    传输层					  传输层	
    网络层					  网络层
    数据链路层				 网络接口层
    物理层
    
    网络协议:在网络数据传中,都要遵循的执行规则，它规定了每一层在完成自己任务时候应该遵循什么规范
	HTTP协议：超文本传输协议，常用于web浏览器和服务器之间的传递信息
	HTTPS协议：超文本传输安全协议，通过使用SSI/TSL加密技术以及HTTP协议结合进行网络数据安全传输
- ip地址
	ip地址:一台计算机在网络当中的地址编号标识
    IPv4:32位地址长度
    IPv6:128位地址长度
- 域名
	域名是用于标识和访问互联网上的资源（如网站、服务器等）的人类可读的名称。它是由一系列按照特定规则组合的字符串组成，用于在计算机网络中定位和识别特定的资源。
- 端口
	端口是网络地址的一部分,在一台计算机上,每个网络程序对应一个端口
    端口取值范围: 0~65535 之间的整数
	一台计算机上的端口号不会重复
    
- socket套接字
	Socket套接字是计算机网络编程中用于实现网络通信的一种机制。
- UDP套接字
	- UDP服务端
    1.创建套接字 socket()
    2.绑定ip端口 bind()
    3.发送/接收消息 sendto()/recvfrom()
    4.关闭套接字 close()
    
    - UDP客户端
    1.创建套接字 socket()
    2.发送/接收消息 sendto()/recvfrom()
    3.关闭套接字 close()    
```



## 1.TCP套接字

### 1.1 面向连接的传输服务

- 提供了可靠的数据传递,传输过程中无丢失，无失序，无差错，无重复
- 可靠性保障机制(自动完成)
  - 在通信之前需要建立数据连接
  - 确认应答机制
  - 通信结束后正常断开连接

### 1.2 三次握手

![1744379511305](imgs/1744379511305.png)

最开始的时候客户端和服务器都是处于CLOSED关闭状态。主动打开连接的为客户端，被动打开连接的是服务器。

TCP服务器进程先创建传输控制块TCB，时刻准备接受客户进程的连接请求，此时服务器就进入了 LISTEN 监听状态

- 第一次握手 TCP客户进程也是先创建传输控制块TCB，然后向服务器发出连接请求报文，这是报文首部中的同部位SYN=1，同时选择一个初始序列号 seq=x ，此时，TCP客户端进程进入了 SYN-SENT 同步已发送状态

- 第二次握手 TCP服务器收到请求报文后，如果同意连接，则会向客户端发出确认报文。确认报文中应该 ACK=1，SYN=1，确认号是ack=x+1，同时也要为自己初始化一个序列号 seq=y，此时，TCP服务器进程进入了 SYN-RCVD 同步收到状态

- 第三次握手 TCP客户端收到确认后，还要向服务器给出确认。确认报文的ACK=1，ack=y+1，自己的序列号seq=x+1，此时，TCP连接建立，客户端进入ESTABLISHED已建立连接状态 触发三次握手
  

### 1.3 四次挥手

![1744379545143](imgs/1744379545143.png)

数据传输完毕后，双方都可释放连接。最开始的时候，客户端和服务器都是处于ESTABLISHED状态，然后客户端主动关闭，服务器被动关闭。

- 第一次挥手 客户端发出连接释放报文，并且停止发送数据。释放数据报文首部，FIN=1，其序列号为seq=u（等于前面已经传送过来的数据的最后一个字节的序号加1），此时，客户端进入FIN-WAIT-1（终止等待1）状态

- 第二次挥手 服务器端接收到连接释放报文后，发出确认报文，ACK=1，ack=u+1，并且带上自己的序列号seq=v，此时，服务端就进入了CLOSE-WAIT 关闭等待状态

- 第三次挥手 客户端接收到服务器端的确认请求后，客户端就会进入FIN-WAIT-2（终止等待2）状态，等待服务器发送连接释放报文，服务器将最后的数据发送完毕后，就向客户端发送连接释放报文，服务器就进入了LAST-ACK（最后确认）状态，等待客户端的确认。

- 第四次挥手 客户端收到服务器的连接释放报文后，必须发出确认，ACK=1，ack=w+1，而自己的序列号是seq=u+1，此时，客户端就进入了TIME-WAIT（时间等待）状态，但此时TCP连接还未终止，必须要经过2MSL后（最长报文寿命），当客户端撤销相应的TCB后，客户端才会进入CLOSED关闭状态，服务器端接收到确认报文后，会立即进入CLOSED关闭状态，到这里TCP连接就断开了，四次挥手完成
  

**tcp套接字细节**

- tcp连接中一端退出，另一端依然阻塞在recv，此时recv会马上返回一个空字符串
- 如果一端已经不存在,任然通过send向其发送数据则会产生BrokenPipeError/ConnectionResetError
- 一个服务端可以同时连接多个客户端,也能够被重复连接



**TCP编程流程**

- **socket**：创建套接字
- **bind**：绑定地址
- **listen**：设置监听
- **accept**：等待处理连接
- **send/recv**：发送/接受消息
- **close**：关闭连接
- **connect**: 客户端像服务端发起连接请求

```python
# 创建套接字
sock=socket.socket(family,type)
   功能：创建套接字
   参数：family  网络地址类型 AF_INET表示ipv4
        type  套接字类型 SOCK_STREAM 表示tcp套接字 （也叫流式套接字）
   返回值： 套接字对象
```



```python
# 绑定地址 （与udp套接字相同）
sock.bind(addr)
   功能： 绑定本机网络地址
   参数： 二元元组 (ip,port) ('0.0.0.0',8888)
```



```python
# 设置监听
sock.listen(n)
功能 ： 将套接字设置为监听套接字，确定监听队列大小
参数 ： 监听队列大小
```



```python
# 请求连接
sock.connect(server_addr)
功能：连接服务器
参数：元组 服务器地址
```



```python
# 处理客户端连接请求
conn,addr = sockfd.accept()
功能： 阻塞等待处理客户端请求
返回值： conn 客户端连接套接字
addr 连接的客户端地址
```



```python
# 发送/接受消息
n = conn.send(data)
功能 : 发送消息
参数 ：要发送的内容 bytes格式
返回值： 发送的字节数
```



```python
# 关闭连接
sock.close()
   功能：关闭套接字
```



### 1.4单次通讯



**tcp服务端代码：**

```python
"""
    TCP服务器
    1.创建套接字 socket
    2.绑定ip端口 bind
    3.设置监听 listen
    4.等待客户端连接 accept
    5.发送/接收消息 send/recv
    6.关闭连接对象 close
    7.关闭套接字 close
"""
# 导入 socket模块
import socket

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# socket.AF_INET 代表ipv4
# socket.SOCK_STREAM 代表TCP模式
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2.绑定ip端口 bind
server.bind(ADDR)

# 3.设置监听 listen
# 5 代表最大监听队列
server.listen(5)
print("服务端创建成功，端口号为 8080")

# 4.等待客户端连接 accept
# conn 建立连接后的连接对象
# addr 客户端的地址
conn, addr = server.accept()  # 阻塞
print(f"与{addr}客户端连接成功")

# 5.发送/接收消息 send/recv
# udp: recvfrom
# tcp: recv
# 1024: 最大接收消息的字节数
data = conn.recv(1024)  # 阻塞

# 打印客户端消息
print("收到客户端消息：", data.decode('utf-8'))

# 回应客户端消息
reply = f"接收到你的消息：{data.decode('utf-8')}"
conn.send(reply.encode('utf-8'))

# 6.关闭连接对象 close
conn.close()

# 7.关闭套接字 close
server.close()


```

**tcp客户端代码：**

```python
"""
    TCP客户端
    1.创建套接字 socket
    2.发送连接请求 connect
    3.发送/接收消息 send/recv
    4.关闭套接字 close
"""
# 导入 socket模块
import socket

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# UDP: socket.SOCK_DGRAM
# TCP: socket.SOCK_STREAM
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2.发送连接请求 connect
client.connect(ADDR)
print("与服务器连接成功")

# 3.发送/接收消息 send/recv
message = input(">>:")  # 阻塞
client.send(message.encode("utf-8"))

# 接收服务端消息
data = client.recv(1024).decode("utf-8")
print("服务端回复：", data)

# 4.关闭套接字 close
client.close()

```



### 1.5循环通讯

**server**

```python
"""
    TCP服务器
    1.创建套接字 socket
    2.绑定ip端口 bind
    3.设置监听 listen
    4.等待客户端连接 accept
    5.发送/接收消息 send/recv
    6.关闭连接对象 close
    7.关闭套接字 close
"""
# 导入 socket模块
from socket import *

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# AF_INET 代表ipv4
# SOCK_STREAM 代表TCP模式
server = socket(AF_INET, SOCK_STREAM)

# 2.绑定ip端口 bind
server.bind(ADDR)

# 3.设置监听 listen
# 5 代表最大监听队列
server.listen(5)
print("服务端创建成功，端口号为 8080")

# 4.等待客户端连接 accept
# conn 建立连接后的连接对象
# addr 客户端的地址
conn, addr = server.accept()  # 阻塞
print(f"与{addr}客户端连接成功")

# 循环收发消息
while True:
    # 5.发送/接收消息 send/recv
    # udp: recvfrom
    # tcp: recv
    # 1024: 最大接收消息的字节数
    data = conn.recv(1024)  # 阻塞

    # 设置中断
    if not data:
        print(f"与{addr}断开连接")
        break

    # 打印客户端消息
    print("客户端点菜：", data.decode('utf-8'))

    # 回应客户端消息
    reply = f"{data.decode('utf-8')}菜品已经收到，正在准备，马上就好"
    conn.send(reply.encode('utf-8'))

# 6.关闭连接对象 close
conn.close()

# 7.关闭套接字 close
server.close()


```

**client**

```python
"""
    TCP客户端
    1.创建套接字 socket
    2.发送连接请求 connect
    3.发送/接收消息 send/recv
    4.关闭套接字 close
"""
# 导入 socket模块
import socket

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# UDP: socket.SOCK_DGRAM
# TCP: socket.SOCK_STREAM
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2.发送连接请求 connect
client.connect(ADDR)
print("与服务器连接成功")

# 循环收发消息
while True:
    # 3.发送消息send
    message = input("点菜：")

    if not message:
        continue

    # 设置中断
    if message == "就这些了":
        break

    client.send(message.encode("utf-8"))

    # 接收消息 recv
    data = client.recv(1024).decode("utf-8")
    print("服务端回复：", data)

# 4.关闭套接字close
client.close()  # 发送空字符串


```

### 1.6.服务端再服务

**sever**

```python
"""
    TCP服务器
    1.创建套接字 socket
    2.绑定ip端口 bind
    3.设置监听 listen
    4.等待客户端连接 accept
    5.发送/接收消息 send/recv
    6.关闭连接对象 close
    7.关闭套接字 close
"""
# 导入 socket模块
from socket import *

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# AF_INET 代表ipv4
# SOCK_STREAM 代表TCP模式
server = socket(AF_INET, SOCK_STREAM)

# 2.绑定ip端口 bind
server.bind(ADDR)

# 3.设置监听 listen
# 5 代表最大监听队列
server.listen(5)
print("服务端创建成功，端口号为 8080")

# 循环等待用户连接
while True:
    # 4.等待客户端连接 accept
    print("等待连接...")
    conn, addr = server.accept()  # 阻塞
    print(f"与{addr}客户端连接成功")

    # 循环收发消息
    while True:
        # 5.发送/接收消息 send/recv
        data = conn.recv(1024)  # 阻塞

        # 设置中断
        if not data:
            print(f"与{addr}断开连接")
            break

        # 打印客户端消息
        print("客户端点菜：", data.decode('utf-8'))

        # 回应客户端消息
        reply = f"{data.decode('utf-8')}菜品已经收到，正在准备，马上就好"
        conn.send(reply.encode('utf-8'))

    # 关闭连接对象
    conn.close()

# 关闭套接字
server.close()


```



**client**

```python
"""
    TCP客户端
    1.创建套接字 socket
    2.发送连接请求 connect
    3.发送/接收消息 send/recv
    4.关闭套接字 close
"""
# 导入 socket模块
import socket

ADDR = ("127.0.0.1", 8080)

# 1.创建套接字 socket
# UDP: socket.SOCK_DGRAM
# TCP: socket.SOCK_STREAM
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2.发送连接请求 connect
client.connect(ADDR)
print("与服务器连接成功")

# 循环收发消息
while True:
    # 3.发送消息send
    message = input("点菜：")

    if not message:
        continue

    # 设置中断
    if message == "##":
        break

    client.send(message.encode("utf-8"))

    # 接收消息 recv
    data = client.recv(1024).decode("utf-8")
    print("服务端回复：", data)

# 4.关闭套接字close
client.close()  # 发送空字符串


```



```python
# ip可复用
# socket.SOL_SOCKET socket协议
# SO_REUSEADDR 允许在同一 IP 地址和端口上绑定多个套接字
# 0 代表关闭， 1 代表开启
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)


# 检查端口
- 命令行
#查看
netstat -ano | findstr :9999
# 终止程序    
taskkill /F /PID 20992    
```



## 2.使用场景

- **TCP适合对准确要求高，传输数据大的场景**
  - 文件传输:数据下载(电影,音乐)，上传照片，访问网站
  - 邮件收发
  - 点对点数据传输:登录，远程，红包，一对一聊天
- **UDP适合可靠性要求相对不高，传输自由的场景**
  - 视频流：直播，视频聊天
  - 广播：网络广播，群发消息
  - 实时性要求高：如游戏等









