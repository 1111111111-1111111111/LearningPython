import struct

res = struct.pack('i', 2000)
print(res)
print(len(res))
print(type(res))

data = struct.unpack('i', res)
# 解码后返回的是一个元组，第一个元素就是数据长度
print(data)
print(data[0])
