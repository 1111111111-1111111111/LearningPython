# 客户端
import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(('127.0.0.1', 8880))
# 头部信息
client.send(b'9') # 90000
client.send("你好呀".encode('utf-8'))

client.send("你在干嘛呀".encode('utf-8'))

client.close()
