# 服务器
import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 8880))

server.listen(5)

conn, addr = server.accept()
# 接收头部信息
header = conn.recv(3)
data = conn.recv(len(header.decode()))
print(data.decode('utf-8'))

conn.close()

server.close()
