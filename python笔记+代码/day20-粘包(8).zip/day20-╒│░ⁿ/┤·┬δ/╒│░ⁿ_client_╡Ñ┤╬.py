# 客户端
import socket
import struct

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(("127.0.0.1", 8880))

data01 = "你好呀".encode("utf-8")
header01 = struct.pack("i", len(data01))
client.send(header01)
client.send(data01)

data02 = "你在干嘛呀".encode("utf-8")
header02 = struct.pack("i", len(data02))
client.send(header02)
client.send(data02)

client.close()
