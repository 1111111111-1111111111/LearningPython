# 客户端
import socket
import struct

ADDR = ("127.0.0.1", 9000)

# 创建套接字
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 发起连接请求
client.connect(ADDR)

# 循环通信
while True:
    message = input(">>:").encode("utf-8")
    if not message:
        continue
    # 固定发送四个字节
    header = struct.pack("i", len(message))
    client.send(header + message)

    # 接收服务器回应
    data = client.recv(1024).decode("utf-8")
    print("服务器消息：", data)

    # 设置中断
    if message == b"##":
        print("客户端退出连接！")
        break

client.close()
