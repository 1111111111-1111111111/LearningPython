# 服务端
import socket
import struct

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 8880))

server.listen(5)

conn, addr = server.accept()

# 固定读取四个字节
header01 = conn.recv(4)
# 真实数据长度
data_length01 = struct.unpack("i", header01)[0]
# 接受真实数据
data01 = conn.recv(data_length01)
print(data01.decode('utf-8'))

# 固定读取四个字节
header02 = conn.recv(4)
# 真实数据长度
data_length02 = struct.unpack("i", header02)[0]
# 接受真实数据
data02 = conn.recv(data_length02)
print(data02.decode('utf-8'))

conn.close()

server.close()
