import socket
import struct

ADDR = ("127.0.0.1", 9000)


def recv_data(conn, chunk_size=1024):
    # 接收消息 解决粘包
    # 固定读取四个字节
    header = conn.recv(4)
    # 获取真实数据长度
    data_length = struct.unpack("i", header)[0]
    # 已接受长度
    has_data_len = 0
    # 空字节串，用于拼接真实数据
    total_data = b""

    # 按块接收
    while has_data_len < data_length:
        # 剩余数据长度
        length = data_length - has_data_len
        size = chunk_size if length > chunk_size else length
        # 按块接收
        chunk = conn.recv(size)
        # 对数据进行拼接
        total_data += chunk
        # 对长度进行累加
        has_data_len += len(chunk)

    # 返回一个完整的数据
    return total_data


def send_data(conn, message):
    # 把数据长度转化为四个字节
    data = message.encode("utf-8")
    # 头部字节
    header = struct.pack("i", len(data))
    # 发送头部字节
    conn.send(header)
    # 发送真实数据
    conn.send(data)


# 创建套接字
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 发起连接请求
client.connect(ADDR)

# 循环通信
while True:
    message = input(">>:")
    if not message:
        continue
    # 发送数据
    send_data(client, message)
    # 接收消息
    data = recv_data(client)
    print("服务端回复：", data.decode("utf-8"))
    # 设置中断
    if message == "##":
        print("客户端退出连接！")
        break

client.close()
