# 服务器
import socket
import struct

ADDR = ("127.0.0.1", 9000)


def recv_data(conn, chunk_size=1024):
    # 接收消息 解决粘包
    # 固定读取四个字节
    header = conn.recv(4)
    # 获取真实数据长度
    data_length = struct.unpack("i", header)[0]
    # 已接受长度
    has_data_len = 0
    # 空字节串，用于拼接真实数据
    total_data = b""

    # 按块接收
    while has_data_len < data_length:
        # 剩余数据长度
        length = data_length - has_data_len
        size = chunk_size if length > chunk_size else length
        # 按块接收
        chunk = conn.recv(size)
        # 对数据进行拼接
        total_data += chunk
        # 对长度进行累加
        has_data_len += len(chunk)

    # 返回一个完整的数据
    return total_data


def send_data(conn, message):
    # 把数据长度转化为四个字节
    data = message.encode("utf-8")
    # 头部字节
    header = struct.pack("i", len(data))
    # 发送头部字节
    conn.send(header)
    # 发送真实数据
    conn.send(data)


# 创建套接字
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定IP地址
server.bind(ADDR)

# 设置监听
server.listen(5)

# 循环连接
while True:
    print("等待连接...")
    conn, addr = server.accept()
    print(f"与{addr}建立连接")
    # 循环通讯
    while True:
        # 防止意外断开
        try:
            # 调用函数得到二进制数据
            data = recv_data(conn)
            # 打印总数据
            print("收到客户端消息：", data.decode('utf-8'))

            # 调用函数进行发送
            message = "收到客户端消息"
            send_data(conn, message)

            # 设置中断
            if data == b"##":
                print(addr, "退出连接！")
                break
        except Exception as err:
            print(addr, "意外断开")
            break
    conn.close()
server.close()
