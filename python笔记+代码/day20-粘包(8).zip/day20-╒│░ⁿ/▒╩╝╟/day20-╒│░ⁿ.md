#  粘包

## 上节课回顾

```python
- TCP套接字
	- 三次握手
    客户端向服务器发送报文请求连接
	服务收到请求回复报文可以连接
	客户端收到回复再次发送报文建立连接
    
    - 四次挥手
    发起方发送报文请求断开
	接收方收到请求回复信息收到,并准备断开
	接收方准备完成，再次发送表示可以断开
	发送方收到确定，发送最终消息完成断开
    
    - TCP服务端
    1.创建套接字 socket()
    2.绑定ip端口 bind()
    3.设置监听：listen()
    4.等待客户端发起连接 accept()
    5.发送/接收 send()/recv()
    6.关闭连接对象 close()
    7.关闭套接字 close()
    
    - TCP客户端
    1.创建套接字 socket()
    2.发送连接请求 connect()
    3.发送/接收 send recv()
    4.关闭套接字 close()
    
```



## 1.粘包

在socket中数据不是直接发送给对方，是将数据发送到本机操作系统的缓冲区中；接收数据也是一样的，在操作系统的缓冲区中提取数据

缓冲区可以存储少量的数据

### 1.1产生粘包

粘包问题发生在基于TCP协议的网络通信中，因为TCP协议是一个面向流的协议，粘包问题主要分为两种情况：

**发送方**：发送方在很短的时间内连续发送了多个数据包，这些数据包可能会在底层的TCP协议中被合并一个数据包发送出去。

**接收方**：接收方在读取数据时，没有按照发送方发送的边界来读取数据，可能会把多个数据包的数据读到一起。

```python
# 服务器
import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 8880))

server.listen(5)

conn, addr = server.accept()

data = conn.recv(1024)

print(data.decode('utf-8'))

conn.close()

server.close()

---------------------------------------------------------------------
# 客户端
import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(('127.0.0.1', 8880))

client.send("你好呀".encode('utf-8'))

client.send("你在干嘛呀".encode('utf-8'))

client.close()

```

### 1.2解决粘包

- 每次发送消息时，都将消息划分为头部（固定字节长度）和数据两部分。例如：头部，用4个字节表示后面数据的长度
  - 发送数据，先发送数据的长度，再发送数据（或拼接起来再发送）
  - 接收数据，先读4个字节就可以知道自己这个数据包的数据长度，再根据长度读取到数据

让发送端在发送数据之前，先发送数据的长度，让接收端知道要接收多少个数据，然后使用循环进行接收所有的数据

```python
pack()  将python基本数据类型转为字节型
    2个参数
    参数1：模式
        "i" 表示将整数转为  4个字节
        "f" 表示将浮点数转为 4个字节
    参数2：被转换数据

    返回值，就是四个字节

unpack() 将字节型转为基本数据类型
    2个参数
    参数1：模式
    参数2：被转数据 字节数据

    返回值：元组(数据,)
    
import struct

res = struct.pack('i', 2000)
print(res)
print(len(res))
print(type(res))

data = struct.unpack('i', res)
# 解码后返回的是一个元组，第一个元素就是数据长度
print(data)
print(data[0])

```



### 粘包单次通讯

```python
# 服务端
import socket
import struct

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 8880))

server.listen(5)

conn, addr = server.accept()

# 固定读取四个字节
header01 = conn.recv(4)
# 真实数据长度
data_length01 = struct.unpack("i", header01)[0]
# 接受真实数据
data01 = conn.recv(data_length01)
print(data01.decode('utf-8'))

# 固定读取四个字节
header02 = conn.recv(4)
# 真实数据长度
data_length02 = struct.unpack("i", header02)[0]
# 接受真实数据
data02 = conn.recv(data_length02)
print(data02.decode('utf-8'))

conn.close()

server.close()
--------------------------------------------------------------------
# 客户端
import socket
import struct

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(("127.0.0.1", 8880))

data01 = "你好呀".encode("utf-8")
header01 = struct.pack("i", len(data01))
client.send(header01)
client.send(data01)

data02 = "你在干嘛呀".encode("utf-8")
header02 = struct.pack("i", len(data02))
client.send(header02)
client.send(data02)

client.close()

```



### 粘包循环通讯

**server**

```python
# 服务器
import socket
import struct

ADDR = ("127.0.0.1", 9000)

# 创建套接字
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定IP地址
server.bind(ADDR)

# 设置监听
server.listen(5)

# 循环连接
while True:
    print("等待连接...")
    conn, addr = server.accept()
    print(f"与{addr}建立连接")
    # 循环通讯
    while True:
        # 接收消息 解决粘包
        # 固定读取四个字节
        header = conn.recv(4)
        # 获取真实数据长度
        data_length = struct.unpack("i", header)[0]
        # 已接受长度
        has_data_len = 0
        # 空字节串，用于拼接真实数据
        total_data = b""

        # 按块接收
        while True:
            # 剩余数据长度
            length = data_length - has_data_len
            if length > 1024:
                size = 1024
            else:
                size = length
            # 按块接收
            chunk = conn.recv(size)
            # 对数据进行拼接
            total_data += chunk
            # 对长度进行累加
            has_data_len += len(chunk)
            # 数据接收完毕退出循环
            if has_data_len == data_length:
                break
        # 打印总数据
        print("收到客户端消息：", total_data.decode('utf-8'))

        conn.send(b"ok")

        # 设置中断
        if total_data == b"##":
            print(addr, "退出连接！")
            break
    conn.close()
server.close()


```



**client**

```python
# 客户端
import socket
import struct

ADDR = ("127.0.0.1", 9000)

# 创建套接字
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 发起连接请求
client.connect(ADDR)

# 循环通信
while True:
    message = input(">>:").encode("utf-8")
    if not message:
        continue
    # 固定发送四个字节
    header = struct.pack("i", len(message))
    client.send(header + message)

    # 接收服务器回应
    data = client.recv(1024).decode("utf-8")
    print("服务器消息：", data)

    # 设置中断
    if message == b"##":
        print("客户端退出连接！")
        break

client.close()


```



### 粘包函数

**tcp**

```python
# 服务器
import socket
import struct

ADDR = ("127.0.0.1", 9000)


def recv_data(conn, chunk_size=1024):
    # 接收消息 解决粘包
    # 固定读取四个字节
    header = conn.recv(4)
    # 获取真实数据长度
    data_length = struct.unpack("i", header)[0]
    # 已接受长度
    has_data_len = 0
    # 空字节串，用于拼接真实数据
    total_data = b""

    # 按块接收
    while has_data_len < data_length:
        # 剩余数据长度
        length = data_length - has_data_len
        size = chunk_size if length > chunk_size else length
        # 按块接收
        chunk = conn.recv(size)
        # 对数据进行拼接
        total_data += chunk
        # 对长度进行累加
        has_data_len += len(chunk)

    # 返回一个完整的数据
    return total_data


def send_data(conn, message):
    # 把数据长度转化为四个字节
    data = message.encode("utf-8")
    # 头部字节
    header = struct.pack("i", len(data))
    # 发送头部字节
    conn.send(header)
    # 发送真实数据
    conn.send(data)


# 创建套接字
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定IP地址
server.bind(ADDR)

# 设置监听
server.listen(5)

# 循环连接
while True:
    print("等待连接...")
    conn, addr = server.accept()
    print(f"与{addr}建立连接")
    # 循环通讯
    while True:
        # 防止意外断开
        try:
            # 调用函数得到二进制数据
            data = recv_data(conn)
            # 打印总数据
            print("收到客户端消息：", data.decode('utf-8'))

            # 调用函数进行发送
            message = "收到客户端消息"
            send_data(conn, message)

            # 设置中断
            if data == b"##":
                print(addr, "退出连接！")
                break
        except Exception as err:
            print(addr, "意外断开")
            break
    conn.close()
server.close()


```



```python
import socket
import struct

ADDR = ("127.0.0.1", 9000)


def recv_data(conn, chunk_size=1024):
    # 接收消息 解决粘包
    # 固定读取四个字节
    header = conn.recv(4)
    # 获取真实数据长度
    data_length = struct.unpack("i", header)[0]
    # 已接受长度
    has_data_len = 0
    # 空字节串，用于拼接真实数据
    total_data = b""

    # 按块接收
    while has_data_len < data_length:
        # 剩余数据长度
        length = data_length - has_data_len
        size = chunk_size if length > chunk_size else length
        # 按块接收
        chunk = conn.recv(size)
        # 对数据进行拼接
        total_data += chunk
        # 对长度进行累加
        has_data_len += len(chunk)

    # 返回一个完整的数据
    return total_data


def send_data(conn, message):
    # 把数据长度转化为四个字节
    data = message.encode("utf-8")
    # 头部字节
    header = struct.pack("i", len(data))
    # 发送头部字节
    conn.send(header)
    # 发送真实数据
    conn.send(data)


# 创建套接字
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 发起连接请求
client.connect(ADDR)

# 循环通信
while True:
    message = input(">>:")
    if not message:
        continue
    # 发送数据
    send_data(client, message)
    # 接收消息
    data = recv_data(client)
    print("服务端回复：", data.decode("utf-8"))
    # 设置中断
    if message == "##":
        print("客户端退出连接！")
        break

client.close()


```

























