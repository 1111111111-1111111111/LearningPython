import socket

ADDR = ("127.0.0.1", 9999)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(ADDR)
print("与服务器连接成功")

# 循环收发消息
while True:
    mess = input(">>:")
    if not mess:
        continue
    if mess == "##":
        print("客户端退出连接")
        break
    client.send(mess.encode("utf-8"))
    data = client.recv(1024)
    print("服务端回复：", data.decode("utf-8"))

client.close()
