import socket
import select

ADDR = ("127.0.0.1", 9999)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# ip可复用
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind(ADDR)

server.listen(5)

# 读列表, 保存套接字对象，未来会添加客户端连接对象
read_list = [server]

while True:
    # 添加监听机制
    r, w, x = select.select(read_list, [], [])

    # 遍历r列表拿取其中准备就绪的对象
    for read in r:
        if read == server:
            conn, addr = server.accept()
            print(f"与{addr}连接成功！")
            # 把客户端连接对象加入到监听列表中
            read_list.append(conn)
        else:
            data = read.recv(1024)
            if data:
                print("客户端点菜：", data.decode("utf-8"))
                read.send(f"收到消息：{data.decode("utf-8")}".encode("utf-8"))
            else:
                print(f"断开连接，conn：{read}")
                read.close()
                read_list.remove(read)

server.close()
