import socket


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", 9999))
    server.listen(5)
    # 等待浏览器连接
    while True:
        conn, addr = server.accept()
        print(addr)
        handle(conn)
        conn.close()
    server.close()


def handle(conn):
    data = conn.recv(1024)
    # 组织响应
    response = "HTTP/1.1 200 ok\r\n"  # \r:回车 \n:换行
    response += "Content-Type: image/jpeg\r\n"
    response += "\r\n"
    with open("evolution.jpg", "rb") as file:
        response = response.encode() + file.read()
    conn.send(response)


if __name__ == '__main__':
    main()
