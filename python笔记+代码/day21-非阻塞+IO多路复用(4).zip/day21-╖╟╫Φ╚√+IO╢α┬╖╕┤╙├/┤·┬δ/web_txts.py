import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 9999))

server.listen(5)

# 循环连接、
while True:
    conn, addr = server.accept()
    print(addr)

    request = conn.recv(1024)
    print(request.decode('utf-8'))

    # 组织响应
    response = "HTTP/1.1 200 ok\r\n"  # \r:回车 \n:换行
    response += "Content-Type: text/html\r\n"
    response += "\r\n"
    # GET /index.html HTTP/1.1
    info_str = request.decode('utf-8').split('\r\n')[0]
    info = info_str.split(' ')[1]
    if info == "/lw":
        response += "你好，老王！"
    elif info == "/jz":
        response += "来吃饺子了！"
    else:
        response += "请问是谁呀？"

    conn.send(response.encode('gbk'))
    conn.close()
server.close()

