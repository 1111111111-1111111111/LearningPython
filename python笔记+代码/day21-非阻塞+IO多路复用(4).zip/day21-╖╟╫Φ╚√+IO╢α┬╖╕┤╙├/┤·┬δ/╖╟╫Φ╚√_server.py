import socket

ADDR = ("127.0.0.1", 9999)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(ADDR)

server.listen(5)

# 设置为非阻塞状态的套接字
server.setblocking(False)

# 保存客户端的连接对象
conn_list = []  # conn01 conn02 conn03

# 断开的连接对象
del_conn = []

while True:
    # 捕获异常
    try:
        # 等待多个客户端连接
        conn, addr = server.accept()
        conn_list.append(conn)
        print(f"与{addr}建立连接")
    except BlockingIOError:
        # 访问列表，将就绪的连接对象进行通讯
        for conn in conn_list:
            try:
                data = conn.recv(1024)
                if not data:
                    conn.close()  # 四次挥手
                    del_conn.append(conn)
                    continue
                print(f"客户端{conn}点菜：", data.decode('utf-8'))
                conn.send(f"点菜成功:{data.decode('utf-8')}".encode('utf-8'))
            except BlockingIOError:
                # 继续遍历下一个连接对象
                continue
        for conn in del_conn:
            print(f"断开连接：{conn}")  # conn02
            conn_list.remove(conn)

        # 清空删除列表
        del_conn.clear()

server.close()
