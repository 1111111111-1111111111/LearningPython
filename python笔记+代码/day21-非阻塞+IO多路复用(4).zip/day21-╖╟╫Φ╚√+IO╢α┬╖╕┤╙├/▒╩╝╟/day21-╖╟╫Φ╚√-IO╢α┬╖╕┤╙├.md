# 非阻塞+IO多路复用

# 1.非阻塞状态

socket都是会阻塞的（等待状态）

在等待客户端连接以及接收客户端的消息的时候会发生阻塞状态（accept，recv）

设置非阻塞：socket对象.setblocking(False)

**sever**

```python
import socket

ADDR = ("127.0.0.1", 9999)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(ADDR)

server.listen(5)

# 设置为非阻塞状态的套接字
server.setblocking(False)

# 保存客户端的连接对象
conn_list = []  # conn01 conn02 conn03

# 断开的连接对象
del_conn = []

while True:
    # 捕获异常
    try:
        # 等待多个客户端连接
        conn, addr = server.accept()
        conn_list.append(conn)
        print(f"与{addr}建立连接")
    except BlockingIOError:
        # 访问列表，将就绪的连接对象进行通讯
        for conn in conn_list:
            try:
                data = conn.recv(1024)
                if not data:
                    conn.close()  # 四次挥手
                    del_conn.append(conn)
                    continue
                print(f"客户端{conn}点菜：", data.decode('utf-8'))
                conn.send(f"点菜成功:{data.decode('utf-8')}".encode('utf-8'))
            except BlockingIOError:
                # 继续遍历下一个连接对象
                continue
        for conn in del_conn:
            print(f"断开连接：{conn}")  # conn02
            conn_list.remove(conn)

        # 清空删除列表
        del_conn.clear()

server.close()


```



**client**

```python
import socket

ADDR = ("127.0.0.1", 9999)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(ADDR)
print("与服务器连接成功")

# 循环收发消息
while True:
    mess = input(">>:")
    if not mess:
        continue
    if mess == "##":
        print("客户端退出连接")
        break
    client.send(mess.encode("utf-8"))
    data = client.recv(1024)
    print("服务端回复：", data.decode("utf-8"))

client.close()


```



# 2.IO多路复用

IO多路复用是用于提升效率，单个进程可以同时监听多个网络连接IO（一个服务端可以服务多个客户端）

IO多路复用，通过一种机制，可以监视多个文件描述符，一旦描述符就绪（读，写），能够通知到程序进行相应的读写操作

```python
select 方法
import select
rs, ws, xs=select(rlist, wlist, xlist[, timeout])
功能: 监控IO事件，阻塞等待IO发生
参数： 
rlist 列表 读IO列表，添加等待发生的或者可读的IO事件
wlist 列表 写IO列表，存放要可以主动处理的或者可写的IO事件
xlist 列表 异常IO列表，存放出现异常要处理的IO事件
timeout 超时时间
返回值： 
rs 列表 rlist中准备就绪的IO
ws 列表 wlist中准备就绪的IO
xs 列表 xlist中准备就绪的IO

# wlist,xlist 目前不需要使用到，直接传一个空列表即可
```



**server**

```python
import socket
import select

ADDR = ("127.0.0.1", 9999)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# ip可复用
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind(ADDR)

server.listen(5)

# 读列表, 保存套接字对象，未来会添加客户端连接对象
read_list = [server]

while True:
    # 添加监听机制
    r, w, x = select.select(read_list, [], [])

    # 遍历r列表拿取其中准备就绪的对象
    for read in r:
        if read == server:
            conn, addr = server.accept()
            print(f"与{addr}连接成功！")
            # 把客户端连接对象加入到监听列表中
            read_list.append(conn)
        else:
            data = read.recv(1024)
            if data:
                print("客户端点菜：", data.decode("utf-8"))
                read.send(f"收到消息：{data.decode("utf-8")}".encode("utf-8"))
            else:
                print(f"断开连接，conn：{read}")
                read.close()
                read_list.remove(read)

server.close()


```



**client**

```python
import socket

ADDR = ("127.0.0.1", 9999)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(ADDR)
print("与服务器连接成功")

# 循环收发消息
while True:
    mess = input(">>:")
    if not mess:
        continue
    if mess == "##":
        print("客户端退出连接")
        break
    client.send(mess.encode("utf-8"))
    data = client.recv(1024)
    print("服务端回复：", data.decode("utf-8"))

client.close()


```



# 3.HTTP协议

HTTP 协议主要用于网页获取和数据传输。作为一个应用层协议，HTTP 依赖于 TCP 进行数据传输。

在 HTTP 通信过程中，客户端（浏览器）通过 TCP 传输发送 HTTP 请求给服务端。服务端接收到请求后进行解析，并处理请求内容，组织响应内容。接着，服务端将响应内容以 HTTP 响应格式发送回浏览器。浏览器接收到响应内容后，会进行解析并展示给用户。

## 3.1HTTP请求

请求行：包含请求方法、请求内容和HTTP版本。

```
GET /index.html HTTP/1.1
```

请求头部：包含请求的附加信息，每一行都是一个键值对，键和值之间用冒号分隔。例如：

```
User-Agent: Mozilla/5.0
Accept: text/html
```

-   User-Agent：包含发出请求的浏览器或客户端软件的信息。
-   Accept：指定客户端能够处理的内容类型。它告诉服务器返回的资源类型。
-   Authorization：用于客户端身份验证，通常在需要认证的请求中使用。
-   Cookie：发送与请求相关的cookie信息。
-   Referer：指定当前请求的来源页面URL，通常用于追踪和分析页面跳转来源。

空行：请求头部之后是一个空行，用于分隔请求头部和请求体。

请求体：包含要发送的数据。

## 3.2HTTP响应

状态行：包括HTTP版本、状态码和状态描述。

```
HTTP/1.1 200 OK
```

-   状态码：表示请求的处理结果，如 200 表示成功，404 表示未找到，500 表示服务器错误等。
-   状态描述：对状态码的简短描述。

响应头部：包含服务器和响应的附加信息，每一行是一个键值对，键和值之间用冒号分隔。

```
Content-Type: text/html
Content-Length: 1234
```

-   Content-Type：指定响应体的媒体类型。它告诉客户端如何解释响应体的内容。
-   Content-Length：指定响应体的大小，以字节为单位。
-   Location：当响应状态码为重定向（如301、302）时，指示客户端应该请求的新的URL地址。
-   Set-Cookie：服务器设置的Cookie，客户端在后续请求中会带上这个Cookie。

空行：响应头部之后是一个空行，用于分隔响应头部和响应体。

响应体：包含实际要传输的数据，可以是HTML、图片、文件等各种格式。

```python
import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 9999))

server.listen(5)

conn, addr = server.accept()

print(addr)

data = conn.recv(1024)
print(data.decode('utf-8'))

# 组织响应
response = """HTTP/1.1 200 ok
Content-Type: text/html

hello world
"""
conn.send(response.encode('utf-8'))
conn.close()
server.close()

```



```python
import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 9999))

server.listen(5)

# 循环连接、
while True:
    conn, addr = server.accept()
    print(addr)

    request = conn.recv(1024)
    print(request.decode('utf-8'))

    # 组织响应
    response = "HTTP/1.1 200 ok\r\n"  # \r:回车 \n:换行
    response += "Content-Type: text/html\r\n"
    response += "\r\n"
    # GET /index.html HTTP/1.1
    info_str = request.decode('utf-8').split('\r\n')[0]
    info = info_str.split(' ')[1]
    if info == "/lw":
        response += "你好，老王！"
    elif info == "/jz":
        response += "来吃饺子了！"
    else:
        response += "请问是谁呀？"

    conn.send(response.encode('gbk'))
    conn.close()
server.close()


```



```python
import socket


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", 9999))
    server.listen(5)
    # 等待浏览器连接
    while True:
        conn, addr = server.accept()
        print(addr)
        handle(conn)
        conn.close()
    server.close()


def handle(conn):
    data = conn.recv(1024)
    # 组织响应
    response = "HTTP/1.1 200 ok\r\n"  # \r:回车 \n:换行
    response += "Content-Type: image/jpeg\r\n"
    response += "\r\n"
    with open("evolution.jpg", "rb") as file:
        response = response.encode() + file.read()
    conn.send(response)


if __name__ == '__main__':
    main()


```





















































