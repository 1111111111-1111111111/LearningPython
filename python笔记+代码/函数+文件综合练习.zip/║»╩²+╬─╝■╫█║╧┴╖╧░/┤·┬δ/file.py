def file_read():
    """
    获取文件内容
    :return:
    """
    file = open('student_info.txt', 'rb')
    # 读的方法
    data_list = file.readlines()
    file.close()
    return data_list


def file_write(mess):
    """
    将信息写入文件
    :param mess:
    :return:
    """
    file = open('student_info.txt', 'ab')
    file.write(mess.encode('utf-8'))
    file.flush()
    file.close()


def file_overwrite(data_list):
    """
    覆盖写操作
    :param data_list: 要写入到信息列表
    :return:
    """
    file = open('student_info.txt', 'wb')
    file.writelines(data_list)
    file.close()
