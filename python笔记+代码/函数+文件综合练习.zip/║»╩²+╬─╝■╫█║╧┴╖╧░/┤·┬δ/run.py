from tool import *


def main():
    """
    启动函数
    :return:
    """
    # 功能选择字典
    menu = {
        "1": add,
        "2": show,
        "3": change,
        "4": delete,
        "5": exit
    }
    display()
    while True:
        # display()
        num = input("请输入选项：")
        if num in menu:
            menu[num]()
        else:
            print("您的输入有误，请重新输入！")
