from file import *


def display():
    """
    打印菜单
    :return:
    """
    print("""
    ================================
                学生管理系统
    1.录入信息              2.查看信息
    3.修改信息              4.删除信息
    5.退出系统
    ================================
    """)


def add():
    """
    录入信息
    :return:
    """
    cid = input("请输入学号：")
    # 判断学号是否已经存在
    if exist(cid):
        print("该学号已经存在！")
    else:
        name = input("请输入学生姓名：")
        age = input("请输入学生年龄：")
        message = f"{cid}    {name}    {age}\n"
        file_write(message)
        print("学生信息添加成功！")


def show():
    """
    查看信息
    :return:
    """
    print("当前学生信息：")
    data_list = file_read()
    for line in data_list:
        print(line.decode('utf-8'), end="")


def change():
    """
    修改信息
    :return:
    """
    cid = input("请输入要修改的学生学号：")  # 1002
    index = exist(cid)  # 2
    if index:
        name = input("请输入要修改的学生姓名：")  # 老张
        age = input("请输入要修改的学生年龄：")  # 60
        message = f"{cid}    {name}    {age}\n"
        # 覆盖写操作
        data_list = file_read()
        """data_list = [
                "学号     姓名   年龄",
                "1001    老王    40",
                "1002    老刘    45",
                "1003    小明    18",
            ]"""
        data_list[index] = message.encode('utf-8')
        """data_list = [
                        "学号     姓名   年龄",
                        "1001    老王    40",
                        "1002    老张    60",
                        "1003    小明    18",
                    ]"""
        file_overwrite(data_list)
        print("修改成功！")
    else:
        print("未找到该学号的学生")


def delete():
    """
    删除信息
    :return:
    """
    cid = input("请输入要删除的学生学号：")  # 1002
    index = exist(cid)  # 2
    if index:
        # 覆盖写操作
        data_list = file_read()
        """data_list = [
                "学号     姓名   年龄",
                "1001    老王    40",
                "1002    老刘    45",
                "1003    小明    18",
            ]"""
        del data_list[index]
        """data_list = [
                        "学号     姓名   年龄",
                        "1001    老王    40",
                        "1003    小明    18",
                    ]"""
        file_overwrite(data_list)
        print("删除成功！")
    else:
        print("未找到该学号的学生")


def exist(cid):
    """
    判断学号是否已经存在
    :return:
    """
    data_list = file_read()
    """data_list = [
        "学号     姓名   年龄",
        "1001    老王    40",
        "1002    老刘    45",
        "1003    小明    18",
    ]"""
    for i in range(len(data_list)):
        # data_list[i].decode("utf-8").split("    ") = ["1001", "老王", "40"]
        if data_list[i].decode("utf-8").split("    ")[0] == cid:
            return i
    return 0
