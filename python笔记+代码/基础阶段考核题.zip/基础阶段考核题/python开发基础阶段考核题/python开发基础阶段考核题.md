# python开发基础期阶段考核题

满分100分 

考核题主要是自测自己这个阶段的学习成果 希望同学们认真对待

考核主要是自己测试这个阶段学习的如何 不影响后面学习安排

## 一、选择题

1、网络通信TCP中哪个是属于接收消息。[   ] A

A、recv        B、send        C、sendto        D、recvfrom

2、序列类型的特性都有 (   )  C

​    A、下标 索引

​    B、字符串 元组 列表

​    C、切片 步长 索引 下标

​    D、没有正确的

3、Python的运行方式包括（  ）B

A、即时模式    B、脚本模式    C、交互模式    D、代码模式

4、print输出函数里默认有个参数设定自动换行是哪一个（  ）A

A、end    B、and    C、not    D、'  '

5、当我想要一个个取列表中的数据用哪一个循环更方便（  ）D

A、for i in range     B、while True    C、不知道    D、for i in

6、构造方法的作用。(  )  D

A、一般的方法    B、对象的初始化    C、对象的建立    D、类的初始化

## 二、填空题

1、以下代码输出的结果为 (   ) 3

```python
x = True
y = False
z = False

if not x or y:
    print(1)
elif not x or not y and z:
    print(2)
elif not x or y or not y and x:
    print(3)
else:
    print(4)
```

2、以下代码输出的结果为 (   )  10

```python
i = sum = 0

while i <= 4:
    sum += i
    i = i + 1
print(sum)
```

3、函数的参数传递形式分别为：**位置传参 关键字传参  默认值传参**  不定长参数1 *args  不定长参数2 **kwargs

4、0 and 11 ， 输出的结果为: 

5、0 or 11 ， 输出的结果为: 

6、python中,不定长函数有两种写法,分别是: 

7、闭包函数是指一个嵌套函数里的______并且它能_ ______的操作数据

8、文件操作中,读的操作模式用__r___来表示,写的操作模式用_w__来表示

## 三、判断题

正确 t  错误 f

1、字典中值（value）不可以重复。（ ）f

2、Python中main函数表示的是程序执行入口。（  ）t

3、a = {2 , 5 , 3  , [2 , 4 , 6 , 8] , 10}这个集合是正确的。（  ）f

4、以下代码输出的x为196。（ ）f

```python
def func():
    global x
    x = 56

x = 196
func()
print(x)
```

5、以下代码自会执行一次。（ ）f

```python
while 4 == 4:
    print('hello')
```

## 四、问答题

1、写出Python中的数据类型（在每个数据类型后面用括号备注上可变或不可变）：

​    数值类型：整型 浮点型 布尔类型

​    序列类型：元组(不可变)  列表(可变)  字符串 (不可变)

​    散列类型：字典(可变)  集合(可变)

2、什么形式的函数才是闭包。**一个嵌套函数，且嵌套函数使用外部函数的变量，外部函数返回值是内部函数**

3、装饰器的作用      

4、命名空间有几个   

5、讲过几个常用模块   

6、序列类型跟散列类型的区别。**有序和无序**

7、什么是作用域   **可以在哪个范围内使用指定的变量或者函数**

8、什么是模块 ， 什么是包 **包包含模块，将业务逻辑封装在模块中，在通过组合多个模块打包成包**



## 五、代码题

1、'各位老师辛苦啦！'

​    1、将上面的文字写入文件中 ， 文件命名为'demo.txt'

​    2、在'demo.txt'的文件中追加，'老师:今天的课就到此为止 明天又要继续上课啦'

```python
with open("./demo.txt", "w", encoding="utf-8") as f:
    f.write('各位老师辛苦啦！')

with open("./demo.txt", "r", encoding="utf-8") as f:
    print(f.read())

with open("./demo.txt","a+",encoding="utf-8") as f: 
    f.write('老师:今天的课就到此为止 明天又要继续上课啦')
```



2、生成10个随机数不同的随机二位数 ，并存放到集合中 

​    1、计算这个数字列表的平均值 ， 将该列表保存到一个列表number中

​    2、用平均值与数字列表比较 ， 将大于平均值的数字保存到列表number中 ，平均值必须是列表的第一个元素

```python
import random

s = set()
for i in range(10): 
    s.add(random.randint(10,99))

def avg(n):
    return sum(n) / len(n)
number = [avg(s)]
for i in s:
    if number[0] < i:
        number.append(i)
print(number)
```

3、dic = {"Development":"开发小哥","OP":"运维小哥","Operate":"运营小仙女","UI":"UI小仙女"}  ， 对字典进行增删改查

```python
dic = {"Development": "开发小哥", "OP": "运维小哥", "Operate": "运营小仙女", "UI": "UI小仙女"}


def add():
    """
    添 加 数 据 
    """
    data = input("请输入要添加的信息！(键 值)")
    key, value = data.split()
    dic[key] = value
    print(f"以成功添加键值对{key}:{value}")


def delect():
    """
    删 除 数 据 
    """
    data = input("请输入要删除的信息！(键/值 数据)")
    cmd, value = data.split()
    if cmd == "键":
        # 删除提供 键 的键值对 
        del dic[value]
        print(f"已删除键为{value}的数据")
    else:
        # 删除提供 值 的键值对 
        for key, v in dic.items():
            if value == v:
                del dic[key]
                print(f"已删除为值{data}的数据")
                break


def modify():
    """
    修 改 数 据 
    """
    data = input("请输入要修改的信息！(键/值 原键/值名 数据)")
    cmd, pri_name, data = data.split()
    if cmd == "键":
        v = dic[pri_name]
        dic[data] = v
        del dic[pri_name]
        print(f"键{pri_name}已被修改为{data}")
    else:
        for key, v in dic.items():
            if pri_name == v:
                dic[key] = data
                print(f"值{pri_name}已被修改为{data}")
                break


def seek():
    """
    查 找 数 据 
    """
    for key, value in dic.items():
        print(f"{key} : {value}")


def display():
    """
    打  印 菜 单 
    """
    print(""" 
        增：1
        删: 2
        改：3
        查: 4
        退出: 5
    """)


while True:
    display()
    cmd = input("请输入指令：")
    if cmd == "1":
        add()
    elif cmd == "2":
        delect()
    elif cmd == "3":
        modify()
    elif cmd == "4":
        seek()
    elif cmd == "5":
        break
    else:
        print("您的指令有误！")
      
```

4、彩票模拟器

- 先让用户依次选择6个红球(1-33之间)，再选择1个蓝球(1--16之间)，最后统一打印用户选择的球号。
- 确保用户不能选择重复的，选择的数不能超出范围。

```python
ball_number = []
n = 0  # 记录已选择的红球个数


def display():
    print("""
    请选择 6 个红球，红球序号在 1-33 之间
    再选择 1 个篮球，篮球序号在 1-16 之间
    """)


def red_ball():
    global n
    data = int(input(f"您已选择红球{n}个，请输入要选择的红球序号(一次输入一个序号)："))
    while True:
        if data in ball_number:
            data = int(input("球号已存在，请您重新输入(一次输入一个序号)："))
            continue
        if data not in range(1, 34):
            data = int(input("您输入的球号不存在，请重新输入(一次输入一个序号)："))
            continue
        ball_number.append(data)
        n += 1
        break


def blue_ball():
    global n
    data = int(input(f"您已选择{n}个球，接下来请输入选择篮球序号(一次输入一个序号)："))
    while True:
        if data not in range(1, 17):
            data = int(input("您输入的球号不存在，请重新输入1-16(一次输入一个序号)："))
            continue
        ball_number.append(data)
        n += 1
        break


while True:
    display()
    if len(ball_number) < 7:
        red_ball()
        continue
    elif len(ball_number) == 7:
        blue_ball()
        continue
    else:
        print(ball_number)
        break

```



5、在数字列表中查找最大的数字 不使用内置函数。给你一个思路

```python
[170, 160, 180, 165]
```

```python
假设第一个就是最大值
使用假设的和第二个进行比较, 发现更大的就替换假设的
使用假设的和第三个进行比较, 发现更大的就替换假设的
使用假设的和第四个进行比较, 发现更大的就替换假设的
最后，假设的就是最大的.
number = [170, 160, 180, 165]
MAX = number[0]
for i in number[1:]:
    if MAX < i:
        MAX = i
print(MAX)
```

6、写一个九九乘法表

```python
for i in range(1,10):
    for j in range(1, i+1):
        print(f"{j} * {i} = {i*j} ",end="\t")
    print()
```



7、 一球从100米高度自由落下，每次落地后反跳回原高度的一半；再落下，求它在第10次落地时，共经过多少米？第10次反弹多高？

```python
jump_high, high = 100, 100
SUM  = 0 
for i in range(1,11):
    jump_high = jump_high / 2
    SUM += jump_high * 2            
print(f"第10次落地时，共经过{SUM}米,反弹{jump_high}米")
```

8、猴子吃桃问题：猴子第一天摘下若干个桃子，当即吃了一半，还不瘾，又多吃了一个第二天早上又将剩下的桃子吃掉一半，又多吃了一个。以后每天早上都吃了前一天剩下的一半零一个。到第10天早上想再吃时，见只剩下一个桃子了。求第一天共摘了多少。

```python
initial_peach = 0
remaining_peach = 1
day = 10
for i in range(day-1, 0, -1):
   initial_peach = (remaining_peach + 1) * 2
print(initial_peach)
```

9、打印出100~999所有的"水仙花数"，所谓"水仙花数"是指一个三位数，其各位数字立方和等于该数本身。例如：153是一个"水仙花数"，因为153=1的三次方＋5的三次方＋3的三次方。

```python
for i in range(100, 1000):
    h = i // 100 # 百分位
    t = i % 100 // 10 # 十分位
    s = i % 10 # 个分位
    if i == pow(h,3) + pow(t,3) + pow(s,3):
        print(i, end="\t")
```



10、接收用户输入某年某月某日，判断这一天是这一年中的第几天。（需要考虑该年份是否为闰年）

```python
TIME = input("请输入年月日(年 月 日):")
year,month,day = TIME.split()
total_days = 0
months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
if year % 400 == 0 or year % 4 ==0 and year % 100 != 0
    months[1] = 29
for i in range(month-1):
    total_days += months[i]
total_days += day
print(f"{year}年{month}月{day}日是这一年的第{total_day}天")
```
