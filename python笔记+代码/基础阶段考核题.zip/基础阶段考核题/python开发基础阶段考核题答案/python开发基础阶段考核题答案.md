# python开发基础期阶段考核题

满分100分 

考核题主要是自测自己这个阶段的学习成果 希望同学们认真对待



## 一、选择题

1、网络通信TCP中哪个是属于接收消息。[ A  ]

A、recv		B、send		C、sendto		D、recvfrom

2、序列类型的特性都有 ( C ) 

​    A、下标 索引

​	B、字符串 元组 列表

​	C、切片 步长 索引 下标

​	D、没有正确的

3、Python的运行方式包括（ B,C  ）

A、即时模式	B、脚本模式	C、交互模式	D、代码模式

4、print输出函数里默认有个参数设定自动换行是哪一个（ A ）

A、end	B、and	C、not	D、'  '

5、当我想要一个个取列表中的数据用哪一个循环更方便（ D ）

A、for i in range 	B、while True	C、不知道	D、for i in

6、构造方法的作用。( B  )

A、一般的方法	B、对象的初始化	C、对象的建立	D、类的初始化

## 二、填空题

1、以下代码输出的结果为 (  3  )

```python
x = True
y = False
z = False

if not x or y:
    print(1)
elif not x or not y and z:
    print(2)
elif not x or y or not y and x:
    print(3)
else:
    print(4)
```

2、以下代码输出的结果为 ( 10  )

```python
i = sum = 0

while i <= 4:
    sum += i
    i = i + 1
print(sum)
```

3、函数的参数传递形式分别为：

```
位置参数
关键字参数
默认参数
不定长参数1 *args
不定长参数2 **kwargs
```

4、0 and 11 ， 输出的结果为: 0

5、0 or 11 ， 输出的结果为: 11

6、python中,不定长函数有两种写法,分别是:

```
不定长参数1 *args
不定长参数2 **kwargs
```

7、闭包函数是指一个嵌套函数里的内层函数并且它能间接的操作数据

8、文件操作中,读的操作模式用r来表示,写的操作模式用w来表示

## 三、判断题

正确 t  错误 f

1、字典中值（value）不可以重复。（ f ）

2、Python中main函数表示的是程序执行入口。（ t ）

3、a = {2 , 5 , 3  , [2 , 4 , 6 , 8] , 10}这个集合是正确的。（ f  ）

4、以下代码输出的x为196。（ f ）

```python
def func():
    global x
    x = 56
    
x = 196
func()
print(x)
```

5、以下代码自会执行一次。（ f ）

```python
while 4 == 4:
    print('hello')
```

## 四、问答题

1、写出Python中的数据类型（在每个数据类型后面用括号备注上可变或不可变）：

```python
数值类型：整型(int , 不可变) , 浮点型(float , 不可变) , 布尔类型(bool , 不可变)

序列类型：字符串(str , 不可变) , 列表(list , 可变) , 元组(tuple , 不可变)

散列类型：字典(dict , 可变) , 集合(set , 可变)
```

2、什么形式的函数才是闭包。

```
一个嵌套函数 , 外层函数返回内层函数 , 内层函数使用外层函数的数据
```

3、装饰器的作用

```
在不修改源代码的前提下 , 给源代码增加新功能
```

4、命名空间有几个

```
内置命名空间 , 全局命名空间 , 局部命名空间
```

5、讲过几个常用模块

```
time , random , os , sys ,json等等
```

6、序列类型跟散列类型的区别。

```
1,序列类型: 有序 存储多个数据

2,散列类型: 无序 去重 存储多个数据
```

7、什么是作用域

```
一个数据能够使用的范围
```

8、什么是模块 ， 什么是包

```
模块:就是一个python文件

包: 把功能相同的模块放在一个文件夹里统一管理 文件夹有个文件init 
```

## 五、代码题

1、'各位老师辛苦啦！'

​	1、将上面的文字写入文件中 ， 文件命名为'demo.txt'

​	2、在'demo.txt'的文件中追加，'老师:今天的课就到此为止 明天又要继续上课啦'

```python
with open('demo.txt'' , mode='w' , encoding='utf-8') as f:
    f.write('各位老师辛苦啦！')

with open('demo.txt'' , mode='r' , encoding='utf-8') as f:
    res = f.read()
    print(res)

with open('demo.txt'' , mode='a' , encoding='utf-8') as f:
    f.write('老师:今天的课就到此为止 明天又要继续上课啦')
```



2、生成10个随机数不同的随机二位数 ，并存放到集合中 

​	1、计算这个数字列表的平均值 ， 将该列表保存到一个列表number中

​	2、用平均值与数字列表比较 ， 将大于平均值的数字保存到列表number中 ，平均值必须是列表的第一个元素

```python
import random
a = set()
while True:
    res = random.randint(10 , 99)
    a.add(res)
    if len(a) == 10:
        ls = list(a)
        break
sum = 0
for i in ls:
   sum += i
average_value = sum / len(ls)
li = [average_value]
for x in ls:
    if x > average_value:
        li.append(x)
print(li)
```



3、dic = {"Development":"开发小哥","OP":"运维小哥","Operate":"运营小仙女","UI":"UI小仙女"}  ， 对字典进行增删改查

```Python
dic = {"Development":"开发小哥","OP":"运维小哥","Operate":"运营小仙女","UI":"UI小仙女"} 
#增
dic['manage']='alex'
print(dic)
#删
del dic['Development']
print(dic)
#改
dic['manage'] = 'oldboys'
print(dic)
#查看
find = dic.get("UI")
print(find)
```

4、彩票模拟器

- 先让用户依次选择6个红球(1-33之间)，再选择1个蓝球(1--16之间)，最后统一打印用户选择的球号。
- 确保用户不能选择重复的，选择的数不能超出范围。

5、在数字列表中查找最大的数字 不使用内置函数。给你一个思路

```python
[170, 160, 180, 165]
```

```python
假设第一个就是最大值
使用假设的和第二个进行比较, 发现更大的就替换假设的
使用假设的和第三个进行比较, 发现更大的就替换假设的
使用假设的和第四个进行比较, 发现更大的就替换假设的
最后，假设的就是最大的.
```

```python
# 首先创建一个空列表
# 设置循环次数 
# 设置一个输入红球的变量
# 判断红球输入的数字是否在1-33的范围是则输入正确 否则输入错误
# 判断红球输入的数字是否已在空列表内是则跳过 否则添加在列表
# 设置一个输入蓝球的变量
# 判断蓝球输入的数字是否在1-16的范围是则输入正确 放在空列表里
# 最后输出空列表的数据


ball = []

for i in range(6):
    red_ball = int(input('请输入1-33数字'))
    if red_ball in range(1, 34):
        print('输入正确')
        if red_ball in ball:
            continue
        else:
            ball.append(red_ball)
    else:
        print('输入错误')
        break

blue_ball = int(input('请输入1-16数字'))
if blue_ball in range(1, 16):
    print('输入正确')
ball.append(blue_ball)
print(ball)
```

```python
# 1.首先创建一个变量,值为列表的第一个数据
# 2.遍历列表 进行判断,如果遍历数据比变量大就覆盖变量数据
# 3.输出变量
list0 = [170, 160, 180, 165]
max_list1 = 0
for i in list0:
    if max_list1 < i:
        max_list1 = i
        print(max_list1)
```



6、写一个九九乘法表

```Python
# 乘法表 如何设计
# 1.要有几个循环???  2个 --> 有两个操作数,有行和列
# 2.循环的范围应该是几到几?  1-9
for i in range(1,10):
    for j in range(1,i+1): # 内外循环的值,最后要保持一致
        print(f'{i}*{j}={i*j}',end='\t')
    print()
# 左右两边的数相等  1*1 两边都是1  6*6两边都是6  9*9两边都是9
# 需要让i和j的值保持一致. 起点都是从1开始,终点值为i+1.  写i的话,默认就是取到i的前一位
```

7、 一球从100米高度自由落下，每次落地后反跳回原高度的一半；再落下，求它在第10次落地时，共经过多少米？第10次反弹多高？

```python
start_height = 100	# 初始高度
all_height = 100	# 计算求经过得路程 , 初始值为100即第一次掉落到地面得高度
height = 1	# 落地次数
while height <= 10:	
    start_height /= 2	# 每次反弹的高度
    all_height += (start_height * 2)	#对每次的反弹进行累加
    if height == 10:	#判断是否为第十次的反弹
        print(start_height)
    height += 1
print(all_height)
```

8、猴子吃桃问题：猴子第一天摘下若干个桃子，当即吃了一半，还不瘾，又多吃了一个第二天早上又将剩下的桃子吃掉一半，又多吃了一个。以后每天早上都吃了前一天剩下的一半零一个。到第10天早上想再吃时，见只剩下一个桃子了。求第一天共摘了多少。

```python
peach = 1
day = 9
while day > 0:
    peach = (peach + 1) * 2
    print('第',day,'天，摘了',peach,'个桃子。')
    day -= 1
print('第一天摘了',peach)
```

9、打印出100~999所有的"水仙花数"，所谓"水仙花数"是指一个三位数，其各位数字立方和等于该数本身。例如：153是一个"水仙花数"，因为153=1的三次方＋5的三次方＋3的三次方。

```python
for num in range(100 , 1000):
    num_0 = num % 10
    num_1 = num // 10 % 10
    num_2 = num // 100
    if num == num_0 ** 3 + num_1 ** 3 + num_2 ** 3:
        print(num)
```

10、接收用户输入某年某月某日，判断这一天是这一年中的第几天。（需要考虑该年份是否为闰年）

```Python
year = int(input("请输入年份: "))
month = int(input('请输入月份: '))
day = int(input('请输入日期号数: '))
date = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
if year % 400 == 0 or (year % 4 == 0 and year % 100 != 0):
    date[1] += 1
all_day = 0
for i in range(month - 1):
    all_day += date[i]
all_day += day  
print('这是第', all_day, '天')
```

