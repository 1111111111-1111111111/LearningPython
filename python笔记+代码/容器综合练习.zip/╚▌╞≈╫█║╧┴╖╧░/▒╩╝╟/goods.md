# 容器综合复习

```python
"""
商品
选购
付款 余额
"""
import time

# 商品
goods = {
    1: {"name": "小米14", "price": 500, "num": 10},
    2: {"name": "苹果15", "price": 500, "num": 10},
    3: {"name": "华为p60", "price": 500, "num": 10},
    4: {"name": "  OPPO  ", "price": 500, "num": 10},
    5: {"name": "  vivo  ", "price": 500, "num": 10},
}
# 用户信息
user_info = {"name": "老王", "balance": 1000}
# 购物车
user_buy_goods = {}
# 功能
info = """
    欢迎来到xx的手机商城：
    1：查看用户信息：
    2：查看商品详细信息：
    3：余额充值：
    4：购买商品
    5：查看自己购买的商品
    6：退出：
"""
# 进入系统
while True:
    # 打印操作指南
    print(info)
    # 获取用户操作
    choice = input("请输入你要进行的操作：") # 1 2 3 4 5 6 其他
    # 根据用户输入实现功能
    # 查看用户信息
    if choice == "1":
        print(f"用户姓名：{user_info["name"]}\n用户余额:{user_info["balance"]}")
    # 查看商品详细信息
    elif choice == "2":
        for key, value in goods.items():
            print(f"商品id：{key}   商品名字：{value["name"]}   商品价格：{value["price"]}   库存：{value["num"]}")
    # 余额充值
    elif choice == "3":
        money = int(input("请输入您要充值的金额："))
        user_info["balance"] += money
        print("当前的余额为：", user_info["balance"])
    # 购买商品
    elif choice == "4":
        # 获取购买信息
        buy = input("请输入您要购买的商品编号和数量(id,数量)：") # 1,1
        num_list = buy.split(",")
        # 商品id
        good_id = int(num_list[0])
        # 商品数量
        good_num = int(num_list[1])
        # 商品不在字典中
        if good_id not in goods:
            print("您购买的商品不存在！")
            continue
        # 库存够不够
        if good_num <= goods[good_id]["num"]: # 库存够
            # 计算总花费
            total_money = goods[good_id]["price"] * good_num
            # 展示交易信息
            print(f"您将要花费：{total_money}")
            print(f"您的余额为：{user_info['balance']}")

            # 判断余额是否充足
            if user_info['balance'] >= total_money:
                # 改变用户余额
                user_info['balance'] -= total_money
                # 改变库存
                goods[good_id]["num"] -= good_num
                # 加入购物车
                user_buy_goods[len(user_buy_goods) + 1] = {
                    "name": goods[good_id]["name"],
                    "num": good_num,
                    "time": time.strftime("%Y年%m月%d日%H:%M:%S")
                }
                print("购买成功，当前用户余额为：", user_info['balance'])
        else: # 库存不够
            print("库存不足！")
    # 查看自己购买的商品
    elif choice == "5":
        print("已购买的商品")
        print(" 商品序号 ", "商品名称 ", "购买数量 ", "购买时间 ")
        for k, v in user_buy_goods.items():
            print(f"\t{k}\t\t{v["name"]}\t\t{v["num"]}\t{v["time"]}")
    # 退出
    elif choice == "6":
        print("购买结束")
        break
    else:
        print("您的输入有误，请重新输入！")

```

