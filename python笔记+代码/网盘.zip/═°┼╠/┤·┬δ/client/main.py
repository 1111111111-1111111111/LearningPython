from src.handler import Handler

if __name__ == '__main__':
    handler = Handler()
    handler.execute()


