# 创建客户端
import os
import socket
from config.setting import HOST, PORT
from utils import request


class Handler:
    """ 处理 业务逻辑"""

    def __init__(self):
        self.host = HOST
        self.port = PORT
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # 判定登陆状态
        self.username = None

    def execute(self):
        """ 处理 连接请求"""
        # 发起连接请求
        self.sock.connect((self.host, self.port))
        # 打印菜单
        self.display()
        # 菜单选择字典
        method_dict = {
            "register": self.register,
            "login": self.login,
            "ls": self.ls,
            "upload": self.upload,
            "download": self.download
        }

        # 接收用户请求
        while True:
            # 提示信息
            hint = f"({self.username or "未登录"})>>:"
            # 接收用户请求
            message = input(hint)
            if not message:
                print("输入内容不能为空，请重新输入")
                continue
            if message == "##":
                print("客户端退出！")
                # 发送断开标志位
                request.send_data(self.sock, message)
                break
            # 分割指令
            cmd, *args = message.split()
            """
            cmd         *args
            register    lw 123
            login       lw 123
            ls          
            ls          1.1
            upload      本地路径 远程路径
            download    本地路径 远程路径
            """
            # 调用对应方法
            method = method_dict.get(cmd)
            if not method:
                print("命令不存在，请重新输入")
                continue
            method(*args)

        # 关闭连接
        self.sock.close()

    def display(self):
        """
        打印菜单
        :return:
        """
        welcome = """
        注册：register 用户 密码
        登录：login 用户 密码
        查看：ls 目录(目录不写默认查看根目录)
        上传：upload 本地目录 远程目录
        下载：download 本地目录 远程目录
        """
        print(welcome)

    def register(self, *args):
        """
        注册
        :param args:
        :return:
        """
        # 判断数据
        if len(args) != 2:
            print("格式错误，请重新输入，提示：register 用户 密码")
            return
        username, password = args
        data = f"register {username} {password}"
        # 发送数据
        request.send_data(self.sock, data)
        # 接受回复
        reply = request.recv_data(self.sock)
        print(reply)

    def login(self, *args):
        """
        登录
        :return:
        """
        # 判断数据
        if len(args) != 2:
            print("格式错误，请重新输入，提示：login 用户 密码")
            return
        username, password = args
        data = f"login {username} {password}"
        # 发送消息
        request.send_data(self.sock, data)
        reply = request.recv_data(self.sock)
        if reply == f"{username}登陆成功":
            self.username = username
        print(reply)

    def ls(self, *args):
        """
        查看文件
        :param args:
        :return:
        """
        # 确认登陆状态
        if not self.username:
            print("登录之后才允许查看目录")
            return
        # 查看根目录/子目录
        if not args:
            cmd = "ls"
        elif len(args) == 1:
            cmd = f"ls {args[0]}"
        else:
            print("格式错误，请重新输入，提示：ls 或者 ls 目录")
            return
        # 发送指令
        request.send_data(self.sock, cmd)
        reply = request.recv_data(self.sock)
        print(reply)

    def upload(self, *args):
        """
        上传文件
        :return:
        """
        # 确认登陆状态
        if not self.username:
            print("登录之后才允许上传文件")
            return

        # 判断数据
        if len(args) != 2:
            print("格式错误，请重新输入，提示：upload 本地目录 远程目录")
            return
        local_path, remote_path = args
        # 判断文件是否存在
        if not os.path.exists(local_path):
            print(f"文件 {local_path}不存在，请重新输入！")
            return
        # 发送指令
        request.send_data(self.sock, f"upload {remote_path}")
        reply = request.recv_data(self.sock)
        print(reply)

        # 开始上传文件
        request.send_file(self.sock, local_path)
        reply = request.recv_data(self.sock)
        print(reply)

    def download(self, *args):
        """
        下载文件
        :param args:
        :return:
        """
        # 确认登陆状态
        if not self.username:
            print("登录之后才允许下载文件")
            return

        # 判断数据
        if len(args) != 2:
            print("格式错误，请重新输入，提示：download 本地目录 远程目录")
            return
        local_path, remote_path = args
        # 创建上级目录文件夹
        folder = os.path.dirname(local_path)
        if not os.path.exists(folder):
            os.makedirs(folder)
        request.send_data(self.sock, f"download {remote_path}")
        reply = request.recv_data(self.sock)
        if reply == "开始下载":
            print(reply)
            request.recv_file(self.sock, local_path)
            print("下载成功")
        else:
            print(reply)
