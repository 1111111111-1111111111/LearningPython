# 提示信息
username = "老王"
hint = f"({username or "未登录"})"
# 接收用户请求
message = input(hint)
print(message)