# 工具类函数
import os
import struct


def send_data(conn, message):
    """
    发送消息
    :param conn:
    :param message:
    :return:
    """
    # 先发送头部
    data = message.encode('utf-8')
    header = struct.pack('i', len(data))
    conn.send(header)
    # 发送真实数据
    conn.send(data)


def recv_data(conn, chunk_size=1024):
    """
    接收消息
    :param conn:
    :return:
    """
    # 获取头部四个字节的信息 数据长度
    has_read_size = 0
    header = b""
    while has_read_size < 4:
        chunk = conn.recv(4 - has_read_size)
        has_read_size += len(chunk)
        header += chunk

    # 解包 获取真实数据长度
    data_length = struct.unpack('i', header)[0]
    has_read_size = 0
    total_data = b""
    while has_read_size < data_length:
        # 剩余数据长度
        length = data_length - has_read_size
        # if length > chunk_size:
        #     size = chunk_size
        # else:
        #     size = length
        size = chunk_size if length > chunk_size else length
        chunk = conn.recv(size)
        has_read_size += len(chunk)
        total_data += chunk

    # 返回收到的消息
    return total_data.decode("utf-8")


def send_file(conn, file_path, chunk_size=1024):
    """
    边读边发
    :param conn:
    :param file_path:
    :return:
    """
    # 获取文件大小
    file_size = os.path.getsize(file_path)
    header = struct.pack('i', file_size)
    conn.send(header)

    # 发送真实数据
    has_send_size = 0
    with open(file_path, 'rb') as file:
        while has_send_size < file_size:
            # 剩余数据长度
            length = file_size - has_send_size
            size = chunk_size if length > chunk_size else length
            chunk = file.read(size)
            conn.send(chunk)
            has_send_size += len(chunk)


def recv_file(conn, file_path, chunk_size=1024):
    """
    边接边写
    :param conn:
    :param file_path:
    :param chunk_size:
    :return:
    """
    # 获取头部四个字节的信息 数据长度
    has_recv_size = 0
    header = b""
    while has_recv_size < 4:
        chunk = conn.recv(4 - has_recv_size)
        has_recv_size += len(chunk)
        header += chunk

    # 解包 获取真实数据长度
    file_length = struct.unpack('i', header)[0]
    with open(file_path, 'wb') as file:
        has_recv_data_size = 0

        while has_recv_data_size < file_length:
            # 剩余数据长度
            length = file_length - has_recv_data_size
            size = chunk_size if length > chunk_size else length
            chunk = conn.recv(size)
            has_recv_data_size += len(chunk)
            file.write(chunk)
            file.flush()
