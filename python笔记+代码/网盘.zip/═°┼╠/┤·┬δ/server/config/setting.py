# 配置信息
import os

HOST = '127.0.0.1'
PORT = 9999

# 服务器路径
pan_path = os.path.dirname(os.path.dirname(__file__))

# 用户信息文件夹路径
DATABASE_PATH = os.path.join(pan_path, 'database')

# 用户网盘文件夹路径
FILES_PATH = os.path.join(pan_path, 'files')
