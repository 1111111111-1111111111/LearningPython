# 启动接口
from src.server import Server
from src.handler import Handler

if __name__ == '__main__':
    server = Server()
    server.run(Handler)
