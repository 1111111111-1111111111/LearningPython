# 进行逻辑的处理
import os

from utils import request
from config import setting
import json


class Handler:
    """处理 业务逻辑"""

    def __init__(self, conn):
        self.conn = conn
        self.username = None

    @property
    def home_path(self):
        """获取网盘的路径"""
        return os.path.join(setting.FILES_PATH, self.username)

    def execute(self):
        """
        处理连接请求
        :return: True:继续处理 False:关闭连接
        """
        # 接收消息 注册 登录 查看 上传 下载 退出
        message = request.recv_data(self.conn)
        if message == '##':
            print("客户端退出！")
            return False
        # 菜单选择字典
        method_dict = {
            "register": self.register,
            "login": self.login,
            "ls": self.ls,
            "upload": self.upload,
            "download": self.download
        }
        # 分割指令
        cmd, *args = message.split()
        # 调用对应方法
        method = method_dict[cmd]
        # 序列传参
        method(*args)

        return True

    def register(self, username, password):
        """
        注册
        :return:
        """
        # 存为字典
        user_info = {"username": username, "password": password}
        # json 储存
        user_path = f"{setting.DATABASE_PATH}/{username}.json"
        # 已经注册
        if os.path.exists(user_path):
            request.send_data(self.conn, f"{username}用户已经存在")
            return
        # 创建用户数据
        with open(user_path, "w", encoding="utf-8") as file:
            json.dump(user_info, file, ensure_ascii=False)
        # 创建用户网盘文件夹
        user_file_folder = os.path.join(setting.FILES_PATH, username)
        os.makedirs(user_file_folder)

        request.send_data(self.conn, f"{username}用户注册成功")

    def login(self, username, password):
        """登录"""
        # 获取用户信息
        user_path = f"{setting.DATABASE_PATH}/{username}.json"
        if os.path.exists(user_path):
            with open(user_path, "r", encoding="utf-8") as file:
                user_dict = json.load(file)
                if user_dict["password"] == password:
                    # 更改登陆状态
                    self.username = username
                    request.send_data(self.conn, f"{username}登陆成功")
                else:
                    request.send_data(self.conn, f"{username}密码错误")
        else:
            request.send_data(self.conn, f"{username}用户不存在")

    def ls(self, folder_path=None):
        """
        查看文件
        :param folder_path:
        :return:
        """
        # 确认登陆状态
        if not self.username:
            print("登录之后才允许查看目录")
            return
        # 查看根目录
        if not folder_path:
            # 获取根目录文件名
            data = "\n".join(os.listdir(self.home_path))
            if data:
                request.send_data(self.conn, data)
                return
            request.send_data(self.conn, "该目录没有内容")
            return

        # 查看子目录
        # 获取子目录的路径
        target_folder = os.path.join(self.home_path, folder_path)
        # 目标目录不存在
        if not os.path.exists(target_folder):
            request.send_data(self.conn, "路径不存在")
            return

        # 判断子目录是否为文件夹
        if not os.path.isdir(target_folder):
            request.send_data(self.conn, "文件夹不存在")
            return

        # 获取子目录文件名
        data = "\n".join(os.listdir(target_folder))
        if data:
            request.send_data(self.conn, data)
            return
        request.send_data(self.conn, "该目录没有内容")

    def upload(self, file_path):
        """
        上传文件
        :param file_path:
        :return:
        """
        # 确认登陆状态
        if not self.username:
            print("登录之后才允许上传文件")
            return
        # 目标文件路径
        # ../lw/1.1/3.20/fan.jpg
        target_folder = os.path.join(self.home_path, file_path)
        # 创建上级目录
        # ../lw/1.1/3.20
        folder = os.path.dirname(target_folder)
        if not os.path.exists(folder):
            os.makedirs(folder)
        request.send_data(self.conn, "开始上传")

        # 接受客户端文件
        request.recv_file(self.conn, target_folder)
        request.send_data(self.conn, "上传成功")

    def download(self, file_path):
        """
        下载文件
        :param file_path:
        :return:
        """
        # 确认登陆状态
        if not self.username:
            print("登录之后才允许上传文件")
            return
        # 获取目标文件路径
        target_folder = os.path.join(self.home_path, file_path)
        # 判断文件是否存在
        if not os.path.exists(target_folder):
            request.send_data(self.conn, f"{file_path}不存在")
            return
        request.send_data(self.conn, "开始下载")
        request.send_file(self.conn, target_folder)
