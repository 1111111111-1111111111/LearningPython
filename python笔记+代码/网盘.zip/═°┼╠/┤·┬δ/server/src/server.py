# 构建服务器
import socket

import select

from config import setting


class Server(object):
    """建立网络连接"""

    def __init__(self):
        self.host = setting.HOST
        self.port = setting.PORT

    def run(self, Handler):
        """
        启动服务器 服务端再服务
        """
        # 创建tcp套接字
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # ip可复用
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # 绑定ip地址
        server.bind((self.host, self.port))
        # 设置监听
        server.listen(5)
        # 服务端再服务
        while True:
            # 等待客户端连接
            conn, addr = server.accept()
            print(f"与客户端{addr}建立连接")
            # 创建实例
            instance = Handler(conn)
            # 循环通信
            while True:
                # 执行逻辑
                result = instance.execute()
                # 判断退出，False就退出
                if not result:
                    break
            # 关闭客户端连接对象
            conn.close()
        # 关闭套接字对象
        server.close()

    def run_io(self, Handler):
        """
        启动服务器 IO多路复用
        """
        # 创建tcp套接字
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # ip可复用
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # 绑定ip地址
        server.bind((self.host, self.port))
        # 设置监听
        server.listen(5)
        # 读列表
        read_list = [server]
        # 连接对象字典
        handler_dict = {}
        # 服务端再服务
        while True:
            # 添加监测机制
            r, w, x = select.select(read_list, [], [])
            # for循环遍历就绪的对象
            for read in r:
                if read == server:
                    conn, addr = server.accept()
                    print(f"与客户端{addr}建立连接")
                    # 加入监测列表
                    read_list.append(conn)
                    # 创建实例
                    handler_dict[conn] = Handler(conn)
                else:
                    result = handler_dict[read].execute()
                    # 判断退出，False就退出
                    if not result:
                        read.close()
                        read_list.remove(read)
                        del handler_dict[read]
        # 关闭套接字对象
        server.close()
